# Peer Connect


### Prerequisites

- OpenJDK v11
- SQL Server 2016+
- MongoDB v3.6+
- Eclipse v4.9+ / Intellij IDEA v2018.x

### Project Setup

To start working on this project, you need to setup few environment variables on you system:

- `PEER_CONNECT__DB_CONN` – JDBC Connection String (SQL Server)
- `PEER_CONNECT__DB_USER` – JDBC Username (SQL Server)
- `PEER_CONNECT__DB_PASS` – JDBC Password (SQL Server)
- `PEER_CONNECT__AUDIT_DB_CONN` – Connection String (MongoDB)

Additionally, to test emails, you need to set following variables:

- `PEER_CONNECT__SMTP_HOST` – SMTP Host
- `PEER_CONNECT__SMTP_PORT` – SMTP Port
- `PEER_CONNECT__SMTP_USER` – SMTP User
- `PEER_CONNECT__SMTP_PASS` – SMTP Pass



### DB Setup, Migration & Seeding

> The database named in the connection string should be present on the database server before starting the program.

This project uses Flyway to manage schema creation and migrations. The same can be found under `src/main/resources/db`.
Flyway automatically runs any migration/seed scripts in the mentioned folders.

> Flyway automatically drops & recreates whole schema if either the scripts or database structure is modified since last run.



### Development

Any development on this project should be done by creating a feature branch from the `development` branch.
When you complete the feature you are working on, you should send a pull request which will be reviewed and then merged into `development` branch.
Under no circumstances should you work on the `main` or `development` branch directly.

