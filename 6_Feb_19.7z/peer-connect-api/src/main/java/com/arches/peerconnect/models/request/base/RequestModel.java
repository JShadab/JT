package com.arches.peerconnect.models.request.base;


import com.arches.peerconnect.entities.base.Auditable;


/**
 * @author Anurag Mishra, 2018-12-27
 */
public interface RequestModel<T extends Auditable> {

    void mapToEntity(T entity);
    T createNew();

}
