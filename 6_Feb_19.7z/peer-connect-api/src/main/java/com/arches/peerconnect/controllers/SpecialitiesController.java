package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Speciality;
import com.arches.peerconnect.models.request.SpecialityRequest;
import com.arches.peerconnect.services.SpecialitiesService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@RestController
@RequestMapping("/specialities")
@PreAuthorize("hasRole('ADMIN')")
@Api(value="Speciality", description="Speciality")
public class SpecialitiesController extends PeerConnectBaseController<Speciality> {

    public SpecialitiesController(SpecialitiesService service) {
        super(service);
    }

    //

    @PostMapping("")
    @ApiOperation(value = "Create speciality")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody SpecialityRequest request) {

        return super.create(tenantId, request);

    }

    @PutMapping("")
    @ApiOperation(value = "Update speciality")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody SpecialityRequest request) {

        return super.update(entityId, request);

    }

}
