package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Affiliation;
import com.arches.peerconnect.models.request.AffiliationRequest;
import com.arches.peerconnect.services.AffiliationsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@RestController
@RequestMapping("/affiliations")
@PreAuthorize("hasRole('ADMIN')")
@Api(value="Affiliation", description="Affiliation")
public class AffiliationsController extends PeerConnectBaseController<Affiliation> {

    public AffiliationsController(AffiliationsService service) {
        super(service);
    }

    //

    @PostMapping("")
    @ApiOperation(value = "Create Affiliation")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody AffiliationRequest request) {

        return super.create(tenantId, request);

    }

    @ApiOperation(value = "Update Affiliation")
    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody AffiliationRequest request) {

        return super.update(entityId, request);

    }

}
