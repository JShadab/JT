package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.QuestionOption;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "SurveyQuestionOptions")
public class SurveyQuestionOption extends QuestionOption {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "questionId")
    @JsonIgnore
    private SurveyQuestion question;

    //

    @JsonProperty("questionId")
    public UUID getQuestionId() {
        return question.getId();
    }

}
