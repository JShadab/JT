package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.SupportTopic;
import com.arches.peerconnect.repos.base.PeerConnectRepository;


/**
 * @author Anurag Mishra, 2018-12-28
 */
public interface SupportTopicsRepository extends PeerConnectRepository<SupportTopic> { }
