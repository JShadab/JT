package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.Enrollment;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
public interface EnrollmentsRepository extends JpaRepository<Enrollment, UUID> {

    List<Enrollment> getAllByCampaign_Id(UUID campaignId);
    Optional<Enrollment> getByCampaign_IdAndId(UUID campaignId, UUID enrollmentId);

}
