package com.arches.peerconnect.config;


import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @author Anurag Mishra, 2019-01-16
 */
@Configuration
public class RabbitMQConfig {

    @Value("${app.messaging.exchange-name}")
    private String exchangeName;
    @Value("${app.messaging.emails-queue-name}")
    private String emailsQueueName;
    @Value("${app.messaging.texts-queue-name}")
    private String textsQueueName;

    private final ObjectMapper objectMapper;

    public RabbitMQConfig(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Bean
    public Jackson2JsonMessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter(objectMapper);
    }

    @Bean
    public RabbitAdmin rabbitAdmin(ConnectionFactory connectionFactory) {
        return new RabbitAdmin(connectionFactory);
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        System.out.printf(
            "RABBITMQ CONNECTION: %s@%s:%s\n",
            connectionFactory.getUsername(), connectionFactory.getHost(), connectionFactory.getPort());
        final var template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(jsonMessageConverter());

        return template;
    }

    @Bean
    public TopicExchange exchange() {
        System.out.printf("RABBITMQ TOPIC EXCHANGE: %s\n", exchangeName);
        return new TopicExchange(exchangeName);
    }

    @Bean("emailsQueue")
    public Queue emailQueue() {
        System.out.printf("RABBITMQ EMAILS QUEUE: %s\n", emailsQueueName);
        return new Queue(emailsQueueName);
    }

    @Bean("textsQueue")
    public Queue smsQueue() {
        System.out.printf("RABBITMQ TEXTS QUEUE: %s\n", textsQueueName);
        return new Queue(textsQueueName);
    }

    @Bean
    public Binding bindingEmails(TopicExchange exchange, Queue emailsQueue) {
        return BindingBuilder.bind(emailsQueue).to(exchange).with("emails.#");
    }

    @Bean
    public Binding bindingTexts(TopicExchange exchange, Queue textsQueue) {
        return BindingBuilder.bind(textsQueue).to(exchange).with("texts.#");
    }

}
