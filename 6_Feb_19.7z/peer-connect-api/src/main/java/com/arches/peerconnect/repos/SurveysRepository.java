package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.Survey;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
public interface SurveysRepository extends JpaRepository<Survey, UUID> {

    @Query("SELECT id FROM Survey WHERE campaign.id = ?1 AND isEnrollment = true")
    UUID getEnrollmentSurveyByCampaignId(UUID campaignId);

}
