package com.arches.peerconnect.services.base;


import com.arches.peerconnect.entities.base.Auditable;
import com.arches.peerconnect.entities.base.PeerConnectEntity;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.enums.OpCode;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.request.base.RequestModel;

import com.arches.peerconnect.services.audit.AuditTrailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;
import java.util.function.Consumer;


/**
 * @author Anurag Mishra, 2018-12-28
 */
public abstract class EntityService<T extends Auditable> {

    protected final JpaRepository<T, UUID> entityRepository;
    protected final ErrorCode entityErrorCode;

    @Autowired
    protected AuditTrailsService auditTrailsService;

    protected EntityService(JpaRepository<T, UUID> entityRepository, ErrorCode entityErrorCode) {
        this.entityRepository = entityRepository;
        this.entityErrorCode = entityErrorCode;
    }

    public T create(UUID campaignId, RequestModel<T> request) {
        return create(campaignId, request, null);
    }

    public T create(UUID campaignId, RequestModel<T> request, Consumer<T> postCreate) {
        var entity = request.createNew();

        if (postCreate != null)
            postCreate.accept(entity);

        entityRepository.save(entity);

        addAuditTrail(campaignId, entity.getId(), entity.getClass().getSimpleName(), OpCode.CREATED, request);

        return entity;
    }

    public void update(UUID entityId, RequestModel<T> request) {
        update(entityId, request, null, null);
    }

    public void update(UUID entityId, RequestModel<T> request, Consumer<T> preUpdate, Consumer<T> postUpdate) {
        var entity = entityRepository
                         .findById(entityId)
                         .orElseThrow(() -> new ApiException(entityErrorCode));

        if (preUpdate != null)
            preUpdate.accept(entity);

        request.mapToEntity(entity);

        if (postUpdate != null)
            postUpdate.accept(entity);

        entityRepository.save(entity);

        var campaignId = entity instanceof PeerConnectEntity ? ((PeerConnectEntity) entity).getCampaignId() : null;
        addAuditTrail(campaignId, entity.getId(), entity.getClass().getSimpleName(), OpCode.UPDATED, request);
    }

    public void delete(UUID entityId) {
        var entity = entityRepository
                         .findById(entityId)
                         .orElseThrow(() -> new ApiException(entityErrorCode));

        entity.setIsArchived(true);

        entityRepository.save(entity);

        var campaignId = entity instanceof PeerConnectEntity ? ((PeerConnectEntity) entity).getCampaignId() : null;
        addAuditTrail(campaignId, entity.getId(), entity.getClass().getSimpleName(), OpCode.ARCHIVED, null);
    }

    //

    protected void addAuditTrail(UUID campaignId, UUID entityId, String type, OpCode opCode, Object payload) {
        auditTrailsService.create(campaignId, entityId, type, opCode, payload);
    }
}
