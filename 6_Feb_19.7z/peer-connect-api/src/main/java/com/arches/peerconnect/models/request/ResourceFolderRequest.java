package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.ResourceFolder;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-2
 */
@Data
public class ResourceFolderRequest implements RequestModel<ResourceFolder> {

    @NotEmpty
    private String name;

    @NotNull
    private Boolean isRestricted;

    private UUID featResourceId;

    //

    @Override
    public void mapToEntity(ResourceFolder entity) {
        entity.setName(getName());
        entity.setIsRestricted(getIsRestricted());
    }

    @Override
    public ResourceFolder createNew() {
        var entity = new ResourceFolder();
        mapToEntity(entity);
        return entity;
    }

}
