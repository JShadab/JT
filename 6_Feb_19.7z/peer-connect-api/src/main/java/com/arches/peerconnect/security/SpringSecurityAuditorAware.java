package com.arches.peerconnect.security;


import org.springframework.data.domain.AuditorAware;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Component
public class SpringSecurityAuditorAware implements AuditorAware<UUID> {

    @Override
    public Optional<UUID> getCurrentAuditor() {

        var principal = Optional.ofNullable(SecurityContextHolder.getContext())
                                .map(SecurityContext::getAuthentication)
                                .filter(Authentication::isAuthenticated)
                                .map(Authentication::getPrincipal);

        return principal.isEmpty() || principal.get().getClass() == String.class
            ? Optional.empty()
            : principal.map(UserPrincipal.class::cast).map(UserPrincipal::getId);
    }
}
