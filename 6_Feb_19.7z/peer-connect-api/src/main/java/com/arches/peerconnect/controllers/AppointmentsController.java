package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Appointment;
import com.arches.peerconnect.models.request.AppointmentRequest;
import com.arches.peerconnect.security.CurrentUser;
import com.arches.peerconnect.security.UserPrincipal;
import com.arches.peerconnect.services.AppointmentsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.Date;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-02
 */
@RestController
@RequestMapping("/appointments")
@PreAuthorize("hasRole('ADMIN')")
@Api(value="Appointment", description="Appointment")
public class AppointmentsController extends PeerConnectBaseController<Appointment> {

    private final AppointmentsService service;

    public AppointmentsController(AppointmentsService service) {
        super(service);
        this.service = service;
    }

    //

    @GetMapping("/upcoming")
    @ApiOperation(value = "Get upcoming appointments")
    public List<Appointment> getAllUpcoming(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "captainId", required = false) UUID captainId,
        @RequestParam(value = "participantId", required = false) UUID participantId,
        @RequestParam(value = "startDate", required = false) Date startDate,
        @RequestParam(value = "endDate", required = false) Date endDate) {

        return service.findAllUpcoming(tenantId, captainId, participantId, startDate, endDate);

    }

    @GetMapping("/completed")
    @ApiOperation(value = "Get all completed appointments")
    public List<Appointment> getAllCompleted(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "captainId", required = false) UUID captainId,
        @RequestParam(value = "participantId", required = false) UUID participantId,
        @RequestParam(value = "startDate", required = false) Date startDate,
        @RequestParam(value = "endDate", required = false) Date endDate) {

        return service.findAllCompleted(tenantId, captainId, participantId, startDate, endDate);

    }

    @PostMapping("/captainArrival")
    @ApiOperation(value = "Mark captain arrival")
    public ResponseEntity<?> markCaptainArrival(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId,
        @RequestParam(value = "captainId") UUID captainId) {

        service.markCaptainArrival(tenantId, appointmentId, captainId);

        return okResponse();

    }

    @PostMapping("/participantArrival")
    @ApiOperation(value = "Mark participant arrival")
    public ResponseEntity<?> markParticipantArrival(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId,
        @RequestParam(value = "participantId") UUID participantId) {

        service.markParticipantArrival(tenantId, appointmentId, participantId);

        return okResponse();

    }

    @PostMapping("/completedAppointment")
    @ApiOperation(value = "Mark appointment completed")
    public ResponseEntity<?> markAppointmentComplete(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId,
        @RequestParam(value = "duration") int duration,
        @RequestParam(value = "externalId") String externalId) {

        service.markAppointmentComplete(tenantId, appointmentId, duration, externalId);

        return okResponse();

    }

    @PostMapping("/sendOverdueReminder")
    @ApiOperation(value = "Send appointment reminder")
    public ResponseEntity<?> sendOverdueReminder(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId) {

        service.sendAppointmentOverdueReminder(tenantId, appointmentId);

        return okResponse();

    }

    @PostMapping("/sendOffLabelRequest")
    @ApiOperation(value = "Send Off label request")
    public ResponseEntity<?> sendOffLabelRequest(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId) {

        service.sendOffLabelRequest(tenantId, appointmentId);

        return okResponse();

    }

    @PostMapping("/sendSupportRequest")
    @ApiOperation(value = "Send support request")
    public ResponseEntity<?> sendSupportRequest(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("supportTopicId") UUID supportTopicId,
        @RequestParam("name") String name,
        @RequestParam("email") String email) {

        service.sendSupportRequest(tenantId, supportTopicId, name, email);

        return okResponse();

    }


    @PostMapping("")
    @ApiOperation(value = "Create appointment")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody AppointmentRequest request) {

        var entity = service.create(tenantId, request);

        return createdResponse(entity.getId());
    }

    @PutMapping("")
    @ApiOperation(value = "Update appointment")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody AppointmentRequest request) {

        service.update(entityId, request);

        return okResponse();
    }

    @DeleteMapping("")
    @ApiOperation(value = "Delete appointment")
    public ResponseEntity<?> delete(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @CurrentUser UserPrincipal principal) {

        service.delete(tenantId, entityId, principal);

        return okResponse();
    }

}
