package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.SupportTopic;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.SupportTopicsRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Service
public class SupportTopicsService extends PeerConnectEntityService<SupportTopic> {

    public SupportTopicsService(
        SupportTopicsRepository supportTopicsRepository,
        ParentsRepository parentsRepository) {

        super(supportTopicsRepository, parentsRepository, ErrorCode.E030);

    }

}
