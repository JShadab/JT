package com.arches.peerconnect.entities.base;


import com.arches.peerconnect.entities.enums.QuestionDataType;
import com.arches.peerconnect.entities.enums.QuestionType;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class Question extends PeerConnectEntity {

    @Column(nullable = false)
    private String name;

    private String description;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private QuestionType type;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private QuestionDataType dataType;

    @Column(nullable = false)
    private Boolean isEvent = false;

}
