package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.base.PeerConnectEntity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.Arrays;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_TimeZones")
public class TimeZone extends PeerConnectEntity {

    @Column(nullable = false)
    private String label;

    @Column(nullable = false)
    private String abbr;

    @Column(nullable = false)
    private int utcOffset = 0;

    @Column(nullable = false)
    private int dstOffset = 0;

}
