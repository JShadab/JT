package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.Topic;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotEmpty;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@Data
public class TopicRequest implements RequestModel<Topic> {

    @NotEmpty
    private String name;

    //

    @Override
    public void mapToEntity(Topic entity) {
        entity.setName(getName());
    }

    @Override
    public Topic createNew() {
        var entity = new Topic();
        mapToEntity(entity);
        return entity;
    }

}
