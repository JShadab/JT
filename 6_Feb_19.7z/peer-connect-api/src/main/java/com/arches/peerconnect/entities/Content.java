package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.Auditable;
import com.arches.peerconnect.entities.enums.Channel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "Contents")
public class Content extends Auditable {

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private Channel channel;

    private String category;

    private String subject;

    private String preHeader;

    @Column(nullable = false)
    private String text;

    private String fileName;


    @ManyToOne
    @JoinColumn(name = "campaignId")
    @JsonIgnore
    private Parent campaign;

    //

    @JsonProperty("campaignId")
    public UUID getCampaignId() {
        return campaign.getId();
    }

}
