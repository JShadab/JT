package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.TimeZone;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.TimeZonesRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Service
public class TimeZonesService extends PeerConnectEntityService<TimeZone> {

    public TimeZonesService(
        TimeZonesRepository timeZonesRepository,
        ParentsRepository parentsRepository) {

        super(timeZonesRepository, parentsRepository, ErrorCode.E032);

    }

}
