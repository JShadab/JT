package com.arches.peerconnect.entities.enums;

/**
 * @author Anurag Mishra, 2019-01-17
 */
public enum ContactMethod {

    Email,
    SMS,
    Both

}
