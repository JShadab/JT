package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.Enrollment;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.enums.OpCode;
import com.arches.peerconnect.entities.peerconnect.Participant;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.request.ParticipantRequest;
import com.arches.peerconnect.repos.*;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
@Service
public class ParticipantsService extends PeerConnectEntityService<Participant> {

    private final ParticipantsRepository participantsRepository;
    private final UsersRepository usersRepository;
    private final EnrollmentsRepository enrollmentsRepository;
    private final SurveysRepository surveysRepository;
    private final NotificationsService notificationsService;

    public ParticipantsService(
        ParticipantsRepository participantsRepository,
        UsersRepository usersRepository,
        EnrollmentsRepository enrollmentsRepository,
        SurveysRepository surveysRepository,
        ParentsRepository parentsRepository,
        NotificationsService notificationsService) {

        super(participantsRepository, parentsRepository, ErrorCode.E021);

        this.participantsRepository = participantsRepository;
        this.usersRepository = usersRepository;
        this.enrollmentsRepository = enrollmentsRepository;
        this.surveysRepository = surveysRepository;
        this.notificationsService = notificationsService;

    }

    //

    public Participant getByCampaignIdAndEmailAddress(UUID campaignId, String email) {
        return participantsRepository.getByCampaign_IdAndEmailAddress(campaignId, email).orElse(null);
    }

    public List<Participant> getAllUnscheduledParticipants(UUID campaignId) {
        return participantsRepository.getAllUnscheduledParticipants(campaignId);
    }

    public List<Participant> getAllWithUpcomingAppointments(UUID campaignId) {
        return participantsRepository.getAllWithUpcomingAppointments(campaignId);
    }

    @SuppressWarnings("Duplicates")
    public Enrollment create(UUID campaignId, ParticipantRequest request) {

        var user = usersRepository.findByCampaignIdAndEmailAddress(campaignId, request.getEmailAddress());

        if (user.isPresent())
            throw new ApiException(ErrorCode.E016);

        var enrollment = request.createNew();

        var surveyId = surveysRepository.getEnrollmentSurveyByCampaignId(campaignId);

        enrollment.setCampaign(parentsRepository.getOne(campaignId));
        enrollment.setSurvey(surveysRepository.getOne(surveyId));

        var result = enrollmentsRepository.save(enrollment);

        addAuditTrail(campaignId, result.getId(), enrollment.getClass().getSimpleName(), OpCode.CREATED, request);

        notificationsService.sendWelcomeEmail(request.getFirstName(), request.getLastName(), request.getEmailAddress());

        return result;
    }

    public void update(UUID participantId, ParticipantRequest request) {
        var enrollment = enrollmentsRepository
                             .findById(participantId)
                             .orElseThrow(() -> new ApiException(ErrorCode.E021));

        request.mapToEntity(enrollment);

        enrollmentsRepository.save(enrollment);

        addAuditTrail(enrollment.getCampaignId(), enrollment.getId(), enrollment.getClass().getSimpleName(), OpCode.UPDATED, request);
    }

}
