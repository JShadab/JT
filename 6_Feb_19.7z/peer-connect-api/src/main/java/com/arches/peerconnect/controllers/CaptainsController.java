package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Captain;
import com.arches.peerconnect.models.request.CaptainRequest;
import com.arches.peerconnect.services.CaptainsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
@RestController
@RequestMapping("/captains")
@PreAuthorize("hasRole('ADMIN')")
@Api(value="Captain", description="Captain")
public class CaptainsController extends PeerConnectBaseController<Captain> {

    private final CaptainsService service;

    public CaptainsController(CaptainsService service) {
        super(service);
        this.service = service;
    }

    //

    @GetMapping("/by-email")
    @ApiOperation(value = "Get Captain by email")
    public Captain getByEmail(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("email") String email) {
        return service.getByCampaignIdAndEmailAddress(tenantId, email);
    }

    @GetMapping("/available")
    @ApiOperation(value = "Get available captain for a topic")
    public List<Captain> available(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("topicId") UUID topicId) {
        return service.getAvailableCaptainsByTopic(tenantId, topicId);
    }

    @PostMapping("")
    @ApiOperation(value = "Create captain")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody CaptainRequest request) {

        var result = service.create(tenantId, request);

        return createdResponse(result.getId());
    }

    @PutMapping("")
    @ApiOperation(value = "Update captain")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody CaptainRequest request) {

        service.update(entityId, request);

        return okResponse();
    }

}
