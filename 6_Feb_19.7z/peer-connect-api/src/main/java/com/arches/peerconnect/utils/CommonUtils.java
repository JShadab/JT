package com.arches.peerconnect.utils;


import com.aventrix.jnanoid.jnanoid.NanoIdUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-31
 */
public class CommonUtils {

    private static TypeReference<List<UUID>> listTypeReference = new TypeReference<>() { };
    private static ObjectMapper mapper = new ObjectMapper();

    public static List<UUID> convertToUUIDList(String uuidsAsJson) {
        List<UUID> uuids;
        try {
            uuids = mapper.readValue(uuidsAsJson, listTypeReference);
        } catch (IOException e) {
            uuids = new ArrayList<>();
        }

        return uuids;
    }

    public static String generateNanoId(int length) {
        return NanoIdUtils
                   .randomNanoId(
                       NanoIdUtils.DEFAULT_NUMBER_GENERATOR,
                       NanoIdUtils.DEFAULT_ALPHABET,
                       length
                   );
    }

}
