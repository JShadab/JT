package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.SupportTopic;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotEmpty;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Data
public class SupportTopicRequest implements RequestModel<SupportTopic> {

    @NotEmpty
    private String name;

    //

    @Override
    public void mapToEntity(SupportTopic entity) {
        entity.setName(getName());
    }

    @Override
    public SupportTopic createNew() {
        var entity = new SupportTopic();
        mapToEntity(entity);
        return entity;
    }

}
