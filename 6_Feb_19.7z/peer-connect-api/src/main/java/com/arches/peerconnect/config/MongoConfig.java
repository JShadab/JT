package com.arches.peerconnect.config;


import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;

import org.bson.UuidRepresentation;
import org.bson.codecs.UuidCodec;
import org.bson.codecs.configuration.CodecRegistries;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;


/**
 * @author Anurag Mishra, 2019-01-13
 */
@Configuration
public class MongoConfig {

    @Primary
    @Bean
    public MongoClientOptions mongoClientOptions() {
        // Customize the codec registry to use the standard (non-legacy)
        // representation when storing and retrieving UUIDs.
        final var codecRegistry =
            CodecRegistries.fromRegistries(
                CodecRegistries.fromCodecs(new UuidCodec(UuidRepresentation.STANDARD)),
                MongoClient.getDefaultCodecRegistry()
            );

        return MongoClientOptions
                    .builder()
                    .codecRegistry(codecRegistry)
                    .build();
    }

}
