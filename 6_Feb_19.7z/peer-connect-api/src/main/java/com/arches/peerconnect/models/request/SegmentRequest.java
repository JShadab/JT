package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.Segment;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotEmpty;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Data
public class SegmentRequest implements RequestModel<Segment> {

    @NotEmpty
    private String name;

    //

    @Override
    public void mapToEntity(Segment entity) {
        entity.setName(getName());
    }

    @Override
    public Segment createNew() {
        var entity = new Segment();
        mapToEntity(entity);
        return entity;
    }

}
