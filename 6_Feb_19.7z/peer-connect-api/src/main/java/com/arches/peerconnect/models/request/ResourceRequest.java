package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.enums.ContentType;
import com.arches.peerconnect.entities.peerconnect.Resource;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Data
public class ResourceRequest implements RequestModel<Resource> {

    @NotEmpty
    private String name;

    @NotEmpty
    private String description;

    @NotNull
    private ContentType contentType;

    @NotEmpty
    private String absoluteUrl;

    @NotEmpty
    private String thumbnailUrl;

    @NotNull
    private UUID folderId;

    //

    @Override
    public void mapToEntity(Resource entity) {
        entity.setName(getName());
        entity.setDescription(getDescription());
        entity.setContentType(getContentType());
        entity.setAbsoluteUrl(getAbsoluteUrl());
        entity.setThumbnailUrl(getThumbnailUrl());
    }

    @Override
    public Resource createNew() {
        var entity = new Resource();
        mapToEntity(entity);
        return entity;
    }

}
