package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Affiliation;
import com.arches.peerconnect.repos.base.PeerConnectRepository;


/**
 * @author Anurag Mishra, 2018-12-28
 */
public interface AffiliationsRepository extends PeerConnectRepository<Affiliation> {
}
