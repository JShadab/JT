package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Availability;
import com.arches.peerconnect.repos.base.PeerConnectRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-31
 */
public interface AvailabilitiesRepository extends PeerConnectRepository<Availability> {

    @Query(
        "SELECT a\n" +
        "FROM   Availability a\n" +
        "WHERE  a.campaign.id = :campaignId\n" +
        "  AND  a.captain.id = :captainId\n" +
        "  AND  (:startDate IS NULL OR a.startDate >= :startDate)\n" +
        "  AND  (:endDate IS NULL OR a.startDate <= :endDate)\n" +
        "ORDER BY a.startDate ASC")
    List<Availability> findAllByParams(
        @Param("campaignId") UUID campaignId,
        @Param("captainId") UUID captainId,
        @Param("startDate") Date startDate,
        @Param("endDate") Date endDate);

    @Query(
        "SELECT a\n" +
        "FROM   Availability a\n" +
        "       LEFT JOIN Appointment ap ON a.id = ap.availability.id\n" +
        "WHERE  ap.id IS NULL\n" +
        "  AND  a.campaign.id = :campaignId\n" +
        "  AND  a.captain.id = :captainId\n" +
        "  AND  (:startDate IS NULL OR a.startDate >= :startDate)\n" +
        "  AND  (:endDate IS NULL OR a.startDate <= :endDate)\n" +
        "ORDER BY a.startDate ASC")
    List<Availability> findAllUnused(
        @Param("campaignId") UUID campaignId,
        @Param("captainId") UUID captainId,
        @Param("startDate") Date startDate,
        @Param("endDate") Date endDate);

}
