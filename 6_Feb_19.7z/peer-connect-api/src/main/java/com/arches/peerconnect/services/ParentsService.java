package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.Parent;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.enums.Level;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.services.base.EntityService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-26
 */
@Service
public class ParentsService extends EntityService<Parent> {

    private final ParentsRepository parentsRepository;

    public ParentsService(ParentsRepository parentsRepository) {
        super(parentsRepository, ErrorCode.E036);
        this.parentsRepository = parentsRepository;
    }

    public List<Parent> getAllByLevel(Level level) {
        return parentsRepository.findAllByLevel(level);
    }

    public List<Parent> getAllByParentId(UUID parentId) {
        return parentsRepository.findAllByParent_Id(parentId);
    }

}
