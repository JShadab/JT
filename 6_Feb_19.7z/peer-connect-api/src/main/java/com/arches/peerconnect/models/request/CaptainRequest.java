package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.Enrollment;
import com.arches.peerconnect.models.request.base.RequestModel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-31
 */
@Data
public class CaptainRequest implements RequestModel<Enrollment> {

    @NotEmpty
    private String firstName;

    @NotEmpty
    private String lastName;

    private String title;

    @NotEmpty
    private String emailAddress;

    @NotEmpty
    private String password;

    @NotEmpty
    private String mobileNumber;

    private String addressLine1;

    private String addressLine2;

    private String city;

    private String state;

    private String zipCode;

    private String profileImageUrl;

    private String biography;

    private Boolean optIn = true;

    private Boolean terms = true;

    private Boolean unsubscribed = false;

    private UUID mediaSourceId;

    private UUID affiliationId;

    private List<UUID> roleId;

    private List<UUID> segmentId;

    private UUID specialityId;

    @NotNull
    private UUID timeZoneId;

    @NotNull
    private List<UUID> topicId;

    @NotNull
    private Boolean isActive;

    private String userType = "Captain";

    //

    @Override
    public void mapToEntity(Enrollment entity) {
        // encode password
        var pwdEncoder = new BCryptPasswordEncoder();
        password = pwdEncoder.encode(password);

        var mapper = new ObjectMapper();
        String json;

        try {
            json = mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            // Will be caught in validation and thrown properly
            json = null;
        }

        entity.setResponse(json);
        entity.setIsActive(getIsActive());
    }

    @Override
    @JsonIgnore
    public Enrollment createNew() {
        var entity = new Enrollment();
        mapToEntity(entity);
        return entity;
    }

}
