package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.ResourceFolder;
import com.arches.peerconnect.repos.base.PeerConnectRepository;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
public interface ResourceFoldersRepository extends PeerConnectRepository<ResourceFolder> {

    @Override
    @Query("SELECT f FROM ResourceFolder f LEFT JOIN FETCH f.resources WHERE f.campaign.id = ?1 AND f.id = ?2")
    Optional<ResourceFolder> getByCampaign_IdAndId(UUID campaignId, UUID entityId);

}
