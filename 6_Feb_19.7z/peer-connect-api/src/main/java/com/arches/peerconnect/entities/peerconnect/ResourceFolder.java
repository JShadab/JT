package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.base.PeerConnectEntity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_ResourceFolders")
public class ResourceFolder extends PeerConnectEntity {

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Boolean isRestricted = false;


    @OneToOne
    @JoinColumn(name = "featResourceId")
    @JsonIgnore
    private Resource featResource;

    @OneToMany(mappedBy = "folder")
    @JsonInclude(Include.NON_DEFAULT)
    private List<Resource> resources;

    //

    @JsonProperty("featResourceId")
    @JsonInclude(Include.NON_NULL)
    public UUID getFeatResourceId() {
        return featResource != null ? featResource.getId() : null;
    }

}
