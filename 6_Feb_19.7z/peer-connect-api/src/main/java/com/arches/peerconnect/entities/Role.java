package com.arches.peerconnect.entities;


import lombok.Data;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@Entity
@Table(name = "Roles")
public class Role {

    @Id
    @Type(type = "uuid-char")
    @Column(columnDefinition = "uniqueidentifier", nullable = false)
    @GenericGenerator(name = "guid-generator", strategy = "uuid2")
    @GeneratedValue(generator = "guid-generator")
    private UUID id;

    @Column(nullable = false)
    private String name;

    @ManyToMany(mappedBy = "roles")
    private Set<Admin> admins = new HashSet<>();

}
