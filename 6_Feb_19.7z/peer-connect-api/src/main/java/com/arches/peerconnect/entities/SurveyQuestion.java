package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.Question;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "SurveyQuestions")
public class SurveyQuestion extends Question {

    @OneToMany(mappedBy = "question")
    private List<SurveyQuestionOption> options;

}

