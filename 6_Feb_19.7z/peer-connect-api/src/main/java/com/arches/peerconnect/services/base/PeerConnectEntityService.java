package com.arches.peerconnect.services.base;


import com.arches.peerconnect.entities.base.PeerConnectEntity;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.request.base.RequestModel;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.base.PeerConnectRepository;

import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;


/**
 * @author Anurag Mishra, 2018-12-28
 */
public class PeerConnectEntityService<T extends PeerConnectEntity> extends EntityService<T> {

    private final PeerConnectRepository<T> peerConnectRepository;
    protected final ParentsRepository parentsRepository;

    public PeerConnectEntityService(
        PeerConnectRepository<T> peerConnectRepository,
        ParentsRepository parentsRepository,
        ErrorCode entityErrorCode) {

        super(peerConnectRepository, entityErrorCode);
        this.peerConnectRepository = peerConnectRepository;
        this.parentsRepository = parentsRepository;

    }


    public List<T> getAllByCampaignId(UUID campaignId) {
        return peerConnectRepository.getAllByCampaign_Id(campaignId);
    }

    public T getByCampaignIdAndId(UUID campaignId, UUID entityId) {
        return peerConnectRepository
                   .getByCampaign_IdAndId(campaignId, entityId)
                   .orElseThrow(() -> new ApiException(entityErrorCode));
    }

    @Override
    public T create(UUID campaignId, RequestModel<T> request) {
        return create(campaignId, request, null);
    }

    @Override
    public T create(UUID campaignId, RequestModel<T> request, Consumer<T> postCreate) {
        Consumer<T> postCreateWithCampaign = entity -> {
            if (postCreate != null) postCreate.accept(entity);
            entity.setCampaign(parentsRepository.getOne(campaignId));
        };

        return super.create(campaignId, request, postCreateWithCampaign);
    }

}
