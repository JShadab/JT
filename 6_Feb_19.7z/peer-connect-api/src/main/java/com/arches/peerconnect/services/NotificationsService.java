package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ContactMethod;
import com.arches.peerconnect.entities.peerconnect.Appointment;
import com.arches.peerconnect.entities.peerconnect.Captain;
import com.arches.peerconnect.entities.peerconnect.Participant;
import com.arches.peerconnect.entities.peerconnect.TimeZone;
import com.arches.peerconnect.messaging.senders.MessageSender;
import com.arches.peerconnect.models.message.EmailMessage;
import com.arches.peerconnect.models.message.TextMessage;

import org.flowable.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;


/**
 * @author Anurag Mishra, 2019-01-18
 */
@Service
@Transactional
@SuppressWarnings("Duplicates")
public class NotificationsService {

    @Value("${app.admin.name}")
    private String adminName;

    @Value("${app.admin.email}")
    private String adminEmail;

    @Value("${app.sender.name}")
    private String senderName;

    @Value("${app.sender.email}")
    private String senderEmail;

    @Value("${app.sender.phone}")
    private String senderPhone;


    @Value("${app.mandrill.templates.accounts.welcome}")
    private String welcomeTmplId;

    @Value("${app.mandrill.templates.accounts.forgot-password}")
    private String forgotPwdTmplId;

    @Value("${app.mandrill.templates.accounts.unsubscribe}")
    private String unsubscribeTmplId;


    @Value("${app.mandrill.templates.appointments.participants.scheduled}")
    private String apptScheduledParticipantTmplId;

    @Value("${app.mandrill.templates.appointments.participants.reminder-unscheduled}")
    private String apptReminderUnscheduledParticipantTmplId;

    @Value("${app.mandrill.templates.appointments.participants.reminder-upcoming}")
    private String apptReminderUpcomingParticipantTmplId;

    @Value("${app.mandrill.templates.appointments.participants.reminder-1hour}")
    private String apptReminder1HourParticipantTmplId;

    @Value("${app.mandrill.templates.appointments.participants.reminder-15mins}")
    private String apptReminder15MinsParticipantTmplId;

    @Value("${app.mandrill.templates.appointments.participants.reminder-overdue}")
    private String apptReminderOverdueTmplId;

    @Value("${app.mandrill.templates.appointments.participants.completed}")
    private String apptCompletedTmplId;

    @Value("${app.mandrill.templates.appointments.participants.cancelled}")
    private String apptCancelledParticipantTmplId;


    @Value("${app.mandrill.templates.appointments.captains.scheduled}")
    private String apptScheduledCaptainTmplId;

    @Value("${app.mandrill.templates.appointments.captains.reminder-upcoming}")
    private String apptReminderUpcomingCaptainTmplId;

    @Value("${app.mandrill.templates.appointments.captains.reminder-1hour}")
    private String apptReminder1HourCaptainTmplId;

    @Value("${app.mandrill.templates.appointments.captains.reminder-15mins}")
    private String apptReminder15MinsCaptainTmplId;

    @Value("${app.mandrill.templates.appointments.captains.cancelled}")
    private String apptCancelledCaptainTmplId;


    @Value("${app.mandrill.templates.requests.offlabel}")
    private String reqOffLabelTmplId;

    @Value("${app.mandrill.templates.requests.support}")
    private String reqSupportTmplId;


    @Value("${app.mandrill.templates.admin.daily-recap}")
    private String dailyRecapTmplId;


    private final MessageSender sender;
    private final TimeZonesService timeZonesService;
    private final SupportTopicsService supportTopicsService;
    private final RuntimeService runtimeService;


    public NotificationsService(
        MessageSender sender,
        TimeZonesService timeZonesService,
        SupportTopicsService supportTopicsService,
        RuntimeService runtimeService) {

        this.sender = sender;
        this.timeZonesService = timeZonesService;
        this.supportTopicsService = supportTopicsService;
        this.runtimeService = runtimeService;

    }


    // ACCOUNTS

    public void sendWelcomeEmail(String firstName, String lastName, String emailAddress) {

        var tmplVars = Map.of("firstName", firstName);

        sendEmailMessage(
            "welcome",
            Map.of(firstName + " " + lastName, emailAddress),
            "Welcome to Peer Connect",
            welcomeTmplId,
            tmplVars,
            null);
    }

    public void sendForgotPasswordEmail(String email, String token) {

        var tmplVars = Map.of("token", token);

        sendEmailMessage(
            "forgotPassword",
            Map.of("", email),
            "Password Reset Email",
            forgotPwdTmplId,
            tmplVars,
            null);
    }

    public void sendUnsubscribeEmail(String firstName, String lastName, String email) {

        var tmplVars = Map.of("firstName", firstName);

        sendEmailMessage(
            "unsubscribe",
            Map.of(firstName + " " + lastName, email),
            "You have been unsubscribed from Peer Connect",
            unsubscribeTmplId,
            tmplVars,
            null);
    }

    // APPOINTMENTS

    public void sendAppointmentScheduledConfirmation(UUID campaignId, Appointment appointment) {

        var participant = appointment.getParticipant();
        var captain = appointment.getCaptain();
        var topic = appointment.getTopic();
        var apptInstant = appointment.getAvailability().getStartDate();
        var apptDateTime = getOffsetDateTime(
                                apptInstant,
                                timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId()));

        // PARTICIPANT

        // send email

        var tmplVars = Map.of(
                        "appointmentId", appointment.getId().toString(),
                        "firstName", participant.getFirstName(),
                        "captainFirstName", captain.getFirstName(),
                        "captainLastName", captain.getLastName(),
                        "captainTitle", captain.getTitle(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.scheduled",
            participant,
            "Your Appointment is scheduled",
            apptScheduledParticipantTmplId,
            tmplVars,
            null);

        // send text

        sendTextMessage(
            "appointment.scheduled",
            participant,
            "Your Appointment is scheduled at " + apptDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) +
                ". http://lmgtfy.com/?q=scheduled");


        // CAPTAIN

        // send email

        tmplVars = Map.of(
                        "appointmentId", appointment.getId().toString(),
                        "firstName", captain.getFirstName(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.scheduled",
            captain,
            "A New Appointment Scheduled",
            apptScheduledCaptainTmplId,
            tmplVars,
            null);


        // SCHEDULE NOTIFICATIONS

        runtimeService
            .createProcessInstanceBuilder()
            .processDefinitionKey("appointmentRemindersProcess")
            .businessKey(campaignId.toString())
            .variable("appointmentId", appointment.getId())
            .variable("reminderTime1Hour", apptInstant.minus(1, ChronoUnit.HOURS))
            .variable("reminderTime15Mins", apptInstant.minus(15, ChronoUnit.MINUTES))
            .start();

    }

    public void sendAppointmentUnscheduledReminderToParticipants(UUID campaignId, List<Participant> participants) {

        var recipients = participants
                            .stream()
                            .collect(Collectors.toMap(
                                        p -> p.getFirstName() + " " + p.getLastName(),
                                        Participant::getEmailAddress));
        var recipientVars = participants
                                .stream()
                                .collect(Collectors.toMap(
                                            Participant::getEmailAddress,
                                            p -> Map.of("fistName", p.getFirstName())));

        sendEmailMessage(
            "appointment.reminder",
            recipients,
            "You haven't scheduled any appointment",
            apptReminderUnscheduledParticipantTmplId,
            null,
            recipientVars);

    }

    public void sendAppointmentUpcomingReminderToParticipant(
        UUID campaignId, Participant participant, List<Appointment> appointments) {

        var timeZone = timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId());

        var rowTmpl = "<tr>\n" +
            "  <td><b>Appointment Topic</b>: %s</td>\n" +
            "  <td><b>Appointment Date</b>: %s</td>\n" +
            "  <td><b>Appointment Time</b>: %s</td>\n" +
            "  <td><b>Captain</b>: %s %s %s</td>\n" +
            "</tr>\n";
        var appointmentsHtml = new StringBuilder();
        appointmentsHtml.append("<table cellspacing='5' cellpadding='5'>");

        for (var appointment : appointments) {
            var captain = appointment.getCaptain();
            var topic = appointment.getTopic();
            var apptDateTime = getOffsetDateTime(appointment.getAvailability().getStartDate(), timeZone);

            appointmentsHtml.append(
                String.format(
                    rowTmpl,
                    topic.getName(),
                    apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                    apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME),
                    captain.getTitle(),
                    captain.getFirstName(),
                    captain.getLastName()
                ));
        }

        appointmentsHtml.append("</table>");

        var tmplVars = Map.of(
                        "firstName", participant.getFirstName(),
                        "appointments", appointmentsHtml.toString());

        sendEmailMessage(
            "appointment.reminder",
            participant,
            "Your Upcoming Appointment(s)",
            apptReminderUpcomingParticipantTmplId,
            tmplVars,
            null);

    }

    public void sendAppointmentUpcomingReminderToCaptains(UUID campaignId, List<Captain> captains) {

        var recipients = captains
                            .stream()
                            .collect(Collectors.toMap(
                                c -> c.getFirstName() + " " + c.getLastName(),
                                Captain::getEmailAddress));
        var recipientVars = captains
                                .stream()
                                .collect(Collectors.toMap(
                                    Captain::getEmailAddress,
                                    p -> Map.of("fistName", p.getFirstName())));

        sendEmailMessage(
            "appointment.reminder",
            recipients,
            "Your Upcoming Appointment",
            apptReminderUpcomingCaptainTmplId,
            null,
            recipientVars);

    }

    public void sendAppointment1HourReminder(UUID campaignId, Appointment appointment) {

        var participant = appointment.getParticipant();
        var captain = appointment.getCaptain();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId()));

        // PARTICIPANT

        var tmplVars = Map.of(
                        "appointmentId", appointment.getId().toString(),
                        "firstName", participant.getFirstName(),
                        "captainFirstName", captain.getFirstName(),
                        "captainLastName", captain.getLastName(),
                        "captainTitle", captain.getTitle(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.scheduled",
            participant,
            "Your Appointment is scheduled to begin in 1 hour",
            apptReminder1HourParticipantTmplId,
            tmplVars,
            null);

        // CAPTAIN

        tmplVars = Map.of(
            "appointmentId", appointment.getId().toString(),
            "firstName", captain.getFirstName(),
            "apptTopic", topic.getName(),
            "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
            "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.scheduled",
            captain,
            "Your Appointment is scheduled to begin in 1 hour",
            apptReminder1HourCaptainTmplId,
            tmplVars,
            null);

    }

    public void sendAppointment15MinsReminder(UUID campaignId, Appointment appointment) {

        var participant = appointment.getParticipant();
        var captain = appointment.getCaptain();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId()));

        // PARTICIPANT

        var tmplVars = Map.of(
                        "appointmentId", appointment.getId().toString(),
                        "firstName", participant.getFirstName(),
                        "captainFirstName", captain.getFirstName(),
                        "captainLastName", captain.getLastName(),
                        "captainTitle", captain.getTitle(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.scheduled",
            participant,
            "Your Appointment is scheduled to begin in 15 mins",
            apptReminder15MinsParticipantTmplId,
            tmplVars,
            null);

        // CAPTAIN

        tmplVars = Map.of(
            "appointmentId", appointment.getId().toString(),
            "firstName", captain.getFirstName(),
            "apptTopic", topic.getName(),
            "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
            "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.scheduled",
            captain,
            "Your Appointment is scheduled to begin in 15 mins",
            apptReminder15MinsCaptainTmplId,
            tmplVars,
            null);

    }

    public void sendAppointmentOverdueReminder(UUID campaignId, Appointment appointment, ContactMethod contactMethod) {

        var participant = appointment.getParticipant();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId()));


        if (contactMethod == ContactMethod.Both || contactMethod == ContactMethod.Email) {
            var tmplVars = new HashMap<String, String>();
            tmplVars.put("apptTopic", topic.getName());
            tmplVars.put("apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE));
            tmplVars.put("apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

            sendEmailMessage(
                "appointment.reminder",
                participant,
                "Your Appointment is overdue",
                apptReminderOverdueTmplId,
                tmplVars,
                null);
        }

        if (contactMethod == ContactMethod.Both || contactMethod == ContactMethod.SMS) {
            sendTextMessage(
                "appointment.reminder",
                participant,
                "Your Appointment scheduled " + apptDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) + " is overdue");
        }
    }

    public void sendAppointmentCompletedNotification(UUID campaignId, Appointment appointment) {

        var participant = appointment.getParticipant();
        var topic = appointment.getTopic();

        var tmplVars = new HashMap<String, String>();
        tmplVars.put("firstName", participant.getFirstName());
        tmplVars.put("topicId", topic.getId().toString());
        tmplVars.put("topicName", topic.getName());

        sendEmailMessage(
            "appointment.reminder",
            participant,
            "Your Appointment is overdue",
            apptCompletedTmplId,
            tmplVars,
            null);
    }

    public void sendAppointmentCancelledNotificationToParticipant(UUID campaignId, Appointment appointment) {

        var participant = appointment.getParticipant();
        var captain = appointment.getCaptain();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId()));

        // send email

        var tmplVars = Map.of(
                        "firstName", participant.getFirstName(),
                        "captainFirstName", captain.getFirstName(),
                        "captainLastName", captain.getLastName(),
                        "captainTitle", captain.getTitle(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.cancelled",
            participant,
            "Your Appointment has been cancelled by Captain",
            apptCancelledParticipantTmplId,
            tmplVars,
            null);

        // send text

        sendTextMessage(
            "appointment.cancelled",
            participant,
            "Your Appointment scheduled at " + apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) +
                " has been cancelled by the Captain. http://lmgtfy.com/?q=cancelled");

        // UNSCHEDULE NOTIFICATIONS

        var query = runtimeService
                         .createProcessInstanceQuery()
                         .includeProcessVariables()
                         .processDefinitionKey("appointmentRemindersProcess")
                         .processInstanceBusinessKey(campaignId.toString())
                         .variableValueEquals("appointmentId", appointment.getId());

        if (query.count() > 0) {
            var process = query.singleResult();
            runtimeService.deleteProcessInstance(process.getId(), "Appointment Cancelled");
        }

    }

    public void sendAppointmentCancelledNotificationToCaptain(UUID campaignId, Appointment appointment) {

        var captain = appointment.getCaptain();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, captain.getTimeZoneId()));

        // send email

        var tmplVars = Map.of(
                        "firstName", captain.getFirstName(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.cancelled",
            captain,
            "Your Appointment has been cancelled by Participant",
            apptCancelledCaptainTmplId,
            tmplVars,
            null);

        // send text

        sendTextMessage(
            "appointment.cancelled",
            List.of(captain.getMobileNumber()),
            "Your Appointment scheduled at " + apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) +
            " has been cancelled by the Participant. http://lmgtfy.com/?q=cancelled");
    }

    // REQUESTS

    public void sendOffLabelRequest(Appointment appointment, ContactMethod contactMethod) {

        var participant = appointment.getParticipant();

        if (contactMethod == ContactMethod.Both || contactMethod == ContactMethod.Email) {
            var tmplVars = Map.of("firstName", participant.getFirstName());

            sendEmailMessage(
                "appointment.off-label",
                participant,
                "Your Off-Label Request has been answered",
                reqOffLabelTmplId,
                tmplVars,
                null);
        }

        if (contactMethod == ContactMethod.Both || contactMethod == ContactMethod.SMS) {
            sendTextMessage(
                "appointment.off-label",
                participant,
                "Your Off Label Request Answered. http://lmgtfy.com/?q=off-label");
        }
    }

    public void sendSupportRequest(UUID campaignId, UUID supportTopicId, String name, String phone) {

        var supportTopic = supportTopicsService.getByCampaignIdAndId(campaignId, supportTopicId);

        var tmplVars = Map.of(
                        "supportTopic", supportTopic.getName(),
                        "name", name,
                        "phone", phone);

        sendEmailMessage(
            "internal",
            Map.of(adminName, adminEmail),
            "A New Support Request on " + supportTopic.getName(),
            reqSupportTmplId,
            tmplVars,
            null);
    }

    // ADMIN

    public void sendRecapEmail(
        UUID campaignId, Integer newAppointments, Integer completedAppointments,
        Integer noShows, Integer offLabelRequests) {

        var tmplVars = Map.of(
                        "newAppointments", newAppointments.toString(),
                        "completedAppointments", completedAppointments.toString(),
                        "noShows", noShows.toString(),
                        "offLabelRequests", offLabelRequests.toString());

        sendEmailMessage(
            "internal",
            Map.of(adminName, adminEmail),
            "Daily Recap",
            dailyRecapTmplId,
            tmplVars,
            null);
    }

    //

    private void sendEmailMessage(
        String route, Participant participant, String subject, String tmplId,
        Map<String, String> globalVars, Map<String, Map<String, String>> recipientVars) {
        sendEmailMessage(
            route,
            Map.of(participant.getFirstName() + " " + participant.getLastName(), participant.getEmailAddress()),
            subject, tmplId, globalVars, recipientVars);
    }

    private void sendEmailMessage(
        String route, Captain captain, String subject, String tmplId,
        Map<String, String> globalVars, Map<String, Map<String, String>> recipientVars) {
        sendEmailMessage(
            route,
            Map.of(captain.getFirstName() + " " + captain.getLastName(), captain.getEmailAddress()),
            subject, tmplId, globalVars, recipientVars);
    }

    private void sendEmailMessage(
        String route, Map<String, String> recipients, String subject, String tmplId,
        Map<String, String> globalVars, Map<String, Map<String, String>> recipientVars) {

        var msg = new EmailMessage();
        msg.setSenderName(senderName);
        msg.setSenderEmail(senderEmail);
        msg.setRecipients(recipients);
        msg.setSubject(subject);
        msg.setTemplateId(tmplId);
        msg.setGlobalProps(globalVars);
        msg.setRecipientProps(recipientVars);

        sender.send("emails." + route, msg);
    }

    private void sendTextMessage(String route, Participant participant, String content) {
        sendTextMessage(route, List.of(participant.getMobileNumber()), content);
    }

    private void sendTextMessage(String route, List<String> recipients, String content) {

        var msg = new TextMessage();
        msg.setSender(senderPhone);
        msg.setRecipients(recipients);
        msg.setBody(content);

        sender.send("texts." + route, msg);
    }

    private OffsetDateTime getOffsetDateTime(Instant instant, TimeZone timeZone) {
        return instant.atOffset(ZoneOffset.ofHours(timeZone.getUtcOffset()));
    }

}
