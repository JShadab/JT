package com.arches.peerconnect.entities.enums;


/**
 * @author Anurag Mishra, 2018-12-24
 */
public enum ErrorCode {

    E011(400, "Invalid Parameter"),
    E012(400, "One or more fields required for processing is missing."),
    E013(400, "An invalid data type was submitted."),
    E014(400, "An incorrect date format was passed."),
    E015(400, "A field length validation failed."),
    E016(400, "Duplicate Enrollment or User already exists in the system for this program."),
    E017(400, "A non-numeric value was passed for a field which only accepts numeric values."),
    E018(400, "The patient failed our standard eligibility checks and is not eligible to enroll into the program. No further enrollment action should be allowed with this patient."),
    E019(400, "Invalid AvailabilityID passed"),
    E020(400, "Invalid AppointmentID passed"),
    E021(400, "Invalid ParticipantID passed"),
    E022(400, "Invalid CaptainID passed"),
    E023(400, "Invalid AdminID passed"),
    E024(400, "Invalid TopicID passed"),
    E025(400, "Invalid FolderID passed"),
    E026(400, "Invalid ResourceID passed"),
    E027(400, "Invalid ContentType passed"),
    E028(400, "Invalid ContactMethod passed"),
    E029(400, "Invalid SpecialityID passed"),
    E030(400, "Invalid SupportTopicID passed"),
    E031(400, "Invalid RoleID passed"),
    E032(400, "Invalid TimeZoneID passed"),
    E033(400, "Invalid SegmentID passed"),
    E034(400, "Invalid ProgramID passed"),
    E035(400, "Invalid TenantID passed"),
    E036(400, "Invalid ParentID passed"),
    E037(400, "Invalid Email or Password"),
    E038(400, "User has registered with invalid email address"),
    E039(401, "Token Expired for login"),
    E040(400, "Maximum number of sessions exceeded by Captain"),
    E041(400, "Maximum number of sessions exceeded by Patient"),
    E042(400, "Limit of number of sessions for a topic exceeded by Patient"),
    E043(400, "Session already marked complete"),

    E401(401, "Authentication Required"),
    E404(404, "Not Found"),
    E500(500, "System Error"),

    S200(200, "Successful");

    //
    private final int statusCode;

    private final String description;

    ErrorCode(int statusCode, String description) {
        this.statusCode = statusCode;
        this.description = description;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public String getDescription() {
        return description;
    }

    public String getFullMessage() {
        return String.format("%s: %s", this.toString(), description);
    }

}
