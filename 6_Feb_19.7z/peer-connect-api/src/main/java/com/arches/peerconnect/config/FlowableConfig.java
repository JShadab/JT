package com.arches.peerconnect.config;


import com.arches.peerconnect.entities.enums.Level;
import com.arches.peerconnect.services.ParentsService;

import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;


/**
 * @author Anurag Mishra, 2019-01-27
 */
@Configuration
public class FlowableConfig {

    private final ParentsService parentsService;
    private final RepositoryService repositoryService;
    private final RuntimeService runtimeService;

    public FlowableConfig(ParentsService parentsService, RepositoryService repositoryService, RuntimeService runtimeService) {
        this.parentsService = parentsService;
        this.repositoryService = repositoryService;
        this.runtimeService = runtimeService;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void deployProcesses() {

        // Test Deployments
        var deploys = repositoryService.createDeploymentQuery().list();
        System.out.println("DEPLOYMENTS: " + deploys);


        var processes = repositoryService.createProcessDefinitionQuery().list();
        System.out.println("PROCESSES: " + processes);

        // Initialize BPM Processes for campaigns
        var campaigns = parentsService.getAllByLevel(Level.Campaign);

        for (var campaign : campaigns) {
            var campaignId = campaign.getId().toString();
            var process = runtimeService.createProcessInstanceQuery()
                                        .processDefinitionKey("dailyUpdatesProcess")
                                        .processInstanceBusinessKey(campaignId);

            if (process.count() < 1)
                runtimeService.createProcessInstanceBuilder()
                              .processDefinitionKey("dailyUpdatesProcess")
                              .businessKey(campaignId)
                              .start();
        }
    }

}
