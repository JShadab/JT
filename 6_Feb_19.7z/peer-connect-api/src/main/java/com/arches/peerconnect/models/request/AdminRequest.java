package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.Admin;
import com.arches.peerconnect.models.request.base.RequestModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Value;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


/**
 * @author Anurag Mishra, 2018-12-27
 */
@Value
@EqualsAndHashCode
public class AdminRequest implements RequestModel<Admin> {

    @NotEmpty
    @ApiModelProperty(notes="First name", required = true)
    private String firstName;

    @NotEmpty
    @ApiModelProperty(notes="Lase name", required = true)
    private String lastName;

    @NotEmpty
    @Email
    @ApiModelProperty(notes="Email", required = true)
    private String emailAddress;

    @NotEmpty
    @ApiModelProperty(notes="Password", required = true)
    private String password;

    @NotEmpty
    @ApiModelProperty(notes="Phone number", required = true)
    private String phoneNumber;

    @NotNull
    @ApiModelProperty(notes="Is active")
    private Boolean isActive;

    @Override
    public void mapToEntity(Admin entity) {
        entity.setFirstName(getFirstName());
        entity.setLastName(getLastName());
        entity.setEmailAddress(getEmailAddress());
        entity.setPassword(getPassword());
        entity.setPhoneNumber(getPhoneNumber());
        entity.setIsActive(getIsActive());
    }

    @Override
    public Admin createNew() {
        var admin = new Admin();
        mapToEntity(admin);
        return admin;
    }

}
