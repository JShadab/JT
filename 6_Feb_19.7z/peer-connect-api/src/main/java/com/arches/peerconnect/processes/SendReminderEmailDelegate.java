package com.arches.peerconnect.processes;


import com.arches.peerconnect.services.AppointmentsService;
import com.arches.peerconnect.services.CaptainsService;
import com.arches.peerconnect.services.NotificationsService;
import com.arches.peerconnect.services.ParticipantsService;

import org.flowable.engine.delegate.JavaDelegate;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-25
 */
@Component
public class SendReminderEmailDelegate {

    private final ParticipantsService participantsService;
    private final CaptainsService captainsService;
    private final AppointmentsService appointmentsService;
    private final NotificationsService notificationsService;

    public SendReminderEmailDelegate(
        ParticipantsService participantsService,
        CaptainsService captainsService,
        AppointmentsService appointmentsService,
        NotificationsService notificationsService) {

        this.participantsService = participantsService;
        this.captainsService = captainsService;
        this.appointmentsService = appointmentsService;
        this.notificationsService = notificationsService;

    }

    //

    @Bean
    public JavaDelegate sendAppointment1HourReminderEmail() {
        return execution -> {
            var campaignId = UUID.fromString(execution.getProcessInstanceBusinessKey());
            var appointmentId = execution.getVariable("appointmentId", UUID.class);
            var appointment = appointmentsService.getByCampaignIdAndId(campaignId, appointmentId);
            notificationsService.sendAppointment1HourReminder(campaignId, appointment);
        };
    }

    @Bean
    public JavaDelegate sendAppointment15MinsReminderEmail() {
        return execution -> {
            var campaignId = UUID.fromString(execution.getProcessInstanceBusinessKey());
            var appointmentId = execution.getVariable("appointmentId", UUID.class);
            var appointment = appointmentsService.getByCampaignIdAndId(campaignId, appointmentId);
            notificationsService.sendAppointment15MinsReminder(campaignId, appointment);
        };
    }

    @Bean
    public JavaDelegate sendSchedulingReminderEmail() {
        return execution -> {
            var campaignId = UUID.fromString(execution.getProcessInstanceBusinessKey());
            var participants = participantsService.getAllUnscheduledParticipants(campaignId);

            if (participants.size() > 0)
                notificationsService.sendAppointmentUnscheduledReminderToParticipants(campaignId, participants);
        };
    }

    @Bean
    public JavaDelegate sendUpcomingReminderEmailToParticipants() {
        return execution -> {
            var campaignId = UUID.fromString(execution.getProcessInstanceBusinessKey());
            var participants = participantsService.getAllWithUpcomingAppointments(campaignId);

            for (var participant : participants) {
                var appointments = appointmentsService.getAllUpcomingByCampaignAndParticipant(campaignId, participant.getId());
                notificationsService.sendAppointmentUpcomingReminderToParticipant(campaignId, participant, appointments);
            }
        };
    }

    @Bean
    public JavaDelegate sendUpcomingReminderEmailToCaptains() {
        return execution -> {
            var campaignId = UUID.fromString(execution.getProcessInstanceBusinessKey());
            var captains = captainsService.getAllWithUpcomingAppointments(campaignId);

            if (captains.size() > 0)
                notificationsService.sendAppointmentUpcomingReminderToCaptains(campaignId, captains);
        };
    }

    @Bean
    public JavaDelegate sendRecapEmailToAdmin() {
        return execution -> {
            var campaignId = UUID.fromString(execution.getProcessInstanceBusinessKey());
            var newAppts = appointmentsService.getCountOfNewAppointments(campaignId);
            var completed = appointmentsService.getCountOfCompletedAppointments(campaignId);
            var noShows = appointmentsService.getCountOfNoShows(campaignId);
            var offLabels = appointmentsService.getCountOfOffLabelRequests(campaignId);

            notificationsService.sendRecapEmail(campaignId, newAppts, completed, noShows, offLabels);
        };
    }

}
