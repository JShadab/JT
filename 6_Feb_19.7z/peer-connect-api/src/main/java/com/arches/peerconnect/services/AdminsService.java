package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.Admin;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.enums.OpCode;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.request.AdminRequest;
import com.arches.peerconnect.repos.AdminsRepository;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.services.base.EntityService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;


/**
 * @author Anurag Mishra, 2018-12-27
 */
@Service
public class AdminsService extends EntityService<Admin> {

    private final AdminsRepository adminsRepository;
    private final ParentsRepository parentsRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminsService(
        AdminsRepository adminsRepository,
        ParentsRepository parentsRepository,
        PasswordEncoder passwordEncoder) {

        super(adminsRepository, ErrorCode.E023);

        this.adminsRepository = adminsRepository;
        this.parentsRepository = parentsRepository;
        this.passwordEncoder = passwordEncoder;

    }

    public List<Admin> getAllByCampaignId(UUID campaignId) {
        return adminsRepository
                   .getAllByParent_Id(campaignId);
    }

    public Admin getByCampaignIdAndId(UUID campaignId, UUID adminId) {
        return adminsRepository
                   .getByParent_IdAndId(campaignId, adminId)
                   .orElseThrow(() -> new ApiException(ErrorCode.E023));
    }

    public Admin create(UUID campaignId, AdminRequest request) {
        return super.create(campaignId, request, admin -> {
            admin.setParent(parentsRepository.getOne(campaignId));
            admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        });
    }

    public void update(UUID adminId, AdminRequest request) {

        final var oldPassword = new AtomicReference<String>();

        super.update(
            adminId,
            request,
            admin -> oldPassword.set(admin.getPassword()),
            admin -> {
                if (!request.getPassword().equals(oldPassword.get()))
                    admin.setPassword(passwordEncoder.encode(admin.getPassword()));
            });
    }

    public void changeStatus(UUID campaignId, UUID adminId, Boolean active) {
        var admin = getByCampaignIdAndId(campaignId, adminId);
        admin.setIsActive(active);

        adminsRepository.save(admin);

        var payload = new Object() { public Boolean isActive = active; };
        addAuditTrail(campaignId, adminId, admin.getClass().getSimpleName(), OpCode.UPDATED, payload);
    }

}
