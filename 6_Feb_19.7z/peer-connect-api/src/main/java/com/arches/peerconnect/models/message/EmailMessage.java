package com.arches.peerconnect.models.message;


import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import java.util.Map;


/**
 * @author Anurag Mishra, 2019-01-16
 */
@Data
public class EmailMessage {

    @NotBlank
    private String senderName;
    @NotBlank
    private String senderEmail;

    @NotEmpty
    private Map<String, String> recipients;

    @NotBlank
    private String subject;

    private Map<String, String> attachments;

    @NotBlank
    private String templateId;

    private Map<String, String> globalProps;
    private Map<String, Map<String, String>> recipientProps;

    private Map<String, String> contentProps;

}
