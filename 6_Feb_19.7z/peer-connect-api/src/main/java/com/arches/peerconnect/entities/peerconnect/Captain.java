package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.base.PeerConnectEntity;
import com.arches.peerconnect.utils.CommonUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import org.hibernate.annotations.Type;

import org.springframework.data.annotation.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Immutable
@Table(name = "PC_Captains")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Captain extends PeerConnectEntity {

    @Column(columnDefinition = "nvarchar")
    private String firstName;

    @Column(columnDefinition = "nvarchar")
    private String lastName;

    @Column(columnDefinition = "nvarchar")
    private String title;

    @Column(columnDefinition = "nvarchar")
    private String emailAddress;

    @Column(columnDefinition = "nvarchar")
    @JsonIgnore
    private String password;

    @Column(columnDefinition = "nvarchar")
    private String mobileNumber;

    @Column(columnDefinition = "nvarchar")
    private String addressLine1;

    @Column(columnDefinition = "nvarchar")
    private String addressLine2;

    @Column(columnDefinition = "nvarchar")
    private String city;

    @Column(columnDefinition = "nvarchar")
    private String state;

    @Column(columnDefinition = "nvarchar")
    private String zipCode;

    @Column(columnDefinition = "nvarchar")
    private String profileImageUrl;

    @Column(columnDefinition = "nvarchar")
    private String biography;

    private Boolean optIn;

    private Boolean terms;

    private Boolean unsubscribed;

    @Column(columnDefinition = "uniqueidentifier")
    @Type(type = "uuid-char")
    private UUID mediaSourceId;

    @Column(columnDefinition = "uniqueidentifier")
    @Type(type = "uuid-char")
    private UUID affiliationId;

    @Column(columnDefinition = "nvarchar")
    @JsonIgnore
    private String roleIdsList;

    @Column(columnDefinition = "nvarchar")
    @JsonIgnore
    private String segmentIdsList;

    @Column(columnDefinition = "uniqueidentifier")
    @Type(type = "uuid-char")
    private UUID specialityId;

    @Column(columnDefinition = "uniqueidentifier")
    @Type(type = "uuid-char")
    private UUID timeZoneId;

    @Column(columnDefinition = "nvarchar")
    @JsonIgnore
    private String topicIdsList;

    //

    @JsonProperty("roleId")
    public List<UUID> getRoleIds() {
        return roleIdsList != null ? CommonUtils.convertToUUIDList(roleIdsList) : null;
    }

    @JsonProperty("segmentId")
    public List<UUID> getSegmentIds() {
        return segmentIdsList != null ? CommonUtils.convertToUUIDList(segmentIdsList) : null;
    }

    @JsonProperty("topicId")
    public List<UUID> getTopicIds() {
        return topicIdsList != null ? CommonUtils.convertToUUIDList(topicIdsList) : null;
    }

}
