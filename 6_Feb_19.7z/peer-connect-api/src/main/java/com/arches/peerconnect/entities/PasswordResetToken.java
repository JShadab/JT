package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.Auditable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import org.hibernate.annotations.Type;

import javax.persistence.*;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-21
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(force = true)
@Entity
@Table(name = "PasswordResetTokens")
public class PasswordResetToken extends Auditable {

    private static final int EXPIRATION = 12;

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uniqueidentifier", nullable = false)
    private UUID campaignId;

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uniqueidentifier", nullable = false)
    private UUID userId;

    private String token;

    private Instant expiration;


    public PasswordResetToken(final UUID campaignId, final UUID userId, final String token) {
        this.campaignId = campaignId;
        this.userId = userId;
        this.token = token;

        calculateExpiration();
    }

    public void updateToken(final String token) {
        this.token = token;

        calculateExpiration();
    }

    public Boolean isExpired() {
        return Instant.now().isAfter(expiration);
    }

    private void calculateExpiration() {
        expiration = Instant.now().plus(EXPIRATION, ChronoUnit.HOURS);
    }

}
