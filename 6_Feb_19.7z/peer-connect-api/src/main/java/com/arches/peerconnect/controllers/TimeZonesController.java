package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.TimeZone;

import com.arches.peerconnect.models.request.TimeZoneRequest;
import com.arches.peerconnect.services.TimeZonesService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@RestController
@RequestMapping("/timeZones")
@Api(value="Time Zone", description="Time Zone")
public class TimeZonesController extends PeerConnectBaseController<TimeZone> {

    public TimeZonesController(TimeZonesService service) {
        super(service);
    }

    //

    @PostMapping("")
    @ApiOperation(value = "Create time zone")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody TimeZoneRequest request) {

        return super.create(tenantId, request);

    }

    @PutMapping("")
    @ApiOperation(value = "Update time zone")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody TimeZoneRequest request) {

        return super.update(entityId, request);

    }

}
