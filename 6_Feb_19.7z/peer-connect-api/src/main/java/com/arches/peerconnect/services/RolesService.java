package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.Role;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.RolesRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@Service
public class RolesService extends PeerConnectEntityService<Role> {

    public RolesService(
        RolesRepository rolesRepository,
        ParentsRepository parentsRepository) {

        super(rolesRepository, parentsRepository, ErrorCode.E031);

    }

}
