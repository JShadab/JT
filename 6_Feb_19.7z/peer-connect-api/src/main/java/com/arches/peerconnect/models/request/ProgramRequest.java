package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.Program;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import java.time.Instant;


/**
 * @author Anurag Mishra, 2018-12-26
 */
@Data
public class ProgramRequest implements RequestModel<Program> {

    @NotEmpty
    private String name;

    @NotNull
    private Instant startDate;

    @NotNull
    private Instant endDate;

    @NotNull
    private int sessionDuration;

    @NotNull
    private int maxCaptainSessions;

    @NotNull
    private int maxParticipantSessions;

    @NotEmpty
    @Email
    private String supportEmail;

    //

    @Override
    public void mapToEntity(Program entity) {
        entity.setName(getName());
        entity.setStartDate(getStartDate());
        entity.setEndDate(getEndDate());
        entity.setSessionDuration(getSessionDuration());
        entity.setMaxCaptainSessions(getMaxCaptainSessions());
        entity.setMaxParticipantSessions(getMaxParticipantSessions());
        entity.setSupportEmail(getSupportEmail());
    }

    @Override
    public Program createNew() {
        var program = new Program();
        mapToEntity(program);
        return program;
    }
}
