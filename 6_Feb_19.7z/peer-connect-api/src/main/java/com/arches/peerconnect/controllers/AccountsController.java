package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.BaseController;
import com.arches.peerconnect.services.AccountsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-20
 */
@Api(value="Account", description="Account")
@RestController
public class AccountsController extends BaseController {

    private final AccountsService accountsService;

    public AccountsController(AccountsService accountsService) {
        this.accountsService = accountsService;
    }

    //
    @ApiOperation(value = "Validate user then send's password reset email")
    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(
        @RequestHeader("Tenant-ID") UUID campaignId,
        @RequestParam("email") String email) {

        accountsService.forgotPassword(campaignId, email);

        return okResponse();
    }
    @ApiOperation(value = "Set new password")
    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(
        @RequestHeader("Tenant-ID") UUID campaignId,
        @RequestParam("token") String token,
        @RequestParam("password") String password) {

        accountsService.resetPassword(campaignId, token, password);

        return okResponse();
    }
    @ApiOperation(value = "Unsubscribe user")
    @PostMapping("/unsubscribe")
    public ResponseEntity<?> unsubscribe(
        @RequestHeader("Tenant-ID") UUID campaignId,
        @RequestParam("email") String email) {

        accountsService.unsubscribe(campaignId, email);

        return okResponse();
    }

}
