package com.arches.peerconnect.models.message;


import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import java.util.List;


/**
 * @author Anurag Mishra, 2019-01-17
 */
@Data
public class TextMessage {

    @NotBlank
    private String sender;
    @NotEmpty
    private List<String> recipients;

    @NotBlank
    private String body;

}
