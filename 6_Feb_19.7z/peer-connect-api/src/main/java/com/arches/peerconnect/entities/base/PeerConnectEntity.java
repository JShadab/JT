package com.arches.peerconnect.entities.base;


import com.arches.peerconnect.entities.Parent;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-27
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@MappedSuperclass
public class PeerConnectEntity extends Auditable {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "campaignId")
    @JsonIgnore
    protected Parent campaign;

    //

    @JsonIgnore
    public UUID getCampaignId() {
        return campaign.getId();
    }

}
