package com.arches.peerconnect.messaging.receivers;


import com.arches.peerconnect.models.message.TextMessage;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Value;


/**
 * @author Anurag Mishra, 2019-01-16
 */
@Slf4j
public class TextsReceiver {

    @Value("app.twilio.accountSid")
    private String accountSid;
    @Value("app.twilio.authToken")
    private String authToken;


    @RabbitListener(queues = "#{textsQueue.name}")
    public void receive(final TextMessage msg) {

        log.info("Text Receiver received message: {}", msg);

        Twilio.init(accountSid, authToken);

        for (var to : msg.getRecipients()) {
            log.info("Sending text to {}: {}", to, msg.getBody());
            var result = Message
                            .creator(new PhoneNumber(to), new PhoneNumber(msg.getSender()), msg.getBody())
                            .create();

            log.info("Text status for {}: {} [{}]", result.getTo(), result.getDateSent(), result.getErrorMessage());
        }

    }

}
