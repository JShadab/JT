package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.Affiliation;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotEmpty;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Data
public class AffiliationRequest implements RequestModel<Affiliation> {

    @NotEmpty
    private String name;

    //

    @Override
    public void mapToEntity(Affiliation entity) {
        entity.setName(getName());
    }

    @Override
    public Affiliation createNew() {
        var entity = new Affiliation();
        mapToEntity(entity);
        return entity;
    }

}
