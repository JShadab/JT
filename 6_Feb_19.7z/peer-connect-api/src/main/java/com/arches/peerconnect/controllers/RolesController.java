package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Role;
import com.arches.peerconnect.models.request.RoleRequest;
import com.arches.peerconnect.services.RolesService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@RestController
@RequestMapping("/roles")
@PreAuthorize("hasRole('ADMIN')")
@Api(value="Role", description="Role")
public class RolesController extends PeerConnectBaseController<Role> {

    public RolesController(RolesService service) {
        super(service);
    }

    //

    @PostMapping("")
    @ApiOperation(value = "Create role")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody RoleRequest request) {

        return super.create(tenantId, request);

    }

    @PutMapping("")
    @ApiOperation(value = "update role")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody RoleRequest request) {

        return super.update(entityId, request);

    }

}
