package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.Parent;

import com.arches.peerconnect.entities.enums.Level;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-26
 */
public interface ParentsRepository extends JpaRepository<Parent, UUID> {

    List<Parent> findAllByLevel(Level level);

    List<Parent> findAllByParent_Id(UUID parentId);

}
