package com.arches.peerconnect.entities.enums;


/**
 * @author Anurag Mishra, 2019-01-13
 */
public enum OpCode {

    CREATED,
    UPDATED,
    ARCHIVED,
    UNARCHIVED,

    FORGOTPASSWORD,
    RESETPASSWORD,
    UNSUBSCRIBED,
    RESUBSCRIBED

}
