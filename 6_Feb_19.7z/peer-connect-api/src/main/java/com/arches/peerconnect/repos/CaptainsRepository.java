package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Captain;
import com.arches.peerconnect.repos.base.PeerConnectRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-31
 */
public interface CaptainsRepository extends PeerConnectRepository<Captain> {

    Optional<Captain> getByCampaign_IdAndEmailAddress(UUID campaignId, String emailAddress);

    @Query(
        value =
            "WITH MaxCnt AS (\n" +
            "  SELECT maxCaptainSessions FROM PC_Programs WHERE campaignId = :campaignId\n" +
            "),\n" +
            "ExhaustedCaptains AS (\n" +
            "  SELECT   captainId\n" +
            "  FROM     PC_Appointments\n" +
            "  WHERE    topicId = :topicId\n" +
            "  GROUP BY captainId, topicId\n" +
            "  HAVING   COUNT(captainId) >= (SELECT TOP 1 maxCaptainSessions FROM MaxCnt)\n" +
            ")\n" +
            "SELECT * FROM PC_Captains WHERE id NOT IN (SELECT captainId FROM ExhaustedCaptains)",
        nativeQuery = true
    )
    List<Captain> getAvailableCaptainsByTopic(UUID campaignId, UUID topicId);

    @Query(
        value =
            "SELECT c.*\n" +
            "FROM   PC_Captains c\n" +
            "WHERE  c.campaignId = ?1\n" +
            "  AND  EXISTS(\n" +
            "           SELECT  ap.id\n" +
            "           FROM    PC_Appointments ap\n" +
            "                   LEFT JOIN PC_Availabilities av ON ap.availabilityId = av.id\n" +
            "           WHERE   ap.captainId = c.id\n" +
            "             AND   DATEDIFF(d, SYSUTCDATETIME(), av.startDate) BETWEEN 0 AND 1)",
        nativeQuery = true
    )
    List<Captain> getAllWithUpcomingAppointments(UUID campaignId);

}
