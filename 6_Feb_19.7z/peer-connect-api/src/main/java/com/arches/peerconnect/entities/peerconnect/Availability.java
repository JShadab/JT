package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.Enrollment;
import com.arches.peerconnect.entities.base.PeerConnectEntity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.time.Instant;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-31
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_Availabilities")
public class Availability extends PeerConnectEntity {

    @Column(nullable = false)
    private Instant startDate;


    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "captainId")
    @JsonIgnore
    private Enrollment captain;

    //

    @JsonProperty("captainId")
    public UUID getCaptainId() {
        return captain.getId();
    }

}
