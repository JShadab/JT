package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.Speciality;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.SpecialitiesRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@Service
public class SpecialitiesService extends PeerConnectEntityService<Speciality> {

    public SpecialitiesService(
        SpecialitiesRepository specialitiesRepository,
        ParentsRepository parentsRepository) {

        super(specialitiesRepository, parentsRepository, ErrorCode.E029);

    }

}
