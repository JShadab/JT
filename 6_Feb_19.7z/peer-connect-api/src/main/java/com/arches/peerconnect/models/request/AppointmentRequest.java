package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.Appointment;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotNull;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
@Data
public class AppointmentRequest implements RequestModel<Appointment> {

    @NotNull
    private UUID availabilityId;

    @NotNull
    private UUID captainId;

    @NotNull
    private UUID participantId;

    @NotNull
    private UUID topicId;

    //

    @Override
    public void mapToEntity(Appointment entity) {
        // nothing to map since every property is either a foreignId
        // or will be set at a later date
    }

    @Override
    public Appointment createNew() {
        var entity = new Appointment();
        mapToEntity(entity);
        return entity;
    }
}
