package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Participant;
import com.arches.peerconnect.repos.base.PeerConnectRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-31
 */
public interface ParticipantsRepository extends PeerConnectRepository<Participant> {

    Optional<Participant> getByCampaign_IdAndEmailAddress(UUID campaignId, String email);

    @Query(
        value =
            "WITH UnscheduledParticipants AS (\n" +
            "  SELECT   p.id\n" +
            "  FROM     PC_Participants p\n" +
            "           LEFT JOIN PC_Appointments ap ON ap.participantId = p.id\n" +
            "           LEFT JOIN PC_Availabilities av ON ap.availabilityId = av.id\n" +
            "  WHERE    p.campaignId = ?1\n" +
            "  GROUP BY p.id, av.startDate\n" +
            "  HAVING DATEDIFF(d, MAX(av.startDate), SYSUTCDATETIME()) >= 7\n" +
            ")\n" +
            "SELECT * FROM PC_Participants WHERE id IN (SELECT id FROM UnscheduledParticipants)",
        nativeQuery = true
    )
    List<Participant> getAllUnscheduledParticipants(UUID campaignId);

    @Query(
        value =
            "SELECT p.*\n" +
            "FROM   PC_Participants p\n" +
            "WHERE  p.campaignId = ?1\n" +
            "  AND  EXISTS(\n" +
            "           SELECT  ap.id\n" +
            "           FROM    PC_Appointments ap\n" +
            "                   LEFT JOIN PC_Availabilities av ON ap.availabilityId = av.id\n" +
            "           WHERE   ap.participantId = p.id\n" +
            "             AND   DATEDIFF(d, SYSUTCDATETIME(), av.startDate) BETWEEN 0 AND 1)",
        nativeQuery = true
    )
    List<Participant> getAllWithUpcomingAppointments(UUID campaignId);

}
