package com.arches.peerconnect.repos.base;


import com.arches.peerconnect.entities.base.PeerConnectEntity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.List;
import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@NoRepositoryBean
public interface PeerConnectRepository<T extends PeerConnectEntity> extends JpaRepository<T, UUID> {

    List<T> getAllByCampaign_Id(UUID campaignId);

    Optional<T> getByCampaign_IdAndId(UUID campaignId, UUID entityId);

}
