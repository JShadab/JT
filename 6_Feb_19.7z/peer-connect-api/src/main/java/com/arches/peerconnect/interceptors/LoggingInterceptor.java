package com.arches.peerconnect.interceptors;


import lombok.extern.slf4j.Slf4j;

import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * @author Anurag Mishra, 2018-12-26
 */
@Slf4j
public class LoggingInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        var principal = request.getUserPrincipal();
        var user = principal != null ? principal.getName() : "anon";

        log.info(
            "INCOMING {} REQUEST FROM {} :: {}{}",
            request.getMethod(), user, request.getRequestURI(), getParameters(request));

        return true;
    }

    private String getParameters(HttpServletRequest request) {
        var postData = new StringBuilder();
        var paramNames = request.getParameterNames();

        if (paramNames != null) {
            postData.append("?");

            while (paramNames.hasMoreElements()) {
                if (postData.length() > 1)
                    postData.append("&");

                var curr = (String) paramNames.nextElement();
                postData
                    .append(curr)
                    .append("=")
                    .append(isPassword(curr) ? "******" : request.getParameter(curr));
            }
        }

        var ipAddr = getRemoteAddr(request);
        if (ipAddr != null && !ipAddr.equals("")) {
            postData.append(postData.length() > 1 ? "&" : "")
                    .append("_reqIp=")
                    .append(ipAddr);
        }

        return postData.toString();
    }

    private String getRemoteAddr(HttpServletRequest request) {

        var ipFromHeader = request.getHeader("X-FORWARDED-FOR");
        if (ipFromHeader != null && ipFromHeader.length() > 0) {
            log.debug("IP from Proxy - X-FORWARDED-FOR : " + ipFromHeader);
            return ipFromHeader;
        }

        return request.getRemoteAddr();

    }

    private boolean isPassword(String param) {

        return param.contains("password") ||
               param.contains("pass") ||
               param.contains("pwd");

    }
}
