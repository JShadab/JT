package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.base.Auditable;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

import lombok.EqualsAndHashCode;
import org.hibernate.annotations.Type;

import org.springframework.data.annotation.Immutable;

import javax.persistence.*;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Immutable
@Table(name = "PC_Users")
public class User extends Auditable {

    @Type(type = "uuid-char")
    @Column(columnDefinition = "uniqueidentifier")
    private UUID campaignId;

    @Column(columnDefinition = "nvarchar")
    private String emailAddress;

    @Column(columnDefinition = "nvarchar")
    @JsonIgnore
    private String password;

    private Boolean isActive;

    @Column(columnDefinition = "nvarchar")
    @JsonIgnore
    private String rolesList;

    //

    @JsonProperty("roles")
    public List<String> getRoles() {
        return Arrays.asList(rolesList.split(","));
    }

}
