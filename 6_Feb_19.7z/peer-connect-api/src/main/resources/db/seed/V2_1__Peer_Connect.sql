-- ROLES

INSERT INTO [dbo].[PC_Roles]
  (campaignId, name)
VALUES
  ('3723137b-9674-4892-a883-c3eefd67d367', 'MD/DO'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'DMD'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'DDS'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'PharmD/RPh'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'PA'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'CRNA/NP/APRN'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'RN'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'Other');

-- PROGRAMS

INSERT INTO [dbo].[PC_Programs]
  (campaignId, name, startDate, endDate, sessionDuration, maxCaptainSessions, maxParticipantSessions, supportEmail)
VALUES
  ('3723137b-9674-4892-a883-c3eefd67d367', 'Knowledge Exchange', SYSUTCDATETIME(), DATEADD(q, 1, SYSUTCDATETIME()), 30, 30, 3, 'support@ke.dps.com')

-- SURVEYS

INSERT INTO Surveys (campaignId, name, isEnrollment)
VALUES ('3723137b-9674-4892-a883-c3eefd67d367', 'Knowledge Exchange - Enrollment Survey', 1)
