---------- [ T A B L E S ] ----------

-- PROGRAMS

CREATE TABLE [dbo].[PC_Programs] (
  [id]                     UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]             UNIQUEIDENTIFIER NOT NULL,

  [name]                   VARCHAR(255)     NOT NULL,
  [startDate]              DATETIME2        NOT NULL,
  [endDate]                DATETIME2        NOT NULL,
  [sessionDuration]        INT              NOT NULL,
  [maxCaptainSessions]     INT              NOT NULL,
  [maxParticipantSessions] INT              NOT NULL,
  [supportEmail]           VARCHAR(255)     NOT NULL,
  [isArchived]             BIT              NOT NULL DEFAULT (0),

  [createdBy]              UNIQUEIDENTIFIER     NULL,
  [createdOn]              DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]             UNIQUEIDENTIFIER     NULL,
  [modifiedOn]             DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Programs]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Programs_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Programs_Campaign] ON [dbo].[PC_Programs] ( [campaignId] ASC )
GO

-- SUPPORT TOPICS

CREATE TABLE [dbo].[PC_SupportTopics] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_SupportTopics]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_SupportTopicsCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_SupportTopicsCampaign] ON [dbo].[PC_SupportTopics] ( [campaignId] ASC )
GO

-- TIME ZONES

CREATE TABLE [dbo].[PC_TimeZones] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]   UNIQUEIDENTIFIER NOT NULL,

  [label]        VARCHAR(255)     NOT NULL,
  [abbr]         VARCHAR(5)       NOT NULL,
  [utcOffset]    INT              NOT NULL,
  [dstOffset]    INT              NOT NULL,
  [isArchived]   BIT              NOT NULL DEFAULT (0),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_TimeZones]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_TimeZonesCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_TimeZonesCampaign] ON [dbo].[PC_TimeZones] ( [campaignId] ASC )
GO

-- SPECIALITIES

CREATE TABLE [dbo].[PC_Specialities] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Specialities]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Specialities_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Specialities_Campaign] ON [dbo].[PC_Specialities] ( [campaignId] ASC )
GO

-- SEGMENTS

CREATE TABLE [dbo].[PC_Segments] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Segments]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Segments_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Segments_Campaign] ON [dbo].[PC_Segments] ( [campaignId] ASC )
GO

-- AFFILIATIONS

CREATE TABLE [dbo].[PC_Affiliations] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Affiliations]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Affiliations_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Affiliations_Campaign] ON [dbo].[PC_Affiliations] ( [campaignId] ASC )
GO

-- ROLES

CREATE TABLE [dbo].[PC_Roles] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Roles]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Roles_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Roles_Campaign] ON [dbo].[PC_Roles] ( [campaignId] ASC )
GO

-- TOPICS

CREATE TABLE [dbo].[PC_Topics] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Topics]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Topics_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Topics_Campaign] ON [dbo].[PC_Topics] ( [campaignId] ASC )
GO

-- RESOURCE FOLDERS

CREATE TABLE [dbo].[PC_ResourceFolders] (
  [id]             UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]     UNIQUEIDENTIFIER NOT NULL,
  [topicId]        UNIQUEIDENTIFIER     NULL,
  [featResourceId] UNIQUEIDENTIFIER     NULL,

  [name]           VARCHAR(255)     NOT NULL,
  [isRestricted]   BIT              NOT NULL DEFAULT (0),
  [isArchived]     BIT              NOT NULL DEFAULT (0),

  [createdBy]      UNIQUEIDENTIFIER     NULL,
  [createdOn]      DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]     UNIQUEIDENTIFIER     NULL,
  [modifiedOn]     DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_ResourceFolders]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_ResourceFolders_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_PC_ResourceFolders_Topic]    FOREIGN KEY ([topicId])     REFERENCES [dbo].[PC_Topics]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourceFolders_Campaign] ON [dbo].[PC_ResourceFolders] ( [campaignId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourceFolders_Topic] ON [dbo].[PC_ResourceFolders] ( [topicId] ASC )
GO

-- RESOURCES

CREATE TABLE [dbo].[PC_Resources] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]   UNIQUEIDENTIFIER NOT NULL,
  [folderId]     UNIQUEIDENTIFIER NOT NULL,

  [name]         VARCHAR(255)     NOT NULL,
  [description]  VARCHAR(MAX)     NOT NULL,
  [contentType]  INT              NOT NULL,                     -- PDF | VIDEO | ...
  [absoluteUrl]  VARCHAR(MAX)     NOT NULL,
  [thumbnailUrl] VARCHAR(MAX)     NOT NULL,
  [isArchived]   BIT              NOT NULL DEFAULT (0),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Resources]                PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Resources_Campaign]       FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_PC_Resources_ResourceFolder] FOREIGN KEY ([folderId])    REFERENCES [dbo].[PC_ResourceFolders]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Resources_Campaign] ON [dbo].[PC_Resources] ( [campaignId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Resources_ResourceFolder] ON [dbo].[PC_Resources] ( [folderId] ASC )
GO

-- RESOURCE RATINGS

CREATE TABLE [dbo].[PC_ResourceRatings] (
  [id]            UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [resourceId]    UNIQUEIDENTIFIER NOT NULL,
  [participantId] UNIQUEIDENTIFIER NOT NULL,

  [score]         INT              NOT NULL DEFAULT (0),
  [isArchived]    BIT              NOT NULL DEFAULT (0),

  [createdBy]     UNIQUEIDENTIFIER     NULL,
  [createdOn]     DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]    UNIQUEIDENTIFIER     NULL,
  [modifiedOn]    DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_ResourceRatings]             PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_ResourceRatings_Resource]    FOREIGN KEY ([resourceId])     REFERENCES [dbo].[PC_Resources]([id]),
  CONSTRAINT [FK_PC_ResourceRatings_Participant] FOREIGN KEY ([participantId])  REFERENCES [dbo].[Enrollments]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourceRatings_Resource] ON [dbo].[PC_ResourceRatings] ( [resourceId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourceRatings_Participant] ON [dbo].[PC_ResourceRatings] ( [participantId] ASC )
GO

-- AVAILABILITIES

CREATE TABLE [dbo].[PC_Availabilities] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,
  [captainId]  UNIQUEIDENTIFIER NOT NULL,

  [startDate]  DATETIME2        NOT NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Availabilities]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Availabilities_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_PC_Availabilities_Captain]  FOREIGN KEY ([captainId])   REFERENCES [dbo].[Enrollments]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Availabilities_Captain] ON [dbo].[PC_Availabilities] ( [captainId] ASC )
GO

-- APPOINTMENTS

CREATE TABLE [dbo].[PC_Appointments] (
  [id]                  UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]          UNIQUEIDENTIFIER NOT NULL,
  [availabilityId]      UNIQUEIDENTIFIER NOT NULL,
  [captainId]           UNIQUEIDENTIFIER NOT NULL,
  [participantId]       UNIQUEIDENTIFIER NOT NULL,
  [topicId]             UNIQUEIDENTIFIER NOT NULL,

  [captainArrival]      DATETIME2            NULL,
  [participantArrival]  DATETIME2            NULL,
  [offLabelRequestSent] BIT              NOT NULL DEFAULT (0),
  [cancelledOn]         DATETIME2            NULL,
  [cancelledBy]         VARCHAR(15)          NULL,
  [completedOn]         DATETIME2            NULL,
  [duration]            INT                  NULL,
  [externalId]          VARCHAR(50)          NULL,
  [isArchived]          BIT              NOT NULL DEFAULT (0),

  [createdBy]           UNIQUEIDENTIFIER     NULL,
  [createdOn]           DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]          UNIQUEIDENTIFIER     NULL,
  [modifiedOn]          DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PC_Appointments]              PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_Appointments_Campaign]     FOREIGN KEY ([campaignId])      REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_PC_Appointments_Availability] FOREIGN KEY ([availabilityId])  REFERENCES [dbo].[PC_Availabilities]([id]),
  CONSTRAINT [FK_PC_Appointments_Captain]      FOREIGN KEY ([captainId])       REFERENCES [dbo].[Enrollments]([id]),
  CONSTRAINT [FK_PC_Appointments_Participant]  FOREIGN KEY ([participantId])   REFERENCES [dbo].[Enrollments]([id]),
  CONSTRAINT [FK_PC_Appointments_Topic]        FOREIGN KEY ([topicId])         REFERENCES [dbo].[PC_Topics]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Appointments_Campaign] ON [dbo].[PC_Appointments] ( [campaignId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Appointments_Availability] ON [dbo].[PC_Appointments] ( [availabilityId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Appointments_Captain] ON [dbo].[PC_Appointments] ( [captainId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Appointments_Participant] ON [dbo].[PC_Appointments] ( [participantId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_Appointments_Topic] ON [dbo].[PC_Appointments] ( [topicId] ASC )
GO


---------- [ V I E W S ] ----------

-- USERS

CREATE VIEW [dbo].[PC_Users]
AS
  SELECT e.id,
         e.campaignId,
         JSON_VALUE(e.response, '$.emailAddress') AS emailAddress,
         JSON_VALUE(e.response, '$.password') AS password,
         e.isActive,
         e.isArchived,
         e.createdBy,
         e.createdOn,
         e.modifiedBy,
         e.modifiedOn,
         (IIF(JSON_VALUE(e.response, '$.userType') = 'Captain',
            'ROLE_CAPTAIN', 'ROLE_PARTICIPANT') + ',ROLE_USER') AS rolesList
  FROM   [dbo].[Enrollments] e
  UNION
  SELECT a.id,
         a.parentId AS campaignId,
         a.emailAddress,
         a.password,
         a.isActive,
         a.isArchived,
         a.createdBy,
         a.createdOn,
         a.modifiedBy,
         a.modifiedOn,
         (SELECT STRING_AGG(r.name, ',')
          FROM   [dbo].[AdminRoles] ar
                 LEFT JOIN [dbo].[Roles] r ON ar.roleId = r.id
          WHERE  ar.adminId = a.id) + ',ROLE_ADMIN' AS roles
  FROM   [dbo].[Admins] a;
GO

-- CAPTAINS

CREATE VIEW [dbo].[PC_Captains]
AS
  SELECT e.id, e.response, e.campaignId, e.isActive, e.isArchived,
         e.createdBy, e.createdOn, e.modifiedBy, e.modifiedOn,
         JSON_VALUE(e.response, '$.firstName')           AS firstName,
         JSON_VALUE(e.response, '$.lastName')            AS lastName,
         JSON_VALUE(e.response, '$.title')               AS title,
         JSON_VALUE(e.response, '$.emailAddress')        AS emailAddress,
         JSON_VALUE(e.response, '$.password')            AS password,
         JSON_VALUE(e.response, '$.mobileNumber')        AS mobileNumber,
         JSON_VALUE(e.response, '$.addressLine1')        AS addressLine1,
         JSON_VALUE(e.response, '$.addressLine2')        AS addressLine2,
         JSON_VALUE(e.response, '$.city')                AS city,
         JSON_VALUE(e.response, '$.state')               AS state,
         JSON_VALUE(e.response, '$.zipCode')             AS zipCode,
         JSON_VALUE(e.response, '$.profileImageUrl')     AS profileImageUrl,
         JSON_VALUE(e.response, '$.biography')           AS biography,
         CONVERT(BIT,              JSON_VALUE(e.response, '$.optIn'))         AS optIn,
         CONVERT(BIT,              JSON_VALUE(e.response, '$.terms'))         AS terms,
         CONVERT(BIT,              JSON_VALUE(e.response, '$.unsubscribed'))  AS unsubscribed,
         CONVERT(UNIQUEIDENTIFIER, JSON_VALUE(e.response, '$.mediaSourceId')) AS mediaSourceId,
         CONVERT(UNIQUEIDENTIFIER, JSON_VALUE(e.response, '$.affiliationId')) AS affiliationId,
         CONVERT(UNIQUEIDENTIFIER, JSON_VALUE(e.response, '$.specialityId'))  AS specialityId,
         CONVERT(UNIQUEIDENTIFIER, JSON_VALUE(e.response, '$.timeZoneId'))    AS timeZoneId,
         JSON_QUERY(e.response, '$.segmentId') AS segmentIdsList,
         JSON_QUERY(e.response, '$.roleId')    AS roleIdsList,
         JSON_QUERY(e.response, '$.topicId')   AS topicIdsList
  FROM   [dbo].[Enrollments] e
  WHERE  JSON_VALUE(e.response, '$.userType') = 'Captain';
GO

-- PARTICIPANTS

CREATE VIEW [dbo].[PC_Participants]
AS
  SELECT e.id, e.response, e.campaignId, e.isActive, e.isArchived,
         e.createdBy, e.createdOn, e.modifiedBy, e.modifiedOn,
         JSON_VALUE(e.response, '$.firstName')           AS firstName,
         JSON_VALUE(e.response, '$.lastName')            AS lastName,
         JSON_VALUE(e.response, '$.title')               AS title,
         JSON_VALUE(e.response, '$.emailAddress')        AS emailAddress,
         JSON_VALUE(e.response, '$.password')            AS password,
         JSON_VALUE(e.response, '$.mobileNumber')        AS mobileNumber,
         JSON_VALUE(e.response, '$.addressLine1')        AS addressLine1,
         JSON_VALUE(e.response, '$.addressLine2')        AS addressLine2,
         JSON_VALUE(e.response, '$.city')                AS city,
         JSON_VALUE(e.response, '$.state')               AS state,
         JSON_VALUE(e.response, '$.zipCode')             AS zipCode,
         JSON_VALUE(e.response, '$.profileImageUrl')     AS profileImageUrl,
         JSON_VALUE(e.response, '$.biography')           AS biography,
         CONVERT(BIT,              JSON_VALUE(e.response, '$.optIn'))         AS optIn,
         CONVERT(BIT,              JSON_VALUE(e.response, '$.terms'))         AS terms,
         CONVERT(BIT,              JSON_VALUE(e.response, '$.unsubscribed'))  AS unsubscribed,
         CONVERT(UNIQUEIDENTIFIER, JSON_VALUE(e.response, '$.mediaSourceId')) AS mediaSourceId,
         CONVERT(UNIQUEIDENTIFIER, JSON_VALUE(e.response, '$.affiliationId')) AS affiliationId,
         CONVERT(UNIQUEIDENTIFIER, JSON_VALUE(e.response, '$.specialityId'))  AS specialityId,
         CONVERT(UNIQUEIDENTIFIER, JSON_VALUE(e.response, '$.timeZoneId'))    AS timeZoneId,
         JSON_QUERY(e.response, '$.segmentId') AS segmentIdsList,
         JSON_QUERY(e.response, '$.roleId')    AS roleIdsList
  FROM   [dbo].[Enrollments] e
  WHERE  JSON_VALUE(e.response, '$.userType') = 'Participant';
GO
