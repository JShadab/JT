-- PARENTS

CREATE TABLE [dbo].[Parents] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [parentId]   UNIQUEIDENTIFIER     NULL,

  [name]       VARCHAR(50)      NOT NULL,
  [level]      INT              NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_Parents]        PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_Parents_Parent] FOREIGN KEY ([parentId]) REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_Parents_Parent] ON [dbo].[Parents] ( [parentId] ASC );
GO

-- ADMINS

CREATE TABLE [dbo].[Admins] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [parentId]     UNIQUEIDENTIFIER     NULL,

  [firstName]    VARCHAR(50)      NOT NULL,
  [lastName]     VARCHAR(50)      NOT NULL,
  [emailAddress] VARCHAR(255)     NOT NULL,
  [password]     VARCHAR(MAX)     NOT NULL,
  [phoneNumber]  VARCHAR(25)          NULL,
  [isActive]     BIT              NOT NULL DEFAULT (0),
  [isArchived]   BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_Admins]        PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_Admins_Parent] FOREIGN KEY ([parentId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_UserParent] ON [dbo].[Admins] ( [parentId] ASC );
GO

-- ROLES

CREATE TABLE [dbo].[Roles] (
  [id]      UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [name]    VARCHAR(30)      NOT NULL,

  CONSTRAINT [PK_Roles] PRIMARY KEY CLUSTERED ([id] ASC)
);
GO

-- ADMIN ROLES

CREATE TABLE [dbo].[AdminRoles]
(
  [adminId]  UNIQUEIDENTIFIER NOT NULL,
  [roleId]   UNIQUEIDENTIFIER NOT NULL,

  CONSTRAINT [PK_AdminRoles]       PRIMARY KEY CLUSTERED ([adminId] ASC, [roleId] ASC),
  CONSTRAINT [FK_AdminRoles_Admin] FOREIGN KEY ([adminId])  REFERENCES [dbo].[Admins]([id]),
  CONSTRAINT [FK_AdminRoles_Role]  FOREIGN KEY ([roleId])  REFERENCES [dbo].[Roles]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_AdminRoles_Admin] ON [dbo].[AdminRoles] ( [adminId] ASC );
GO

CREATE NONCLUSTERED INDEX [FKIDX_AdminRoles_Role] ON [dbo].[AdminRoles] ( [roleId] ASC );
GO

-- PASSWORD RESET TOKENS

CREATE TABLE [dbo].[PasswordResetTokens] (
  [id]          UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]  UNIQUEIDENTIFIER NOT NULL,
  [userId]      UNIQUEIDENTIFIER NOT NULL,

  [token]       VARCHAR(36)      NOT NULL,
  [expiration]  DATETIME2        NOT NULL,
  [isArchived]  BIT              NOT NULL DEFAULT (1),

  [createdBy]   UNIQUEIDENTIFIER     NULL,
  [createdOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]  UNIQUEIDENTIFIER     NULL,
  [modifiedOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_PasswordResetTokens]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PasswordResetTokens_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PasswordResetTokens_Campaign] ON [dbo].[PasswordResetTokens] ( [campaignId] ASC );
GO


-- DEFAULT QUESTIONS

CREATE TABLE [dbo].[DefaultQuestions] (
  [id]          UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]  UNIQUEIDENTIFIER     NULL,

  [name]        VARCHAR(50)      NOT NULL,
  [description] VARCHAR(255)     NOT NULL,
  [type]        VARCHAR(10)      NOT NULL,
  [attribute]   VARCHAR(10)      NOT NULL,
  [isActive]    BIT              NOT NULL DEFAULT (1),
  [isArchived]  BIT              NOT NULL DEFAULT (0),

  [createdBy]   UNIQUEIDENTIFIER     NULL,
  [createdOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]  UNIQUEIDENTIFIER     NULL,
  [modifiedOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_DefaultQuestions]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_DefaultQuestions_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_DefaultQuestions_Campaign] ON [dbo].[DefaultQuestions] ( [campaignId] ASC );
GO

-- DEFAULT QUESTION OPTIONS

CREATE TABLE [dbo].[DefaultQuestionOptions] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [questionId] UNIQUEIDENTIFIER NOT NULL,

  [value]      VARCHAR(255)     NOT NULL,
  [text]       VARCHAR(255)         NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_DefaultQuestionOptions]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_DefaultQuestionOptions_Question] FOREIGN KEY ([questionId]) REFERENCES [dbo].[DefaultQuestions]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_DefaultQuestionOptions_Question] ON [dbo].[DefaultQuestionOptions] ( [questionId] ASC );
GO


-- CONTENTS

CREATE TABLE [dbo].[Contents] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(50)      NOT NULL,
  [channel]    VARCHAR(10)      NOT NULL,                       -- email | sms
  [category]   VARCHAR(50)          NULL,
  [subject]    VARCHAR(MAX)         NULL,
  [preHeader]  VARCHAR(MAX)         NULL,
  [text]       VARCHAR(MAX)     NOT NULL,
  [fileName]   VARCHAR(50)          NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_Contents]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_Contents_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_Contents_Campaign] ON [dbo].[Contents] ( [campaignId] ASC );
GO


-- CAMPAIGN QUESTIONS

CREATE TABLE [dbo].[CampaignQuestions] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]   UNIQUEIDENTIFIER NOT NULL,

  [name]         VARCHAR(50)      NOT NULL,
  [description]  VARCHAR(255)     NOT NULL,
  [type]         VARCHAR(10)      NOT NULL,            -- text, checkbox, radio, select, rating
  [dataType]     VARCHAR(10)      NOT NULL,            -- text: text, email, hidden, number, password | checkbox: single, multiple, multipleOther
  [isEvent]      BIT              NOT NULL DEFAULT (0),
  [isArchived]   BIT              NOT NULL DEFAULT (0),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_CampaignQuestions]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_CampaignQuestions_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO


CREATE NONCLUSTERED INDEX [FKIDX_CampaignQuestions_Campaign] ON [dbo].[CampaignQuestions] ( [campaignId] ASC );
GO

-- CAMPAIGN QUESTION OPTIONS

CREATE TABLE [dbo].[CampaignQuestionOptions] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [questionId] UNIQUEIDENTIFIER NOT NULL,

  [value]      VARCHAR(255)     NOT NULL,
  [text]       VARCHAR(255)         NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_CampaignQuestionOptions]                  PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_CampaignQuestionOptions_CampaignQuestion] FOREIGN KEY ([questionId])  REFERENCES [dbo].[CampaignQuestions]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_CampaignQuestionOptions_CampaignQuestion] ON [dbo].[CampaignQuestionOptions] ( [questionId] ASC );
GO


-- SURVEYS

CREATE TABLE [dbo].[Surveys] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]   UNIQUEIDENTIFIER NOT NULL,

  [name]         VARCHAR(100)     NOT NULL,
  [shortUrl]     VARCHAR(50)          NULL,
  [isEnrollment] BIT              NOT NULL DEFAULT (0),
  [isArchived]   BIT              NOT NULL DEFAULT (0),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_Surveys]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_Surveys_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_Surveys_Campaign] ON [dbo].[Surveys] ( [campaignId] ASC );
GO

-- ENROLLMENTS

CREATE TABLE [dbo].[Enrollments] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,
  [surveyId]   UNIQUEIDENTIFIER NOT NULL,

  [response]   NVARCHAR(MAX)    NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_Enrollments]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_Enrollments_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_Enrollments_Survey]   FOREIGN KEY ([surveyId])    REFERENCES [dbo].[Surveys]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_Enrollments_Campaign] ON [dbo].[Enrollments] ( [campaignId] ASC );
GO

CREATE NONCLUSTERED INDEX [FKIDX_Enrollments_Survey] ON [dbo].[Enrollments] ( [surveyId] ASC );
GO

-- SURVEY RESPONSES

CREATE TABLE [dbo].[SurveyResponses] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [surveyId]     UNIQUEIDENTIFIER NOT NULL,
  [userId]       UNIQUEIDENTIFIER NOT NULL,

  [response]     NVARCHAR(MAX)    NOT NULL,
  [isArchived]   BIT              NOT NULL DEFAULT (0),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_SurveyResponses]            PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_SurveyResponses_Survey]     FOREIGN KEY ([surveyId]) REFERENCES [dbo].[Surveys]([id]),
  CONSTRAINT [FK_SurveyResponses_Enrollment] FOREIGN KEY ([userId])   REFERENCES [dbo].[Enrollments]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyResponses_Survey] ON [dbo].[SurveyResponses] ( [surveyId] ASC );
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyResponses_Enrollment] ON [dbo].[SurveyResponses] ( [userId] ASC );
GO


-- SEGMENTS

CREATE TABLE [dbo].[Segments] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(50)      NOT NULL,
  [ruleSets]   VARCHAR(MAX)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (0),
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_Segments]           PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_Segments_Campaign]  FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_Segments_Campaign] ON [dbo].[Segments] ( [campaignId] ASC );
GO

-- JOURNEYS

CREATE TABLE [dbo].[Journeys] (
  [id]          UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [segmentId]   UNIQUEIDENTIFIER NOT NULL,

  [name]        VARCHAR(50)      NOT NULL,
  [description] VARCHAR(255)         NULL,
  [isActive]    BIT              NOT NULL DEFAULT (0),
  [isArchived]  BIT              NOT NULL DEFAULT (0),

  [createdBy]   UNIQUEIDENTIFIER     NULL,
  [createdOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]  UNIQUEIDENTIFIER     NULL,
  [modifiedOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_Journeys]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_Journeys_Segment] FOREIGN KEY ([segmentId])  REFERENCES [dbo].[Segments]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_Journeys_Segment] ON [dbo].[Journeys] ( [segmentId] ASC );
GO


-- SURVEY QUESTIONS

CREATE TABLE [dbo].[SurveyQuestions] (
  [id]          UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]  UNIQUEIDENTIFIER NOT NULL,
  [surveyId]    UNIQUEIDENTIFIER NOT NULL,

  [name]        VARCHAR(50)      NOT NULL,
  [description] VARCHAR(255)     NOT NULL,
  [type]        VARCHAR(10)      NOT NULL,
  [dataType]    VARCHAR(10)      NOT NULL,
  [isEvent]     BIT              NOT NULL DEFAULT (0),
  [isArchived]  BIT              NOT NULL DEFAULT (0),

  [createdBy]   UNIQUEIDENTIFIER     NULL,
  [createdOn]   DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy]  UNIQUEIDENTIFIER     NULL,
  [modifiedOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_SurveyQuestions]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_SurveyQuestions_Campaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_SurveyQuestions_Survey]   FOREIGN KEY ([surveyId])    REFERENCES [dbo].[Surveys]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyQuestions_Campaign] ON [dbo].[SurveyQuestions] ( [campaignId] ASC );
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyQuestions_Survey] ON [dbo].[SurveyQuestions] ( [surveyId] ASC );
GO

-- SURVEY QUESTION OPTIONS

CREATE TABLE [dbo].[SurveyQuestionOptions] (
  [id]         UNIQUEIDENTIFIER NOT NULL,
  [questionId] UNIQUEIDENTIFIER NOT NULL,

  [value]      VARCHAR(255)     NOT NULL,
  [text]       VARCHAR(255)         NULL,
  [isArchived] BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (SYSUTCDATETIME()),

  CONSTRAINT [PK_SurveyQuestionOptions]                PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_SurveyQuestionOptions_SurveyQuestion] FOREIGN KEY ([questionId])  REFERENCES [dbo].[SurveyQuestions]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyQuestionOptions_SurveyQuestion] ON [dbo].[SurveyQuestionOptions] ( [questionId] ASC );
GO

