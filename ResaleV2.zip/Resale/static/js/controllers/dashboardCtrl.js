angular.module('resale.controllers')
.controller('dashboardCtrl', function ($rootScope, AjaxUtil, $uibModal ,$state, $scope, $location, store, $timeout, $stateParams, AlertService, toastr) {
    
    $scope.checkIfLoggedIn=function(){
        $scope.userId=store.get("resale-userId");
        if($scope.userId != null){
            $scope.getUserById();
        }
    }

    $scope.getUserById=function(){
        AjaxUtil.getDataNoSecure("user/" + $scope.userId, Math.random())
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $scope.user = data;
                    $scope.$digest();
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }
    $scope.logout = function(){
        store.remove("resale-userId");
        $state.go("signin");
    }
});
