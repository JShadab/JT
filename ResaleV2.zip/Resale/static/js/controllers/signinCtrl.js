angular.module('resale.controllers')
.controller('signinCtrl', function ($rootScope, AjaxUtil, $uibModal ,$state, $scope, $location, store, $timeout, $stateParams, AlertService, toastr) {
    
    $scope.loginInput={};
    $scope.login=function(){
        AjaxUtil.getDataNoSecure("userByEmail?email="+$scope.loginInput.email+"&password="+$scope.loginInput.password, Math.random())
				.success(function(data, headers, config) {
                    console.log(data);
					if(data && data.id == "null"){
						toastr.error('Invalid credentials');
					} else {
                        toastr.success("Logged-in");
                        store.set("resale-userId", data.id);
                        $state.go('products');
                    }
				})
				.error(function (errorData, errorStatus, headers, config) {
					if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
						toastr.error('Oops! Error occured. Please try again later.')					
					}
				});
    }

});
