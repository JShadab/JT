package com.shadab.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.shadab.demo.entity.Student;
import com.shadab.demo.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	private StudentService studentService;

	@PostMapping("/student")
	public void saveStudent(Student student) {
		studentService.saveStudent(student);
	}

	@PutMapping("/student")
	public void updateStudent(Student student) {
		studentService.updateStudent(student);
	}

	@DeleteMapping("/student/{id}")
	public void deleteStudentById(@PathVariable Long id) {
		studentService.deleteStudentById(id);
	}

	@DeleteMapping("/student")
	public void deleteStudent(Student student) {
		studentService.deleteStudent(student);
	}

	@GetMapping("/student/{id}")
	public Optional<Student> getStudent(@PathVariable Long id) {
		return studentService.getStudent(id);

	}

	@GetMapping("/student")
	public List<Student> getAllStudent() {
		return studentService.getAllStudent();

	}

}
