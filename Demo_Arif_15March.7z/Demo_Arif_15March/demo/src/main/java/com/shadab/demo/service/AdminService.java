package com.shadab.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shadab.demo.entity.Admin;
import com.shadab.demo.repository.AdminRepository;

@Service
public class AdminService {

	@Autowired
	private AdminRepository adminRepository;

	public void saveAdmin(Admin admin) {
		adminRepository.save(admin);
	}

	public void updateAdmin(Admin admin) {
		adminRepository.save(admin);
	}

	public void deleteAdminById(Long adminId) {
		adminRepository.deleteById(adminId);
	}

	public void deleteAdmin(Admin admin) {
		adminRepository.delete(admin);
	}

	public Optional<Admin> getAdmin(Long adminId) {

		return adminRepository.findById(adminId);

	}

	public List<Admin> getAllAdmin() {

		return adminRepository.findAll();

	}

}
