package com.shadab.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shadab.demo.entity.Student;
import com.shadab.demo.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;

	public void saveStudent(Student student) {
		studentRepository.save(student);
	}

	public void updateStudent(Student student) {
		studentRepository.save(student);
	}

	public void deleteStudentById(Long studentId) {
		studentRepository.deleteById(studentId);
	}

	public void deleteStudent(Student student) {
		studentRepository.delete(student);
	}

	public Optional<Student> getStudent(Long studentId) {

		return studentRepository.findById(studentId);

	}

	public List<Student> getAllStudent() {

		return studentRepository.findAll();

	}

}
