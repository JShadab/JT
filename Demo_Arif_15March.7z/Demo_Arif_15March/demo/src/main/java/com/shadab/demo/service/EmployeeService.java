package com.shadab.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shadab.demo.entity.Employee;
import com.shadab.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	public void saveEmployee(Employee employee) {
		employeeRepository.save(employee);
	}

	public void updateEmployee(Employee employee) {
		employeeRepository.save(employee);
	}

	public void deleteEmployeeById(Long employeeId) {
		employeeRepository.deleteById(employeeId);
	}

	public void deleteEmployee(Employee student) {
		employeeRepository.delete(student);
	}

	public Optional<Employee> getEmployee(Long employeeId) {

		return employeeRepository.findById(employeeId);

	}

	public List<Employee> getAllEmployee() {

		return employeeRepository.findAll();

	}

}
