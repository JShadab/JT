package com.shadab.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.shadab.demo.entity.Employee;
import com.shadab.demo.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@PostMapping("/employee")
	public void saveEmployee(Employee employee) {
		employeeService.saveEmployee(employee);
	}

	@PutMapping("/employee")
	public void updateEmployee(Employee employee) {
		employeeService.updateEmployee(employee);
	}

	@DeleteMapping("/employee/{id}")
	public void deleteEmployeeById(@PathVariable Long id) {
		employeeService.deleteEmployeeById(id);
	}

	@DeleteMapping("/employee")
	public void deleteEmployee(Employee employee) {
		employeeService.deleteEmployee(employee);
	}

	@GetMapping("/employee/{id}")
	public Optional<Employee> getEmployee(@PathVariable Long id) {
		return employeeService.getEmployee(id);

	}

	@GetMapping("/employee")
	public List<Employee> getAllEmployee() {
		return employeeService.getAllEmployee();

	}

}
