package com.shadab.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String name;
	private String gardianName;
	private String admissionFee;
	private String rollNumber;
	private String className;
	private String categoryName;
	private String groupName;
	private String monthlyCharges;
	private String fatherCNIC;
	private String gardianMobileNumber;
	private String beformNumber;
	private String registrationDate;
	private String mobileNumber;
	private String address;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGardianName() {
		return gardianName;
	}

	public void setGardianName(String gardianName) {
		this.gardianName = gardianName;
	}

	public String getAdmissionFee() {
		return admissionFee;
	}

	public void setAdmissionFee(String admissionFee) {
		this.admissionFee = admissionFee;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getMonthlyCharges() {
		return monthlyCharges;
	}

	public void setMonthlyCharges(String monthlyCharges) {
		this.monthlyCharges = monthlyCharges;
	}

	public String getFatherCNIC() {
		return fatherCNIC;
	}

	public void setFatherCNIC(String fatherCNIC) {
		this.fatherCNIC = fatherCNIC;
	}

	public String getGardianMobileNumber() {
		return gardianMobileNumber;
	}

	public void setGardianMobileNumber(String gardianMobileNumber) {
		this.gardianMobileNumber = gardianMobileNumber;
	}

	public String getBeformNumber() {
		return beformNumber;
	}

	public void setBeformNumber(String beformNumber) {
		this.beformNumber = beformNumber;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", gardianName=" + gardianName + ", admissionFee="
				+ admissionFee + ", rollNumber=" + rollNumber + ", className=" + className + ", categoryName="
				+ categoryName + ", groupName=" + groupName + ", monthlyCharges=" + monthlyCharges + ", fatherCNIC="
				+ fatherCNIC + ", gardianMobileNumber=" + gardianMobileNumber + ", beformNumber=" + beformNumber
				+ ", registrationDate=" + registrationDate + ", mobileNumber=" + mobileNumber + ", address=" + address
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((admissionFee == null) ? 0 : admissionFee.hashCode());
		result = prime * result + ((beformNumber == null) ? 0 : beformNumber.hashCode());
		result = prime * result + ((categoryName == null) ? 0 : categoryName.hashCode());
		result = prime * result + ((className == null) ? 0 : className.hashCode());
		result = prime * result + ((fatherCNIC == null) ? 0 : fatherCNIC.hashCode());
		result = prime * result + ((gardianMobileNumber == null) ? 0 : gardianMobileNumber.hashCode());
		result = prime * result + ((gardianName == null) ? 0 : gardianName.hashCode());
		result = prime * result + ((groupName == null) ? 0 : groupName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((mobileNumber == null) ? 0 : mobileNumber.hashCode());
		result = prime * result + ((monthlyCharges == null) ? 0 : monthlyCharges.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((registrationDate == null) ? 0 : registrationDate.hashCode());
		result = prime * result + ((rollNumber == null) ? 0 : rollNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (admissionFee == null) {
			if (other.admissionFee != null)
				return false;
		} else if (!admissionFee.equals(other.admissionFee))
			return false;
		if (beformNumber == null) {
			if (other.beformNumber != null)
				return false;
		} else if (!beformNumber.equals(other.beformNumber))
			return false;
		if (categoryName == null) {
			if (other.categoryName != null)
				return false;
		} else if (!categoryName.equals(other.categoryName))
			return false;
		if (className == null) {
			if (other.className != null)
				return false;
		} else if (!className.equals(other.className))
			return false;
		if (fatherCNIC == null) {
			if (other.fatherCNIC != null)
				return false;
		} else if (!fatherCNIC.equals(other.fatherCNIC))
			return false;
		if (gardianMobileNumber == null) {
			if (other.gardianMobileNumber != null)
				return false;
		} else if (!gardianMobileNumber.equals(other.gardianMobileNumber))
			return false;
		if (gardianName == null) {
			if (other.gardianName != null)
				return false;
		} else if (!gardianName.equals(other.gardianName))
			return false;
		if (groupName == null) {
			if (other.groupName != null)
				return false;
		} else if (!groupName.equals(other.groupName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (mobileNumber == null) {
			if (other.mobileNumber != null)
				return false;
		} else if (!mobileNumber.equals(other.mobileNumber))
			return false;
		if (monthlyCharges == null) {
			if (other.monthlyCharges != null)
				return false;
		} else if (!monthlyCharges.equals(other.monthlyCharges))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (registrationDate == null) {
			if (other.registrationDate != null)
				return false;
		} else if (!registrationDate.equals(other.registrationDate))
			return false;
		if (rollNumber == null) {
			if (other.rollNumber != null)
				return false;
		} else if (!rollNumber.equals(other.rollNumber))
			return false;
		return true;
	}

}
