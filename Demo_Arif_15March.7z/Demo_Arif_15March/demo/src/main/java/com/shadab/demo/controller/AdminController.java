package com.shadab.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shadab.demo.entity.Admin;
import com.shadab.demo.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	private AdminService adminService;

	@GetMapping("/")
	public String getIndex() {
		return "index";
	}

	@GetMapping("/admin/signUp")
	public String getAdminSignUp() {
		return "adminSignUpForm";
	}

	@PostMapping("/admin/login")
	public String getIndex(@RequestParam("email") String email, @RequestParam("password") String password) {

		if ("admin@gmail.com".equals(email) && "1234".equals(password)) {
			return "home";
		} else {
			return "index";
		}

	}

	@PostMapping("/admin")
	public void saveAdmin(Admin admin) {
		adminService.saveAdmin(admin);
	}

	@PutMapping("/admin")
	public void updateAdmin(Admin admin) {
		adminService.updateAdmin(admin);
	}

	@DeleteMapping("/admin/{id}")
	public void deleteAdminById(@PathVariable Long id) {
		adminService.deleteAdminById(id);
	}

	@DeleteMapping("/admin")
	public void deleteAdmin(Admin admin) {
		adminService.deleteAdmin(admin);
	}

	@GetMapping("/admin/{id}")
	public Optional<Admin> getAdmin(@PathVariable Long id) {
		return adminService.getAdmin(id);

	}

	@GetMapping("/admin")
	public List<Admin> getAllAdmin() {
		return adminService.getAllAdmin();

	}

}
