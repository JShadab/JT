package com.poc.twilio;

import java.net.URISyntaxException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.poc.MakeCall;
import com.twilio.rest.api.v2010.account.Application;
import com.twilio.twiml.VoiceResponse;
import com.twilio.twiml.voice.Say;

@SpringBootApplication
@RestController
public class TwilioApplication extends SpringBootServletInitializer {

	public static void main(String[] args) throws URISyntaxException {
		SpringApplication.run(TwilioApplication.class, args);

		MakeCall.call();
	}

	@RequestMapping(value = "/voice-note", method = RequestMethod.POST, produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<Object> getVoiceNote() {

		Say say = new Say.Builder("Hello From Shadab!").build();

		VoiceResponse response = new VoiceResponse.Builder().say(say).build();

		return new ResponseEntity<>(response.toXml(), HttpStatus.OK);
	}

	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public ResponseEntity<Object> test() {

		return new ResponseEntity<>("This is test", HttpStatus.OK);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(applicationClass);
	}

	private static Class<Application> applicationClass = Application.class;
}
