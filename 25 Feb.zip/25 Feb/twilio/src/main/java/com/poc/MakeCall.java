package com.poc;

import java.net.URI;
import java.net.URISyntaxException;

import com.poc.utils.ProxiedTwilioClientCreator;
import com.twilio.Twilio;
import com.twilio.http.TwilioRestClient;
import com.twilio.rest.api.v2010.account.Call;
import com.twilio.type.PhoneNumber;

public class MakeCall {

	public static final String ACCOUNT_SID = "ACda53158aeff510a5c2e2d0058b553837";
	public static final String AUTH_TOKEN = "8955e889d4f4740a7e3783fa32340a01";

	public static final String PROXY_HOST = "192.168.0.220";
	public static final int PROXY_PORT = 3128;

	public static void call() throws URISyntaxException {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

		ProxiedTwilioClientCreator clientCreator = new ProxiedTwilioClientCreator(ACCOUNT_SID, AUTH_TOKEN, PROXY_HOST,
				PROXY_PORT);
		TwilioRestClient twilioRestClient = clientCreator.getClient();
		Twilio.setRestClient(twilioRestClient);

		Call call = Call.creator(new PhoneNumber("+917007586179"), new PhoneNumber("+14699195984"),
				new URI("http://localhost:8080/voice-note")).create();

		System.out.println(call.getSid());
	}

}
