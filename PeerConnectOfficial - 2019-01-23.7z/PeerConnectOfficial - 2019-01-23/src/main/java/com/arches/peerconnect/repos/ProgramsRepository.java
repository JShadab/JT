package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Program;
import com.arches.peerconnect.repos.base.PeerConnectRepository;


/**
 * @author Anurag Mishra, 2018-12-26
 */
public interface ProgramsRepository extends PeerConnectRepository<Program> { }
