package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.BaseController;
import com.arches.peerconnect.models.request.AdminRequest;
import com.arches.peerconnect.services.AdminsService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-27
 */
@RestController
@RequestMapping("/admins")
@PreAuthorize("hasRole('ADMIN')")
public class AdminsController extends BaseController {

    private final AdminsService service;

    public AdminsController(AdminsService service) {
        this.service = service;
    }

    //

    @GetMapping("")
    public ResponseEntity<?> get(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "id", required = false) UUID adminId) {

        return ResponseEntity.ok(
            adminId != null
                ? service.getByCampaignIdAndId(tenantId, adminId)
                : service.getAllByCampaignId(tenantId)
        );

    }

    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody AdminRequest request) {

        var result = service.create(tenantId, request);

        return createdResponse(result.getId());
    }

    @PostMapping("status")
    public ResponseEntity<?> status(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "id") UUID adminId,
        @RequestParam(value = "isActive") Boolean isActive) {

        service.changeStatus(tenantId, adminId, isActive);

        return okResponse();
    }

    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID adminId,
        @Valid @RequestBody AdminRequest request) {

        service.update(adminId, request);

        return okResponse();
    }

    @DeleteMapping("")
    public ResponseEntity<?> delete(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID adminId) {

        service.delete(adminId);

        return okResponse();
    }

}
