package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.base.PeerConnectEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.time.Instant;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_Programs")
public class Program extends PeerConnectEntity {

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Instant startDate;

    @Column(nullable = false)
    private Instant endDate;

    @Column(nullable = false)
    private Integer sessionDuration;

    @Column(nullable = false)
    private Integer maxCaptainSessions;

    @Column(nullable = false)
    private Integer maxParticipantSessions;

    @Column(nullable = false)
    private String supportEmail;

}
