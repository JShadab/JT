package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.base.PeerConnectEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_Segments")
public class Segment extends PeerConnectEntity {

    @Column(nullable = false)
    private String name;

}
