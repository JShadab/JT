package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.Topic;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.TopicsRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@Service
public class TopicsService extends PeerConnectEntityService<Topic> {

    private final TopicsRepository topicsRepository;

    public TopicsService(
        TopicsRepository topicsRepository,
        ParentsRepository parentsRepository) {

        super(topicsRepository, parentsRepository, ErrorCode.E024);

        this.topicsRepository = topicsRepository;
    }

    //

    public List<Topic> getAvailableTopicsByParticipant(UUID tenantId, UUID participantId) {
        return topicsRepository.getAvailableTopicsByParticipant(tenantId, participantId);
    }
}
