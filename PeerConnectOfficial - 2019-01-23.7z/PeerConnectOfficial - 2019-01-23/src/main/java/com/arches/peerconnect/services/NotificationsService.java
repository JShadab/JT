package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ContactMethod;
import com.arches.peerconnect.entities.peerconnect.Appointment;
import com.arches.peerconnect.entities.peerconnect.Participant;
import com.arches.peerconnect.entities.peerconnect.TimeZone;
import com.arches.peerconnect.messaging.senders.MessageSender;
import com.arches.peerconnect.models.message.EmailMessage;
import com.arches.peerconnect.models.message.TextMessage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-18
 */
@Service
@Transactional
@SuppressWarnings("Duplicates")
public class NotificationsService {

    @Value("${app.entrada.name}")
    private String entradaName;

    @Value("${app.entrada.email}")
    private String entradaEmail;

    @Value("${app.sender.email}")
    private String senderEmail;

    @Value("${app.sender.phone}")
    private String senderPhone;


    @Value("${app.mandrill.templates.welcome}")
    private String welcomeTmplId;

    @Value("${app.mandrill.templates.forgot-password}")
    private String forgotPwdTmplId;

    @Value("${app.mandrill.templates.unsubscribe}")
    private String unsubscribeTmplId;

    @Value("${app.mandrill.templates.appointment-scheduled}")
    private String apptScheduledTmplId;

    @Value("${app.mandrill.templates.appointment-reminder}")
    private String apptReminderTmplId;

    @Value("${app.mandrill.templates.appointment-cancelled-participant}")
    private String apptCancelledParticipantTmplId;

    @Value("${app.mandrill.templates.appointment-cancelled-captain}")
    private String apptCancelledCaptainTmplId;

    @Value("${app.mandrill.templates.offlabel-request}")
    private String offLabelRequestTmplId;

    @Value("${app.mandrill.templates.support-request}")
    private String supportRequestTmplId;


    private final MessageSender sender;
    private final TimeZonesService timeZonesService;
    private final SupportTopicsService supportTopicsService;


    public NotificationsService(
        MessageSender sender,
        TimeZonesService timeZonesService,
        SupportTopicsService supportTopicsService) {

        this.sender = sender;
        this.timeZonesService = timeZonesService;
        this.supportTopicsService = supportTopicsService;

    }

    public void sendWelcomeEmail(String firstName, String lastName, String emailAddress) {

        var tmplVars = Map.of("firstName", firstName);

        sendEmailMessage(
            "welcome",
            Map.of(firstName + " " + lastName, emailAddress),
            "Welcome to Peer Connect",
            welcomeTmplId,
            tmplVars);
    }

    public void sendForgotPasswordEmail(String email, String token) {

        var tmplVars = Map.of("token", token);

        sendEmailMessage(
            "forgotPassword", Map.of("", email), "Password Reset Email", forgotPwdTmplId, tmplVars);
    }

    public void sendUnsubscribeEmail(String firstName, String lastName, String email) {

        var tmplVars = Map.of("firstName", firstName);

        sendEmailMessage(
            "unsubscribe",
            Map.of(firstName + " " + lastName, email),
            "You have been unsubscribed from Peer Connect",
            unsubscribeTmplId,
            tmplVars);
    }

    public void sendAppointmentScheduledConfirmation(UUID campaignId, Appointment appointment) {

        var participant = appointment.getParticipant();
        var captain = appointment.getCaptain();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId()));

        // send email

        var tmplVars = Map.of(
                        "appointmentId", appointment.getId().toString(),
                        "firstName", participant.getFirstName(),
                        "captainFirstName", captain.getFirstName(),
                        "captainLastName", captain.getLastName(),
                        "captainTitle", captain.getTitle(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.scheduled",
            participant,
            "Your Appointment is scheduled",
            apptScheduledTmplId,
            tmplVars);

        // send text

        sendTextMessage(
            "appointment.scheduled",
            participant,
            "Your Appointment is scheduled at " + apptDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) +
                ". http://lmgtfy.com/?q=scheduled");
    }

    public void sendAppointmentDueReminder(UUID campaignId, Appointment appointment, ContactMethod contactMethod) {

        var participant = appointment.getParticipant();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId()));


        if (contactMethod == ContactMethod.Both || contactMethod == ContactMethod.Email) {
            var tmplVars = new HashMap<String, String>();
            tmplVars.put("apptTopic", topic.getName());
            tmplVars.put("apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE));
            tmplVars.put("apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

            sendEmailMessage(
                "appointment.cancelled",
                participant,
                "Your Appointment is due",
                apptReminderTmplId,
                tmplVars);
        }

        if (contactMethod == ContactMethod.Both || contactMethod == ContactMethod.SMS) {
            sendTextMessage(
                "appointment.cancelled",
                participant,
                "Your Appointment scheduled " + apptDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) + " is due");
        }
    }

    public void sendAppointmentCancelledNotificationToParticipant(UUID campaignId, Appointment appointment) {

        var participant = appointment.getParticipant();
        var captain = appointment.getCaptain();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, participant.getTimeZoneId()));

        // send email

        var tmplVars = Map.of(
                        "firstName", participant.getFirstName(),
                        "captainFirstName", captain.getFirstName(),
                        "captainLastName", captain.getLastName(),
                        "captainTitle", captain.getTitle(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.cancelled",
            participant,
            "Your Appointment has been cancelled by Captain",
            apptCancelledParticipantTmplId,
            tmplVars);

        // send text

        sendTextMessage(
            "appointment.cancelled",
            participant,
            "Your Appointment scheduled at " + apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) +
                " has been cancelled by the Captain. http://lmgtfy.com/?q=cancelled");
    }

    public void sendAppointmentCancelledNotificationToCaptain(UUID campaignId, Appointment appointment) {

        var captain = appointment.getCaptain();
        var topic = appointment.getTopic();
        var apptDateTime = getOffsetDateTime(
                                appointment.getAvailability().getStartDate(),
                                timeZonesService.getByCampaignIdAndId(campaignId, captain.getTimeZoneId()));

        // send email

        var tmplVars = Map.of(
                        "firstName", captain.getFirstName(),
                        "apptTopic", topic.getName(),
                        "apptDate", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE),
                        "apptTime", apptDateTime.format(DateTimeFormatter.ISO_LOCAL_TIME));

        sendEmailMessage(
            "appointment.cancelled",
            Map.of(captain.getFirstName() + " " + captain.getLastName(), captain.getEmailAddress()),
            "Your Appointment has been cancelled by Participant",
            apptCancelledCaptainTmplId,
            tmplVars);

        // send text

        sendTextMessage(
            "appointment.cancelled",
            List.of(captain.getMobileNumber()),
            "Your Appointment scheduled at " + apptDateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) +
            " has been cancelled by the Participant. http://lmgtfy.com/?q=cancelled");
    }

    public void sendOffLabelRequest(Appointment appointment, ContactMethod contactMethod) {

        var participant = appointment.getParticipant();

        if (contactMethod == ContactMethod.Both || contactMethod == ContactMethod.Email) {
            var tmplVars = Map.of("firstName", participant.getFirstName());

            sendEmailMessage(
                "appointment.off-label",
                participant,
                "Your Off-Label Request has been answered",
                offLabelRequestTmplId,
                tmplVars);
        }

        if (contactMethod == ContactMethod.Both || contactMethod == ContactMethod.SMS) {
            sendTextMessage(
                "appointment.off-label",
                participant,
                "Your Off Label Request Answered. http://lmgtfy.com/?q=off-label");
        }
    }

    public void sendSupportRequest(UUID campaignId, UUID supportTopicId, String name, String phone) {

        var supportTopic = supportTopicsService.getByCampaignIdAndId(campaignId, supportTopicId);

        var tmplVars = Map.of(
                        "supportTopic", supportTopic.getName(),
                        "name", name,
                        "phone", phone);

        sendEmailMessage(
            "internal",
            Map.of(entradaName, entradaEmail),
            "A New Support Request on " + supportTopic.getName(),
            supportRequestTmplId,
            tmplVars);
    }

    //

    private void sendEmailMessage(String route, Participant participant, String subject, String tmplId, Map<String, String> tmplVars) {
        sendEmailMessage(
            route,
            Map.of(participant.getFirstName() + " " + participant.getLastName(), participant.getEmailAddress()),
            subject, tmplId, tmplVars);
    }

    private void sendEmailMessage(String route, Map<String, String> recipients, String subject, String tmplId, Map<String, String> tmplVars) {

        var msg = new EmailMessage();
        msg.setSender(senderEmail);
        msg.setRecipients(recipients);
        msg.setSubject(subject);
        msg.setTemplateId(tmplId);
        msg.setTemplateProps(tmplVars);

        sender.send("emails." + route, msg);
    }

    private void sendTextMessage(String route, Participant participant, String content) {
        sendTextMessage(route, List.of(participant.getMobileNumber()), content);
    }

    private void sendTextMessage(String route, List<String> recipients, String content) {

        var msg = new TextMessage();
        msg.setSender(senderPhone);
        msg.setRecipients(recipients);
        msg.setBody(content);

        sender.send("texts." + route, msg);
    }

    private OffsetDateTime getOffsetDateTime(Instant instant, TimeZone timeZone) {
        return instant.atOffset(ZoneOffset.ofHours(timeZone.getUtcOffset()));
    }
}
