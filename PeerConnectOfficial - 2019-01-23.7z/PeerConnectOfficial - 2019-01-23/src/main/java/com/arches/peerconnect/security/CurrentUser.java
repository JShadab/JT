package com.arches.peerconnect.security;


import org.springframework.security.core.annotation.AuthenticationPrincipal;

import java.lang.annotation.*;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@AuthenticationPrincipal
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.PARAMETER, ElementType.TYPE})
public @interface CurrentUser { }
