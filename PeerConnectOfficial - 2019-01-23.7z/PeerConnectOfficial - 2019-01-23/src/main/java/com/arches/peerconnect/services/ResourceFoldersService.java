package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.ResourceFolder;
import com.arches.peerconnect.models.request.ResourceFolderRequest;
import com.arches.peerconnect.models.request.base.RequestModel;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.ResourceFoldersRepository;
import com.arches.peerconnect.repos.ResourcesRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;


/**
 * @author Anurag Mishra, 2018-12-26
 */
@Service
public class ResourceFoldersService extends PeerConnectEntityService<ResourceFolder> {

    private final ResourcesRepository resourcesRepository;

    public ResourceFoldersService(
        ResourceFoldersRepository resourceFoldersRepository,
        ResourcesRepository resourcesRepository,
        ParentsRepository parentsRepository) {

        super(resourceFoldersRepository, parentsRepository, ErrorCode.E025);

        this.resourcesRepository = resourcesRepository;
    }

    public ResourceFolder create(UUID campaignId, ResourceFolderRequest request) {
        return super.create(campaignId, request, folder -> {
            var featResourceId = request.getFeatResourceId();
            if (featResourceId != null)
                folder.setFeatResource(resourcesRepository.getOne(featResourceId));
        });
    }

    public void update(UUID folderId, ResourceFolderRequest request) {
        super.create(folderId, request, folder -> {
            var featResourceId = request.getFeatResourceId();
            if (featResourceId != null)
                folder.setFeatResource(resourcesRepository.getOne(featResourceId));
        });
    }
}
