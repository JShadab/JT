package com.arches.peerconnect.messaging.senders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

/**
 * @author Anurag Mishra, 2019-01-17
 */
@Component
@Slf4j
public class MessageSender {

    private final RabbitTemplate template;
    private final TopicExchange exchange;

    public MessageSender(RabbitTemplate template, TopicExchange exchange) {
        this.template = template;
        this.exchange = exchange;
    }

    public void send(String route, Object payload) {
        log.info("Sending message to {} on {}: {}", route, exchange.getName(), payload);
        template.convertAndSend(exchange.getName(), route, payload);
    }

}
