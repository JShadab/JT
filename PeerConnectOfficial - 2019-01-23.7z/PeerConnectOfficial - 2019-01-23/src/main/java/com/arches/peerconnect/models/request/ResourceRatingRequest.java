package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.ResourceRating;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Data
public class ResourceRatingRequest implements RequestModel<ResourceRating> {

    @NotNull
    private Integer score;

    @NotNull
    private UUID resourceId;

    @NotNull
    private UUID participantId;

    //

    @Override
    public void mapToEntity(ResourceRating entity) {
        entity.setScore(getScore());
    }

    @Override
    public ResourceRating createNew() {
        var entity = new ResourceRating();
        mapToEntity(entity);
        return entity;
    }

}
