package com.arches.peerconnect.filters;


import com.arches.peerconnect.utils.Constants;

import com.aventrix.jnanoid.jnanoid.NanoIdUtils;

import lombok.Data;
import lombok.EqualsAndHashCode;

import org.slf4j.MDC;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * @author Anurag Mishra, 2019-01-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Component
public class Slf4jMDCFilter extends OncePerRequestFilter {

    private final String requestIdHeader;
    private final String mdcRequestIdKey;
    private final String mdcClientIpKey;
    private final String requestHeader;

    public Slf4jMDCFilter() {
        requestIdHeader = Constants.REQUEST_ID_HEADER;
        mdcRequestIdKey = Constants.MDC_REQUEST_ID_KEY;
        mdcClientIpKey = Constants.MDC_CLIENT_IP_KEY;
        requestHeader = null;
    }

    public Slf4jMDCFilter(final String requestIdHeader, final String mdcRequestIdKey, final String mdcClientIPKey, final String requestHeader) {
        this.requestIdHeader = requestIdHeader;
        this.mdcRequestIdKey = mdcRequestIdKey;
        this.mdcClientIpKey = mdcClientIPKey;
        this.requestHeader = requestHeader;
    }

    @Override
    protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response, final FilterChain chain)
        throws java.io.IOException, ServletException {
        try {
            final String token = extractRequestId(request);
            final String clientIP = extractClientIP(request);
            MDC.put(mdcClientIpKey, clientIP);
            MDC.put(mdcRequestIdKey, token);
            if (!StringUtils.isEmpty(requestIdHeader)) {
                response.addHeader(requestIdHeader, token);
            }
            chain.doFilter(request, response);
        } finally {
            MDC.remove(mdcRequestIdKey);
            MDC.remove(mdcClientIpKey);
        }
    }

    private String extractRequestId(final HttpServletRequest request) {
        final String requestId;
        if (!StringUtils.isEmpty(requestHeader) && !StringUtils.isEmpty(request.getHeader(requestHeader))) {
            requestId = request.getHeader(requestHeader);
        } else {
            requestId = NanoIdUtils.randomNanoId(NanoIdUtils.DEFAULT_NUMBER_GENERATOR, NanoIdUtils.DEFAULT_ALPHABET, 25);
        }
        return requestId;
    }

    private String extractClientIP(final HttpServletRequest request) {
        final String clientIP;
        if (request.getHeader("X-Forwarded-For") != null) {
            clientIP = request.getHeader("X-Forwarded-For").split(",")[0];
        } else {
            clientIP = request.getRemoteAddr();
        }
        return clientIP;
    }

    @Override
    protected boolean isAsyncDispatch(final HttpServletRequest request) {
        return false;
    }

    @Override
    protected boolean shouldNotFilterErrorDispatch() {
        return false;
    }

}
