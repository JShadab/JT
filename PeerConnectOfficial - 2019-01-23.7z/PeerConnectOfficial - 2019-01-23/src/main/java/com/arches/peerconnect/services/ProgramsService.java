package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.Program;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.ProgramsRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;


/**
 * @author Anurag Mishra, 2018-12-26
 */
@Service
public class ProgramsService extends PeerConnectEntityService<Program> {

    public ProgramsService(
        ProgramsRepository programsRepository,
        ParentsRepository parentsRepository) {

        super(programsRepository, parentsRepository, ErrorCode.E034);

    }
}
