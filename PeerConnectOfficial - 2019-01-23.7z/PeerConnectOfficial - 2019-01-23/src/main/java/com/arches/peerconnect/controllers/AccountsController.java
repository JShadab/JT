package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.BaseController;
import com.arches.peerconnect.services.AccountsService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-20
 */
@RestController
public class AccountsController extends BaseController {

    private final AccountsService accountsService;

    public AccountsController(AccountsService accountsService) {
        this.accountsService = accountsService;
    }

    //

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(
        @RequestHeader("Tenant-ID") UUID campaignId,
        @RequestParam("email") String email) {

        accountsService.forgotPassword(campaignId, email);

        return okResponse();
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(
        @RequestHeader("Tenant-ID") UUID campaignId,
        @RequestParam("token") String token,
        @RequestParam("password") String password) {

        accountsService.resetPassword(campaignId, token, password);

        return okResponse();
    }

    @PostMapping("/unsubscribe")
    public ResponseEntity<?> unsubscribe(
        @RequestHeader("Tenant-ID") UUID campaignId,
        @RequestParam("email") String email) {

        accountsService.unsubscribe(campaignId, email);

        return okResponse();
    }

}
