package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.ResourceRating;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
public interface ResourceRatingsRepository extends JpaRepository<ResourceRating, UUID> {

    @Query("SELECT AVG(r.score) FROM ResourceRating r WHERE r.resource.campaign.id = ?1 AND r.resource.id = ?2")
    Double getAverageRatingByResourceId(UUID campaignId, UUID resourceId);

}
