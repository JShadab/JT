package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.Parent;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-26
 */
public interface ParentsRepository extends JpaRepository<Parent, UUID> { }
