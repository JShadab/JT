package com.arches.peerconnect.interceptors;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.security.UserPrincipal;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-26
 */
public class TenantIdValidatorInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        if (request.getRequestURI().contains("swagger-ui.html") ||
                request.getRequestURI().contains("webjars") ||
                request.getRequestURI().contains("/swagger-resources")||
                request.getRequestURI().contains("/configuration")) {
            return true;
        }
        var tenantId = request.getHeader("Tenant-ID");
        if (tenantId == null) {
            throw new ApiException(ErrorCode.E012);
        }

        var userOptional = getCurrentUser();
        if (userOptional.isEmpty()) {
            return true;
        }

        UUID tenantGuid;
        try {
            tenantGuid = UUID.fromString(tenantId);
        } catch (IllegalArgumentException e) {
            throw new ApiException(ErrorCode.E035);
        }

        var user = userOptional.get();
        if (!tenantGuid.equals(user.getCampaignId()))
            throw new ApiException(ErrorCode.E035);

        return true;
    }

    private Optional<UserPrincipal> getCurrentUser() {

        var principal = Optional.ofNullable(SecurityContextHolder.getContext())
                .map(SecurityContext::getAuthentication)
                .filter(Authentication::isAuthenticated)
                .map(Authentication::getPrincipal);

        return principal.isEmpty() || principal.get().getClass() == String.class
                ? Optional.empty()
                : principal.map(UserPrincipal.class::cast);

    }

}
