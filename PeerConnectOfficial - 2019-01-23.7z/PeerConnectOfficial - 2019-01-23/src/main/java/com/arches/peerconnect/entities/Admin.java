package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.Auditable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "Admins")
public class Admin extends Auditable {

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(nullable = false)
    private String emailAddress;

    @Column(nullable = false)
    @JsonIgnore
    private String password;

    @Column(nullable = false)
    private String phoneNumber;

    @Column(nullable = false)
    private Boolean isActive = false;


    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "parentId")
    @JsonIgnore
    private Parent parent;

    @ManyToMany
    @JoinTable(
        name = "AdminRoles",
        joinColumns = @JoinColumn(name = "adminId", referencedColumnName = "id"),
        inverseJoinColumns = @JoinColumn(name = "roleId", referencedColumnName = "id")
    )
    @JsonIgnore
    private Set<Role> roles = new HashSet<>();

    //

    @JsonProperty("parentId")
    public UUID getParentId() {
        return parent.getId();
    }

}
