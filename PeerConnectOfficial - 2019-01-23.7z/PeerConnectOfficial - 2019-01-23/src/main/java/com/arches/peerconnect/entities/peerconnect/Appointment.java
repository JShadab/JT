package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.base.PeerConnectEntity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.time.Instant;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-31
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_Appointments")
public class Appointment extends PeerConnectEntity {

    private Instant captainArrival;

    private Instant participantArrival;

    private Instant completedOn;

    private Instant cancelledOn;

    private String cancelledBy;

    private Integer duration;

    private String externalId;


    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "availabilityId")
    @JsonIgnore
    private Availability availability;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "captainId")
    @JsonIgnore
    private Captain captain;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "participantId")
    @JsonIgnore
    private Participant participant;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "topicId")
    @JsonIgnore
    private Topic topic;

    //

    @JsonProperty("availabilityId")
    public UUID getAvailabilityId() {
        return availability.getId();
    }

    @JsonProperty("captainId")
    public UUID getCaptainId() {
        return captain.getId();
    }

    @JsonProperty("participantId")
    public UUID getParticipantId() {
        return participant.getId();
    }

    @JsonProperty("topicId")
    public UUID getTopicId() {
        return topic.getId();
    }

}
