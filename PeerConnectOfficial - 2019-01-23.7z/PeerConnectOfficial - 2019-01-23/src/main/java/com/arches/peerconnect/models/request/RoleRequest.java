package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.Role;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotEmpty;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@Data
public class RoleRequest implements RequestModel<Role> {

    @NotEmpty
    private String name;

    //

    @Override
    public void mapToEntity(Role entity) {
        entity.setName(getName());
    }

    @Override
    public Role createNew() {
        var entity = new Role();
        mapToEntity(entity);
        return entity;
    }

}
