package com.arches.peerconnect.repos.audit;


import com.arches.peerconnect.entities.audit.AuditTrail;

import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-13
 */
public interface AuditTrailsRepository extends MongoRepository<AuditTrail, String> {

    List<AuditTrail> findByCampaignId(UUID campaignId);

    List<AuditTrail> findByUserId(UUID userId);

    List<AuditTrail> findByEntityId(UUID entityId);

}
