package com.arches.peerconnect.config;


import com.arches.peerconnect.security.AppUserDetailsService;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.client.JdbcClientDetailsService;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JdbcTokenStore;

import javax.sql.DataSource;

import static com.arches.peerconnect.utils.Constants.*;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Slf4j
@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {

    private final DataSource dataSource;

    private final AuthenticationManager authenticationManager;

    private final PasswordEncoder passwordEncoder;

    private final AppUserDetailsService userDetailsService;

    @Autowired
    public AuthorizationServerConfig(
        AuthenticationManager authenticationManager,
        DataSource dataSource,
        PasswordEncoder passwordEncoder,
        AppUserDetailsService userDetailsService) {

        this.authenticationManager = authenticationManager;
        this.dataSource = dataSource;
        this.passwordEncoder = passwordEncoder;
        this.userDetailsService = userDetailsService;

    }

    @Bean
    public TokenStore tokenStore() {
        final var jdbcTokenStore = new JdbcTokenStore(dataSource);
        jdbcTokenStore.setInsertAccessTokenSql(ACCESS_TOKEN_INSERT_STATEMENT);
        jdbcTokenStore.setSelectAccessTokenSql(ACCESS_TOKEN_SELECT_STATEMENT);
        jdbcTokenStore.setSelectAccessTokenAuthenticationSql(ACCESS_TOKEN_AUTHENTICATION_SELECT_STATEMENT);
        jdbcTokenStore.setSelectAccessTokenFromAuthenticationSql(ACCESS_TOKEN_FROM_AUTHENTICATION_SELECT_STATEMENT);
        jdbcTokenStore.setSelectAccessTokensFromUserNameAndClientIdSql(ACCESS_TOKENS_FROM_USERNAME_AND_CLIENT_SELECT_STATEMENT);
        jdbcTokenStore.setSelectAccessTokensFromUserNameSql(ACCESS_TOKENS_FROM_USERNAME_SELECT_STATEMENT);
        jdbcTokenStore.setSelectAccessTokensFromClientIdSql(ACCESS_TOKENS_FROM_CLIENTID_SELECT_STATEMENT);
        jdbcTokenStore.setDeleteAccessTokenSql(ACCESS_TOKEN_DELETE_STATEMENT);
        jdbcTokenStore.setInsertRefreshTokenSql(REFRESH_TOKEN_INSERT_STATEMENT);
        jdbcTokenStore.setSelectRefreshTokenSql(REFRESH_TOKEN_SELECT_STATEMENT);
        jdbcTokenStore.setSelectRefreshTokenAuthenticationSql(REFRESH_TOKEN_AUTHENTICATION_SELECT_STATEMENT);
        jdbcTokenStore.setDeleteRefreshTokenSql(REFRESH_TOKEN_DELETE_STATEMENT);
        jdbcTokenStore.setDeleteAccessTokenFromRefreshTokenSql(ACCESS_TOKEN_DELETE_FROM_REFRESH_TOKEN_STATEMENT);

        return jdbcTokenStore;
    }

    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        final var clientService = new JdbcClientDetailsService(dataSource);
        clientService.setDeleteClientDetailsSql(CLIENT_DELETE_STATEMENT);
        clientService.setFindClientDetailsSql(CLIENT_FIND_STATEMENT);
        clientService.setUpdateClientDetailsSql(CLIENT_UPDATE_STATEMENT);
        clientService.setUpdateClientSecretSql(CLIENT_UPDATE_SECRET_STATEMENT);
        clientService.setInsertClientDetailsSql(CLIENT_INSERT_STATEMENT);
        clientService.setSelectClientDetailsSql(CLIENT_SELECT_STATEMENT);

        clients.withClientDetails(clientService);
    }

    @Bean
    @Primary
    public DefaultTokenServices tokenServices() {
        final var defaultTokenServices = new DefaultTokenServices();
        defaultTokenServices.setTokenStore(tokenStore());
        defaultTokenServices.setSupportRefreshToken(true);
        return defaultTokenServices;
    }

    @Override
    public void configure(AuthorizationServerSecurityConfigurer oauthServer) throws Exception {
        oauthServer
            .allowFormAuthenticationForClients()
            .tokenKeyAccess("permitAll()")
            .checkTokenAccess("isAuthenticated()")
            .passwordEncoder(passwordEncoder);
    }

    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        endpoints
            .tokenStore(tokenStore())
            .authenticationManager(authenticationManager)
            .userDetailsService(userDetailsService);
    }
}
