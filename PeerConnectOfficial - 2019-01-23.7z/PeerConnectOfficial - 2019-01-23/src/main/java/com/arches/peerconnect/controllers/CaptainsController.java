package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Captain;
import com.arches.peerconnect.models.request.CaptainRequest;
import com.arches.peerconnect.services.CaptainsService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
@RestController
@RequestMapping("/captains")
@PreAuthorize("hasRole('ADMIN')")
public class CaptainsController extends PeerConnectBaseController<Captain> {

    private final CaptainsService service;

    public CaptainsController(CaptainsService service) {
        super(service);
        this.service = service;
    }

    //

    @GetMapping("/available")
    public List<Captain> available(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("topicId") UUID topicId) {
        return service.getAvailableCaptainsByTopic(tenantId, topicId);
    }

    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody CaptainRequest request) {

        var result = service.create(tenantId, request);

        return createdResponse(result.getId());
    }

    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody CaptainRequest request) {

        service.update(entityId, request);

        return okResponse();
    }

}
