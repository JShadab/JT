package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.Availability;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;

import java.time.Instant;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-31
 */
@Data
public class AvailabilityRequest implements RequestModel<Availability> {

    @NotNull
    @Future
    private Instant startDate;

    @NotNull
    private UUID captainId;

    //

    @Override
    public void mapToEntity(Availability entity) {
        entity.setStartDate(startDate);
    }

    @Override
    public Availability createNew() {
        var entity = new Availability();
        mapToEntity(entity);
        return entity;
    }

}
