package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Speciality;
import com.arches.peerconnect.repos.base.PeerConnectRepository;


/**
 * @author Anurag Mishra, 2018-12-29
 */
public interface SpecialitiesRepository extends PeerConnectRepository<Speciality> {
}
