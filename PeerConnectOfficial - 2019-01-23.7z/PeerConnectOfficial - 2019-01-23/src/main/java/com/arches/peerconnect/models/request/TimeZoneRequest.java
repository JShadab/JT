package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.peerconnect.TimeZone;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Data
public class TimeZoneRequest implements RequestModel<TimeZone> {

    @NotEmpty
    private String label;

    @NotEmpty
    private String abbr;

    @NotNull
    private int utcOffset;

    @NotNull
    private int dstOffset;

    //

    @Override
    public void mapToEntity(TimeZone entity) {
        entity.setLabel(getLabel());
        entity.setAbbr(getAbbr());
        entity.setUtcOffset(getUtcOffset());
        entity.setDstOffset(getDstOffset());
    }

    @Override
    public TimeZone createNew() {
        var entity = new TimeZone();
        mapToEntity(entity);
        return entity;
    }
}
