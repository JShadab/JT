package com.arches.peerconnect.controllers.base;


import com.arches.peerconnect.entities.base.PeerConnectEntity;
import com.arches.peerconnect.models.request.base.RequestModel;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-27
 */
public class PeerConnectBaseController<T extends PeerConnectEntity> extends BaseController {

    private final PeerConnectEntityService<T> service;

    protected PeerConnectBaseController(PeerConnectEntityService<T> service) {
        this.service = service;
    }

    //

    @GetMapping("")
    public ResponseEntity<?> get(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "id", required = false) UUID entityId) {

        return ResponseEntity.ok(
            entityId != null
                ? service.getByCampaignIdAndId(tenantId, entityId)
                : service.getAllByCampaignId(tenantId)
        );

    }

    protected ResponseEntity<?> create(UUID tenantId, RequestModel<T> request) {
        var result = service.create(tenantId, request);

        return createdResponse(result.getId());
    }

    protected ResponseEntity<?> update(UUID entityId, RequestModel<T> request) {
        service.update(entityId, request);

        return okResponse();
    }

    protected ResponseEntity<?> delete(UUID entityId) {
        service.delete(entityId);

        return okResponse();
    }

}
