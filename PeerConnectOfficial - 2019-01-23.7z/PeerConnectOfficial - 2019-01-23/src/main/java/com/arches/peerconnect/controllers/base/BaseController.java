package com.arches.peerconnect.controllers.base;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.models.response.ApiResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-27
 */
public abstract class BaseController {

    protected ResponseEntity<?> createdResponse(UUID id) {

        var location = ServletUriComponentsBuilder
            .fromCurrentContextPath()
            .queryParam("id", id)
            .build()
            .toUri();

        return ResponseEntity
                    .created(location)
                    .body(ApiResponse.from(ErrorCode.S200));

    }

    protected ResponseEntity<?> okResponse() {
        return ResponseEntity.ok(ApiResponse.from(ErrorCode.S200));
    }

}
