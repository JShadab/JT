package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.BaseController;
import com.arches.peerconnect.models.request.ResourceRatingRequest;
import com.arches.peerconnect.services.ResourceRatingsService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@RestController
@RequestMapping("/resourceRatings")
@PreAuthorize("hasRole('ADMIN')")
public class ResourceRatingsController extends BaseController {

    private final ResourceRatingsService service;

    public ResourceRatingsController(ResourceRatingsService service) {
        this.service = service;
    }

    //

    @GetMapping("")
    public Double averageRating(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("resourceId") UUID resourceId) {
        return service.getAverageRatingByResource(tenantId, resourceId);
    }


    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody ResourceRatingRequest request) {

        var entity = service.create(tenantId, request);

        return createdResponse(entity.getId());
    }

    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody ResourceRatingRequest request) {

        service.update(entityId, request);

        return okResponse();
    }

    @DeleteMapping("")
    public ResponseEntity<?> delete(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId) {

        service.delete(entityId);

        return okResponse();
    }

}
