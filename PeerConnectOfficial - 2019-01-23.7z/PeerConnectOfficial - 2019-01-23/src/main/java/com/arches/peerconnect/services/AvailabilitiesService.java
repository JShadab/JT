package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.enums.OpCode;
import com.arches.peerconnect.entities.peerconnect.Appointment;
import com.arches.peerconnect.entities.peerconnect.Availability;
import com.arches.peerconnect.models.request.AvailabilityRequest;
import com.arches.peerconnect.repos.AppointmentsRepository;
import com.arches.peerconnect.repos.EnrollmentsRepository;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.AvailabilitiesRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
@Service
public class AvailabilitiesService extends PeerConnectEntityService<Availability> {

    private final AvailabilitiesRepository availabilitiesRepository;
    private final EnrollmentsRepository enrollmentsRepository;
    private final AppointmentsRepository appointmentsRepository;

    public AvailabilitiesService(
        AvailabilitiesRepository availabilitiesRepository,
        EnrollmentsRepository enrollmentsRepository,
        AppointmentsRepository appointmentsRepository,
        ParentsRepository parentsRepository) {

        super(availabilitiesRepository, parentsRepository, ErrorCode.E019);

        this.availabilitiesRepository = availabilitiesRepository;
        this.enrollmentsRepository = enrollmentsRepository;
        this.appointmentsRepository = appointmentsRepository;

    }

    //

    public List<Availability> findAllByParams(UUID campaignId, UUID captainId, Date startDate, Date endDate) {
        return availabilitiesRepository.findAllByParams(campaignId, captainId, startDate, endDate);
    }

    public List<Availability> findAllUnused(UUID campaignId, UUID captainId, Date startDate, Date endDate) {
        return availabilitiesRepository.findAllUnused(campaignId, captainId, startDate, endDate);
    }

    public Availability create(UUID campaignId, AvailabilityRequest request) {
        return super.create(campaignId, request, availability ->
            availability.setCaptain(enrollmentsRepository.getOne(request.getCaptainId())));
    }

    public void update(UUID campaignId, AvailabilityRequest request) {
        super.update(campaignId, request, null, availability ->
            availability.setCaptain(enrollmentsRepository.getOne(request.getCaptainId())));
    }

    @Override
    public void delete(UUID entityId) {
        super.delete(entityId);

        var ex = new Appointment();
        ex.setAvailability(entityRepository.getOne(entityId));
        appointmentsRepository
            .findOne(Example.of(ex))
            .ifPresent(appt -> {
                appt.setIsArchived(true);

                appointmentsRepository.save(appt);

                addAuditTrail(appt.getCampaignId(), appt.getId(), appt.getClass().getSimpleName(), OpCode.ARCHIVED, null);
            });
    }

}
