package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Appointment;
import com.arches.peerconnect.repos.base.PeerConnectRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
public interface AppointmentsRepository extends PeerConnectRepository<Appointment> {

    @Query(
        value = "SELECT a.*\n" +
                "FROM   PC_Appointments AS a \n" +
                "       LEFT JOIN PC_Availabilities AS av ON a.availabilityId = av.id\n" +
                "WHERE  a.campaignId = :campaignId\n" +
                "  AND  a.completedOn   IS NULL\n" +
                "  AND  DATEDIFF(minute, GETDATE(), av.startDate) >= 1\n" +
                "  AND  (:captainId     IS NULL OR a.captainId     = :captainId)\n" +
                "  AND  (:participantId IS NULL OR a.participantId = :participantId)\n" +
                "  AND  (:startDate     IS NULL OR av.startDate   >= :startDate)\n" +
                "  AND  (:endDate       IS NULL OR av.startDate   <= :endDate)\n" +
                "ORDER BY av.startDate ASC",
        nativeQuery = true)
    List<Appointment> findAllUpcoming(
        @Param("campaignId") UUID campaignId,
        @Param("captainId") UUID captainId,
        @Param("participantId") UUID participantId,
        @Param("startDate") Date startDate,
        @Param("endDate") Date endDate);

    @Query(
        "SELECT a\n" +
        "FROM   Appointment a\n" +
        "WHERE  a.campaign.id = :campaignId\n" +
        "  AND  a.completedOn   IS NOT NULL\n" +
        "  AND  (:captainId     IS NULL OR a.captain.id              = :captainId)\n" +
        "  AND  (:participantId IS NULL OR a.participant.id          = :participantId)\n" +
        "  AND  (:startDate     IS NULL OR a.availability.startDate >= :startDate)\n" +
        "  AND  (:endDate       IS NULL OR a.availability.startDate <= :endDate)\n" +
        "ORDER BY a.availability.startDate DESC")
    List<Appointment> findAllCompleted(
        @Param("campaignId") UUID campaignId,
        @Param("captainId") UUID captainId,
        @Param("participantId") UUID participantId,
        @Param("startDate") Date startDate,
        @Param("endDate") Date endDate);

}
