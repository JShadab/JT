package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Appointment;
import com.arches.peerconnect.models.request.AppointmentRequest;
import com.arches.peerconnect.security.CurrentUser;
import com.arches.peerconnect.security.UserPrincipal;
import com.arches.peerconnect.services.AppointmentsService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.Date;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-02
 */
@RestController
@RequestMapping("/appointments")
@PreAuthorize("hasRole('ADMIN')")
public class AppointmentsController extends PeerConnectBaseController<Appointment> {

    private final AppointmentsService service;

    public AppointmentsController(AppointmentsService service) {
        super(service);
        this.service = service;
    }

    //

    @GetMapping("/upcoming")
    public List<Appointment> getAllUpcoming(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "captainId", required = false) UUID captainId,
        @RequestParam(value = "participantId", required = false) UUID participantId,
        @RequestParam(value = "startDate", required = false) Date startDate,
        @RequestParam(value = "endDate", required = false) Date endDate) {

        return service.findAllUpcoming(tenantId, captainId, participantId, startDate, endDate);

    }

    @GetMapping("/completed")
    public List<Appointment> getAllCompleted(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "captainId", required = false) UUID captainId,
        @RequestParam(value = "participantId", required = false) UUID participantId,
        @RequestParam(value = "startDate", required = false) Date startDate,
        @RequestParam(value = "endDate", required = false) Date endDate) {

        return service.findAllCompleted(tenantId, captainId, participantId, startDate, endDate);

    }

    @PostMapping("/captainArrival")
    public ResponseEntity<?> markCaptainArrival(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId,
        @RequestParam(value = "captainId") UUID captainId) {

        service.markCaptainArrival(tenantId, appointmentId, captainId);

        return okResponse();

    }

    @PostMapping("/participantArrival")
    public ResponseEntity<?> markParticipantArrival(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId,
        @RequestParam(value = "participantId") UUID participantId) {

        service.markParticipantArrival(tenantId, appointmentId, participantId);

        return okResponse();

    }

    @PostMapping("/completedAppointment")
    public ResponseEntity<?> markAppointmentComplete(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId,
        @RequestParam(value = "duration") int duration,
        @RequestParam(value = "externalId") String externalId) {

        service.markAppointmentComplete(tenantId, appointmentId, duration, externalId);

        return okResponse();

    }

    @PostMapping("/sendDueReminder")
    public ResponseEntity<?> sendDueReminder(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId) {

        service.sendAppointmentDueReminder(tenantId, appointmentId);

        return okResponse();

    }

    @PostMapping("/sendOffLabelRequest")
    public ResponseEntity<?> sendOffLabelRequest(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "appointmentId") UUID appointmentId) {

        service.sendOffLabelRequest(tenantId, appointmentId);

        return okResponse();

    }

    @PostMapping("/sendSupportRequest")
    public ResponseEntity<?> sendSupportRequest(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("supportTopicId") UUID supportTopicId,
        @RequestParam("name") String name,
        @RequestParam("email") String email) {

        service.sendSupportRequest(tenantId, supportTopicId, name, email);

        return okResponse();

    }


    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody AppointmentRequest request) {

        var entity = service.create(tenantId, request);

        return createdResponse(entity.getId());
    }

    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody AppointmentRequest request) {

        service.update(entityId, request);

        return okResponse();
    }

    @DeleteMapping("")
    public ResponseEntity<?> delete(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @CurrentUser UserPrincipal principal) {

        service.delete(tenantId, entityId, principal);

        return okResponse();
    }

}
