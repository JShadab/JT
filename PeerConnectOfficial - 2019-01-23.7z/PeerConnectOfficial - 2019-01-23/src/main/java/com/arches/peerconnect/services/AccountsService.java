package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.PasswordResetToken;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.enums.OpCode;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.repos.AdminsRepository;
import com.arches.peerconnect.repos.EnrollmentsRepository;
import com.arches.peerconnect.repos.PasswordResetTokensRepository;
import com.arches.peerconnect.repos.UsersRepository;
import com.arches.peerconnect.services.audit.AuditTrailsService;
import com.arches.peerconnect.utils.CommonUtils;

import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-20
 */
@Service
public class AccountsService {

    private final UsersRepository usersRepository;
    private final AdminsRepository adminsRepository;
    private final EnrollmentsRepository enrollmentsRepository;
    private final PasswordResetTokensRepository resetTokensRepository;
    private final AuditTrailsService auditTrailsService;
    private final NotificationsService notificationsService;
    private final BCryptPasswordEncoder passwordEncoder;

    public AccountsService(
        UsersRepository usersRepository,
        AdminsRepository adminsRepository,
        EnrollmentsRepository enrollmentsRepository,
        PasswordResetTokensRepository resetTokensRepository,
        AuditTrailsService auditTrailsService,
        NotificationsService notificationsService,
        BCryptPasswordEncoder passwordEncoder) {

        this.usersRepository = usersRepository;
        this.adminsRepository = adminsRepository;
        this.enrollmentsRepository = enrollmentsRepository;
        this.resetTokensRepository = resetTokensRepository;
        this.auditTrailsService = auditTrailsService;
        this.notificationsService = notificationsService;
        this.passwordEncoder = passwordEncoder;

    }

    //

    public void forgotPassword(UUID campaignId, String email) {
        var user = usersRepository.findByCampaignIdAndEmailAddress(campaignId, email)
                                  .orElseThrow(() -> new ApiException(ErrorCode.E037));

        var token = CommonUtils.generateNanoId(36);
        var resetToken = new PasswordResetToken(campaignId, user.getId(), token);

        resetTokensRepository.save(resetToken);

        var payload = new Object() {
            public String email = user.getEmailAddress();
            public String token = resetToken.getToken();
        };
        auditTrailsService.create(campaignId, user.getId(), user.getClass().getSimpleName(), OpCode.FORGOTPASSWORD, payload);

        notificationsService.sendForgotPasswordEmail(user.getEmailAddress(), token);
    }

    public void resetPassword(UUID campaignId, String token, String password) {
        var resetToken = resetTokensRepository.getByCampaignIdAndToken(campaignId, token)
                                              .orElseThrow(() -> new ApiException(ErrorCode.E011));

        if (resetToken.isExpired())
            throw new ApiException(ErrorCode.E038);

        var user = usersRepository.findByCampaignIdAndId(campaignId, resetToken.getUserId())
                                  .orElseThrow(() -> new ApiException(ErrorCode.E037));

        if (user.getRolesList().contains("ROLE_ADMIN")) {

            var admin = adminsRepository.findById(user.getId())
                                        .orElseThrow(() -> new ApiException(ErrorCode.E011));
            admin.setPassword(passwordEncoder.encode(password));

            adminsRepository.save(admin);

            var payload = new Object() {
                public String token = resetToken.getToken();
                public String getPassword() {
                    return password;
                }
            };
            auditTrailsService.create(campaignId, admin.getId(), admin.getClass().getSimpleName(), OpCode.RESETPASSWORD, payload);

        } else {

            var enrollment = enrollmentsRepository.getByCampaign_IdAndId(campaignId, user.getId())
                                                  .orElseThrow(() -> new ApiException(ErrorCode.E011));

            try {
                var jsonObject = new JSONObject(enrollment.getResponse());
                jsonObject.put("password", password);

                enrollment.setResponse(jsonObject.toString());
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            enrollmentsRepository.save(enrollment);

            var payload = new Object() {
                public String token = resetToken.getToken();
                public String getPassword() {
                    return password;
                }
            };
            auditTrailsService.create(campaignId, enrollment.getId(), enrollment.getClass().getSimpleName(), OpCode.RESETPASSWORD, payload);
        }
    }

    public void unsubscribe(UUID campaignId, String email) {
        var user = usersRepository.findByCampaignIdAndEmailAddress(campaignId, email)
                                  .orElseThrow(() -> new ApiException(ErrorCode.E037));

        var enrollment = enrollmentsRepository.getByCampaign_IdAndId(campaignId, user.getId())
                                              .orElseThrow(() -> new ApiException(ErrorCode.E011));

        JSONObject jsonObject;
        try {
            jsonObject = new JSONObject(enrollment.getResponse());
            jsonObject.put("unsubscribed", true);

            enrollment.setResponse(jsonObject.toString());

            enrollmentsRepository.save(enrollment);

            var payload = new Object() {
                public String email = user.getEmailAddress();
                public Boolean unsubscribe = true;
            };
            auditTrailsService.create(campaignId, enrollment.getId(), enrollment.getClass().getSimpleName(), OpCode.UNSUBSCRIBED, payload);

            notificationsService
                .sendUnsubscribeEmail(
                    jsonObject.getString("firstName"),
                    jsonObject.getString("lastName"),
                    jsonObject.getString("emailAddress")
                );
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}
