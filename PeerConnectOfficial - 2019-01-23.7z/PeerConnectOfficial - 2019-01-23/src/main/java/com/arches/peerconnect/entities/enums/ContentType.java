package com.arches.peerconnect.entities.enums;

/**
 * @author Anurag Mishra, 2018-12-24
 */
public enum ContentType {

    png,
    gif,
    jpg,
    mp4,
    pdf,
    ppt,
    avi,
    url,
    html

}
