package com.arches.peerconnect.models.response;

import lombok.Value;

import java.util.UUID;

/**
 * @author Anurag Mishra, 2018-12-31
 */
@Value
public class RatingsSummaryResponse {

    private final UUID resourceId;

    private final double avgScore;

}
