package com.arches.peerconnect.services.audit;


import com.arches.peerconnect.entities.audit.AuditTrail;
import com.arches.peerconnect.entities.enums.OpCode;

import com.arches.peerconnect.repos.audit.AuditTrailsRepository;
import org.springframework.stereotype.Service;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-13
 */
@Service
public class AuditTrailsService {

    private final AuditTrailsRepository repository;

    public AuditTrailsService(AuditTrailsRepository repository) {
        this.repository = repository;
    }

    public void create(UUID campaignId, UUID entityId, String type, OpCode opCode, Object payload) {
        var auditTrail = new AuditTrail();
        auditTrail.setCampaignId(campaignId);
        auditTrail.setEntityId(entityId);
        auditTrail.setType(type);
        auditTrail.setOpCode(opCode);
        auditTrail.setPayload(payload);

        repository.save(auditTrail);
    }

}
