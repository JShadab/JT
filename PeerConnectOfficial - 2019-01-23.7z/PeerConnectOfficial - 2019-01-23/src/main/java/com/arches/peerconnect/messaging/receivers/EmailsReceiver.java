package com.arches.peerconnect.messaging.receivers;


import com.arches.peerconnect.models.message.EmailMessage;

import com.microtripit.mandrillapp.lutung.MandrillApi;
import com.microtripit.mandrillapp.lutung.model.MandrillApiError;
import com.microtripit.mandrillapp.lutung.view.MandrillMessage;
import com.microtripit.mandrillapp.lutung.view.MandrillMessage.MergeVar;
import com.microtripit.mandrillapp.lutung.view.MandrillMessage.MergeVarBucket;
import com.microtripit.mandrillapp.lutung.view.MandrillMessage.Recipient;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * @author Anurag Mishra, 2019-01-16
 */
@Slf4j
@Component
public class EmailsReceiver {

    @Value("${app.mandrill.api-key}")
    private String apiKey;


    @RabbitListener(queues = "#{emailsQueue.name}")
    public void receive(final EmailMessage msg) throws IOException, MandrillApiError {
        log.info("Email Receiver received message: {}", msg);
        sendEmail(msg);
    }


    private void sendEmail(final EmailMessage msg) throws IOException, MandrillApiError {
        var api = new MandrillApi(apiKey);

        var mergeVars = msg.getTemplateProps()
                           .entrySet()
                           .stream()
                           .map(this::mapMergeVarFromEntry)
                           .collect(Collectors.toList());

        var recipients = msg.getRecipients()
                            .entrySet()
                            .stream()
                            .map(this::mapRecipientFromEntry)
                            .collect(Collectors.toList());

        var email = new MandrillMessage();
        email.setFromName("Peer Connect");
        email.setFromEmail("pca@archestechnology.com");
        email.setTo(recipients);
        email.setSubject(msg.getSubject());
        email.setGlobalMergeVars(mergeVars);

        var results = api.messages().sendTemplate(msg.getTemplateId(), null, email, false);

        for (var result : results)
            log.info("Send Result: {} - {} [{}]", result.getEmail(), result.getStatus(), result.getRejectReason());
    }

    private MergeVar mapMergeVarFromEntry(Map.Entry<String, String> entry) {
        var mv = new MergeVar();
        mv.setName(entry.getKey());
        mv.setContent(entry.getValue());

        return mv;
    }

    private Recipient mapRecipientFromEntry(Map.Entry<String, String> entry) {
        var to = new Recipient();
        to.setName(entry.getKey());
        to.setEmail(entry.getValue());
        to.setType(Recipient.Type.TO);

        return to;
    }

    private MergeVarBucket mapMergeVarBucketFromRecipient(Recipient recipient, MergeVar[] vars) {
        var bucket = new MergeVarBucket();
        bucket.setRcpt(recipient.getEmail());
        bucket.setVars(vars);

        return bucket;
    }

}
