package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.Enrollment;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.enums.OpCode;
import com.arches.peerconnect.entities.peerconnect.Captain;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.request.CaptainRequest;
import com.arches.peerconnect.repos.*;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
@Service
public class CaptainsService extends PeerConnectEntityService<Captain> {

    private final CaptainsRepository captainsRepository;
    private final EnrollmentsRepository enrollmentsRepository;
    private final UsersRepository usersRepository;
    private final SurveysRepository surveysRepository;

    public CaptainsService(
        CaptainsRepository captainsRepository,
        EnrollmentsRepository enrollmentsRepository,
        UsersRepository usersRepository,
        SurveysRepository surveysRepository,
        ParentsRepository parentsRepository) {

        super(captainsRepository, parentsRepository, ErrorCode.E022);

        this.captainsRepository = captainsRepository;
        this.enrollmentsRepository = enrollmentsRepository;
        this.usersRepository = usersRepository;
        this.surveysRepository = surveysRepository;

    }

    //

    public List<Captain> getAvailableCaptainsByTopic(UUID campaignId, UUID topicId) {
        return captainsRepository.getAvailableCaptainsByTopic(campaignId, topicId);
    }

    public Enrollment create(UUID campaignId, CaptainRequest request) {

        var user = usersRepository.findByCampaignIdAndEmailAddress(campaignId, request.getEmailAddress());

        if (user.isPresent())
            throw new ApiException(ErrorCode.E016);

        var enrollment = request.createNew();

        var surveyId = surveysRepository.getEnrollmentSurveyByCampaignId(campaignId);

        enrollment.setCampaign(parentsRepository.getOne(campaignId));
        enrollment.setSurvey(surveysRepository.getOne(surveyId));

        var result = enrollmentsRepository.save(enrollment);

        addAuditTrail(campaignId, result.getId(), enrollment.getClass().getSimpleName(), OpCode.CREATED, request);

        return result;
    }

    public void update(UUID captainId, CaptainRequest request) {
        var enrollment = enrollmentsRepository
                              .findById(captainId)
                              .orElseThrow(() -> new ApiException(ErrorCode.E022));

        request.mapToEntity(enrollment);

        enrollmentsRepository.save(enrollment);

        addAuditTrail(enrollment.getCampaignId(), enrollment.getId(), enrollment.getClass().getSimpleName(), OpCode.UPDATED, request);
    }
}
