package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Participant;
import com.arches.peerconnect.repos.base.PeerConnectRepository;


/**
 * @author Anurag Mishra, 2018-12-31
 */
public interface ParticipantsRepository extends PeerConnectRepository<Participant> { }
