package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Participant;
import com.arches.peerconnect.models.request.ParticipantRequest;
import com.arches.peerconnect.services.ParticipantsService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
@RestController
@RequestMapping("/participants")
@PreAuthorize("hasRole('ADMIN')")
public class ParticipantsController extends PeerConnectBaseController<Participant> {

    private final ParticipantsService service;

    public ParticipantsController(ParticipantsService service) {
        super(service);
        this.service = service;
    }

    //

    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody ParticipantRequest request) {

        var result = service.create(tenantId, request);

        return createdResponse(result.getId());
    }

    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody ParticipantRequest request) {

        service.update(entityId, request);

        return okResponse();
    }

}
