package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.ResourceRating;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.request.ResourceRatingRequest;
import com.arches.peerconnect.repos.EnrollmentsRepository;
import com.arches.peerconnect.repos.ResourceRatingsRepository;
import com.arches.peerconnect.repos.ResourcesRepository;
import com.arches.peerconnect.services.base.EntityService;

import org.springframework.stereotype.Service;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Service
public class ResourceRatingsService extends EntityService<ResourceRating> {

    private final ResourceRatingsRepository resourceRatingsRepository;
    private final ResourcesRepository resourcesRepository;
    private final EnrollmentsRepository enrollmentsRepository;

    public ResourceRatingsService(
        ResourceRatingsRepository resourceRatingsRepository,
        ResourcesRepository resourcesRepository,
        EnrollmentsRepository enrollmentsRepository) {

        super(resourceRatingsRepository, ErrorCode.E011);

        this.resourceRatingsRepository = resourceRatingsRepository;
        this.resourcesRepository = resourcesRepository;
        this.enrollmentsRepository = enrollmentsRepository;

    }

    //

    public Double getAverageRatingByResource(UUID campaignId, UUID resourceId) {

        if (!resourcesRepository.existsById(resourceId))
            throw new ApiException(ErrorCode.E026);

        return resourceRatingsRepository.getAverageRatingByResourceId(campaignId, resourceId);
    }

    public ResourceRating create(UUID campaignId, ResourceRatingRequest request) {
        return super.create(campaignId, request, rating -> {
            rating.setResource(resourcesRepository.getOne(request.getResourceId()));
            rating.setParticipant(enrollmentsRepository.getOne(request.getParticipantId()));
        });
    }

    public void update(UUID campaignId, ResourceRatingRequest request) {
        super.update(campaignId, request, null, rating -> {
            rating.setResource(resourcesRepository.getOne(request.getResourceId()));
            rating.setParticipant(enrollmentsRepository.getOne(request.getParticipantId()));
        });
    }
}
