package com.arches.peerconnect.entities.base;


import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class QuestionOption extends Auditable {

    @Id
    @Type(type = "uuid-char")
    @Column(columnDefinition = "uniqueidentifier", nullable = false)
    @GenericGenerator(name = "guid-generator", strategy = "uuid2")
    @GeneratedValue(generator = "guid-generator")
    private UUID id;

    @Column(nullable = false)
    private String value;

    private String text;

    @Column(nullable = false)
    private Boolean isActive = true;

}
