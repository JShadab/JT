package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.SupportTopic;
import com.arches.peerconnect.models.request.SupportTopicRequest;
import com.arches.peerconnect.services.SupportTopicsService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@RestController
@RequestMapping("/supportTopics")
@PreAuthorize("hasRole('ADMIN')")
public class SupportTopicsController extends PeerConnectBaseController<SupportTopic> {

    public SupportTopicsController(SupportTopicsService service) {
        super(service);
    }

    //

    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody SupportTopicRequest request) {

        return super.create(tenantId, request);

    }

    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody SupportTopicRequest request) {

        return super.update(entityId, request);

    }

}
