package com.arches.peerconnect.config;


import com.arches.peerconnect.filters.Slf4jMDCFilter;
import com.arches.peerconnect.utils.Constants;

import lombok.Data;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @author Anurag Mishra, 2019-01-13
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "app.slf4j-filter")
public class Slf4jMDCFilterConfig {

    private String requestIdHeader = Constants.REQUEST_ID_HEADER;
    private String mdcRequestIdKey = Constants.MDC_REQUEST_ID_KEY;
    private String mdcClientIpKey = Constants.MDC_CLIENT_IP_KEY;
    private String requestHeader = null;

    @Bean
    public FilterRegistrationBean servletRegistrationBean() {
        final var registrationBean = new FilterRegistrationBean();
        final var log4jMDCFilterFilter = new Slf4jMDCFilter(requestIdHeader, mdcRequestIdKey, mdcClientIpKey, requestHeader);
        registrationBean.setFilter(log4jMDCFilterFilter);
        registrationBean.setOrder(2);

        return registrationBean;
    }


}
