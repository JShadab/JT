package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ContactMethod;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.enums.OpCode;
import com.arches.peerconnect.entities.peerconnect.Appointment;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.request.AppointmentRequest;
import com.arches.peerconnect.repos.*;
import com.arches.peerconnect.security.UserPrincipal;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;


/**
 * @author Anurag Mishra, 2019-01-02
 */
@Service
public class AppointmentsService extends PeerConnectEntityService<Appointment> {

    private final AppointmentsRepository appointmentsRepository;
    private final AvailabilitiesRepository availabilitiesRepository;
    private final CaptainsRepository captainsRepository;
    private final ParticipantsRepository participantsRepository;
    private final TopicsRepository topicsRepository;
    private final NotificationsService notificationsService;

    public AppointmentsService(
        AppointmentsRepository appointmentsRepository,
        AvailabilitiesRepository availabilitiesRepository,
        CaptainsRepository captainsRepository,
        ParticipantsRepository participantsRepository,
        TopicsRepository topicsRepository,
        ParentsRepository parentsRepository,
        NotificationsService notificationsService) {

        super(appointmentsRepository, parentsRepository, ErrorCode.E020);

        this.appointmentsRepository = appointmentsRepository;
        this.availabilitiesRepository = availabilitiesRepository;
        this.captainsRepository = captainsRepository;
        this.participantsRepository = participantsRepository;
        this.topicsRepository = topicsRepository;
        this.notificationsService = notificationsService;

    }

    //

    public List<Appointment> findAllUpcoming(
        UUID campaignId, UUID captainId, UUID participantId, Date startDate, Date endDate) {

        return appointmentsRepository.findAllUpcoming(campaignId, captainId, participantId, startDate, endDate);
    }

    public List<Appointment> findAllCompleted(
        UUID campaignId, UUID captainId, UUID participantId, Date startDate, Date endDate) {

        return appointmentsRepository.findAllCompleted(campaignId, captainId, participantId, startDate, endDate);
    }

    public void markCaptainArrival(UUID campaignId, UUID appointmentId, UUID captainId) {
        var appointment = getByCampaignIdAndId(campaignId, appointmentId);

        if (!appointment.getCaptainId().equals(captainId))
            throw new ApiException(ErrorCode.E022);

        appointment.setCaptainArrival(Instant.now());

        appointmentsRepository.save(appointment);

        var payload = new Object() { public Instant captainArrival = appointment.getCaptainArrival(); };
        addAuditTrail(campaignId, appointmentId, appointment.getClass().getSimpleName(), OpCode.UPDATED, payload);
    }

    public void markParticipantArrival(UUID campaignId, UUID appointmentId, UUID participantId) {
        var appointment = getByCampaignIdAndId(campaignId, appointmentId);

        if (!appointment.getParticipantId().equals(participantId))
            throw new ApiException(ErrorCode.E021);

        appointment.setParticipantArrival(Instant.now());

        appointmentsRepository.save(appointment);

        var payload = new Object() { public Instant participantArrival = appointment.getParticipantArrival(); };
        addAuditTrail(campaignId, appointmentId, appointment.getClass().getSimpleName(), OpCode.UPDATED, payload);
    }

    public void markAppointmentComplete(UUID campaignId, UUID appointmentId, int duration, String externalId) {
        var appointment = getByCampaignIdAndId(campaignId, appointmentId);

        if (appointment.getCompletedOn() != null)
            throw new ApiException(ErrorCode.E042);

        appointment.setCompletedOn(Instant.now());
        appointment.setDuration(duration);
        appointment.setExternalId(externalId);

        appointmentsRepository.save(appointment);

        var payload = new Object() {
            public Instant completedOn = appointment.getCompletedOn();
            public Integer duration = appointment.getDuration();
            public String externalId = appointment.getExternalId();
        };
        addAuditTrail(campaignId, appointmentId, appointment.getClass().getSimpleName(), OpCode.UPDATED, payload);
    }

    public void sendAppointmentDueReminder(UUID campaignId, UUID appointmentId) {
        var appointment = getByCampaignIdAndId(campaignId, appointmentId);

        notificationsService.sendAppointmentDueReminder(campaignId, appointment, ContactMethod.SMS);
    }

    public void sendOffLabelRequest(UUID campaignId, UUID appointmentId) {
        var appointment = getByCampaignIdAndId(campaignId, appointmentId);

        notificationsService.sendOffLabelRequest(appointment, ContactMethod.Both);
    }

    public void sendSupportRequest(UUID campaignId, UUID supportTopicId, String name, String phone) {
        notificationsService.sendSupportRequest(campaignId, supportTopicId, name, phone);
    }

    public Appointment create(UUID campaignId, AppointmentRequest request) {
        var appointment = super.create(campaignId, request, appointmentConsumer(request));

        notificationsService.sendAppointmentScheduledConfirmation(campaignId, appointment);

        return appointment;
    }

    public void update(UUID campaignId, AppointmentRequest request) {
        super.update(campaignId, request, null, appointmentConsumer(request));
    }

    public void delete(UUID campaignId, UUID appointmentId, UserPrincipal principal) {
        var entity = appointmentsRepository.findById(appointmentId)
                                           .orElseThrow(() -> new ApiException(entityErrorCode));

        var userType = principal.getAuthorities()
                                .contains(new SimpleGrantedAuthority("ROLE_CAPTAIN")) ? "Captain" : "Participant";

        entity.setIsArchived(true);
        entity.setCancelledOn(Instant.now());
        entity.setCancelledBy(userType);

        entityRepository.save(entity);

        addAuditTrail(campaignId, entity.getId(), entity.getClass().getSimpleName(), OpCode.ARCHIVED, null);

        if (userType.equals("Captain"))
            notificationsService.sendAppointmentCancelledNotificationToParticipant(campaignId, entity);
        else
            notificationsService.sendAppointmentCancelledNotificationToCaptain(campaignId, entity);
    }

    //

    private Consumer<Appointment> appointmentConsumer(AppointmentRequest request) {
        return appointment -> {
            appointment.setAvailability(availabilitiesRepository.getOne(request.getAvailabilityId()));
            appointment.setCaptain(captainsRepository.getOne(request.getCaptainId()));
            appointment.setParticipant(participantsRepository.getOne(request.getParticipantId()));
            appointment.setTopic(topicsRepository.getOne(request.getTopicId()));
        };
    }
}
