package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.Resource;
import com.arches.peerconnect.models.request.ResourceRequest;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.ResourceFoldersRepository;
import com.arches.peerconnect.repos.ResourcesRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-28
 */
@Service
public class ResourcesService extends PeerConnectEntityService<Resource> {

    private final ResourceFoldersRepository foldersRepository;

    public ResourcesService(
        ResourcesRepository resourcesRepository,
        ResourceFoldersRepository foldersRepository,
        ParentsRepository parentsRepository) {

        super(resourcesRepository, parentsRepository, ErrorCode.E026);

        this.foldersRepository = foldersRepository;
    }

    public Resource create(UUID campaignId, ResourceRequest request) {
        return super.create(campaignId, request, resource ->
            resource.setFolder(foldersRepository.getOne(request.getFolderId())));
    }

    public void update(UUID resourceId, ResourceRequest request) {
        super.update(resourceId, request, null, resource ->
            resource.setFolder(foldersRepository.getOne(request.getFolderId())));
    }
}
