package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.BaseController;
import com.arches.peerconnect.entities.peerconnect.Availability;
import com.arches.peerconnect.models.request.AvailabilityRequest;
import com.arches.peerconnect.services.AvailabilitiesService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.Date;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-01
 */
@RestController
@RequestMapping("/availabilities")
@PreAuthorize("hasRole('ADMIN')")
public class AvailabilitiesController extends BaseController {

    private final AvailabilitiesService service;

    public AvailabilitiesController(AvailabilitiesService service) {
        this.service = service;
    }

    //

    @GetMapping("")
    public List<Availability> get(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("captainId") UUID captainId,
        @RequestParam(value = "startDate", required = false) Date startDate,
        @RequestParam(value = "endDate", required = false) Date endDate) {

        return service.findAllByParams(tenantId, captainId, startDate, endDate);
    }

    @GetMapping("/unused")
    public List<Availability> getAllUnused(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("captainId") UUID captainId,
        @RequestParam(value = "startDate", required = false) Date startDate,
        @RequestParam(value = "endDate", required = false) Date endDate) {

        return service.findAllUnused(tenantId, captainId, startDate, endDate);
    }

    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody AvailabilityRequest request) {

        var result = service.create(tenantId, request);

        return createdResponse(result.getId());
    }

    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody AvailabilityRequest request) {

        service.update(entityId, request);

        return okResponse();
    }

    @DeleteMapping("")
    public ResponseEntity<?> delete(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId) {

        service.delete(entityId);

        return okResponse();
    }

}
