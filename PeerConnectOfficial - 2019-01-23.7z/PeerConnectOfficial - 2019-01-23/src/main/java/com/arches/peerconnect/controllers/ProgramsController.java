package com.arches.peerconnect.controllers;


import com.arches.peerconnect.controllers.base.PeerConnectBaseController;
import com.arches.peerconnect.entities.peerconnect.Program;
import com.arches.peerconnect.models.request.ProgramRequest;
import com.arches.peerconnect.services.ProgramsService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-26
 */
@RestController
@RequestMapping("/programs")
@PreAuthorize("hasRole('ADMIN')")
public class ProgramsController extends PeerConnectBaseController<Program> {

    public ProgramsController(ProgramsService service) {
        super(service);
    }

    //

    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody ProgramRequest request) {

        return super.create(tenantId, request);

    }

    @PutMapping("")
    public ResponseEntity<?> update(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID entityId,
        @Valid @RequestBody ProgramRequest request) {

        return super.update(entityId, request);

    }

}
