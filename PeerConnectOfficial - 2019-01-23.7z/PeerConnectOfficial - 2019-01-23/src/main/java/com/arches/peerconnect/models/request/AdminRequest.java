package com.arches.peerconnect.models.request;


import com.arches.peerconnect.entities.Admin;
import com.arches.peerconnect.models.request.base.RequestModel;

import lombok.EqualsAndHashCode;
import lombok.Value;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


/**
 * @author Anurag Mishra, 2018-12-27
 */
@Value
@EqualsAndHashCode
public class AdminRequest implements RequestModel<Admin> {

    @NotEmpty
    private String firstName;

    @NotEmpty
    private String lastName;

    @NotEmpty
    @Email
    private String emailAddress;

    @NotEmpty
    private String password;

    @NotEmpty
    private String phoneNumber;

    @NotNull
    private Boolean isActive;

    //

    @Override
    public void mapToEntity(Admin entity) {
        entity.setFirstName(getFirstName());
        entity.setLastName(getLastName());
        entity.setEmailAddress(getEmailAddress());
        entity.setPassword(getPassword());
        entity.setPhoneNumber(getPhoneNumber());
        entity.setIsActive(getIsActive());
    }

    @Override
    public Admin createNew() {
        var admin = new Admin();
        mapToEntity(admin);
        return admin;
    }

}
