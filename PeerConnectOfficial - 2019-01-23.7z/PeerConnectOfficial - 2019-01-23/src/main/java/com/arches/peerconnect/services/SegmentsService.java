package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.Segment;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.SegmentsRepository;
import com.arches.peerconnect.services.base.PeerConnectEntityService;

import org.springframework.stereotype.Service;


/**
 * @author Anurag Mishra, 2018-12-29
 */
@Service
public class SegmentsService extends PeerConnectEntityService<Segment> {

    public SegmentsService(
        SegmentsRepository segmentsRepository,
        ParentsRepository parentsRepository) {

        super(segmentsRepository, parentsRepository, ErrorCode.E033);

    }

}
