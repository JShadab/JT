package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.PasswordResetToken;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-21
 */
public interface PasswordResetTokensRepository extends JpaRepository<PasswordResetToken, UUID> {

    Optional<PasswordResetToken> getByCampaignIdAndToken(UUID campaignId, String token);

}
