package com.arches.peerconnect.entities.audit;


import com.arches.peerconnect.entities.enums.OpCode;

import lombok.Data;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

import java.time.Instant;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2019-01-13
 */
@Data
@Document("auditTrails")
public class AuditTrail {

    @Id
    private String id;

    private UUID campaignId;

    @CreatedBy
    private UUID userId;

    private UUID entityId;

    private String type;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private OpCode opCode;

    private Object payload;

    @CreatedDate
    private Instant timestamp;

}
