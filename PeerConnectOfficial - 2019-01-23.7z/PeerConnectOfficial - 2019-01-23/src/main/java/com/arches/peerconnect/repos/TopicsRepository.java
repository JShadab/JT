package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Topic;
import com.arches.peerconnect.repos.base.PeerConnectRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-29
 */
public interface TopicsRepository extends PeerConnectRepository<Topic> {

    @Query(
        value =
            "WITH MaxCnt AS (\n" +
            "  SELECT maxParticipantSessions FROM PC_Programs WHERE campaignId = :campaignId\n" +
            "),\n" +
            "ExhaustedTopics AS (\n" +
            "  SELECT   topicId\n" +
            "  FROM     PC_Appointments\n" +
            "  WHERE    participantId = :participantId\n" +
            "  GROUP BY participantId, topicId\n" +
            "  HAVING   COUNT(topicid) >= (SELECT TOP 1 maxParticipantSessions FROM MaxCnt)\n" +
            ")\n" +
            "SELECT * FROM PC_Topics WHERE id NOT IN (SELECT topicId FROM ExhaustedTopics)",
        nativeQuery = true)
    List<Topic> getAvailableTopicsByParticipant(
        @Param("campaignId") UUID campaignId, @Param("participantId") UUID participantId);

}
