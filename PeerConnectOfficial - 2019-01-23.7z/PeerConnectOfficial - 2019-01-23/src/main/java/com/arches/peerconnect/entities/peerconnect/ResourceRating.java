package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.Enrollment;
import com.arches.peerconnect.entities.base.Auditable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_ResourceRatings")
public class ResourceRating extends Auditable {

    @Column(nullable = false)
    private Integer score;


    @ManyToOne
    @JoinColumn(name = "resourceId")
    @JsonIgnore
    private Resource resource;

    @ManyToOne
    @JoinColumn(name = "participantId")
    @JsonIgnore
    private Enrollment participant;

    //

    @JsonProperty("resourceId")
    public UUID getResourceId() {
        return resource.getId();
    }

    @JsonProperty("participantId")
    public UUID getParticipantId() {
        return participant.getId();
    }

}
