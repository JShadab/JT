package com.poc;

import java.net.URI;
import java.net.URISyntaxException;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Call;
import com.twilio.type.PhoneNumber;

public class MakeCall {

	public static final String ACCOUNT_SID = "ACda53158aeff510a5c2e2d0058b553837";
	public static final String AUTH_TOKEN = "8955e889d4f4740a7e3783fa32340a01";

	public static void main(String[] args) throws URISyntaxException {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

		Call call = Call.creator(new PhoneNumber("+13023452052"), new PhoneNumber("+14699195984"),
				new URI("http://demo.twilio.com/docs/voice.xml")).create();

		System.out.println(call.getSid());
	}

}
