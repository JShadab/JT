(function() {
	'use strict';
	angular.module('Alerts', ['ui.bootstrap', 'ui.bootstrap.tpls'])
		.factory("AlertService",["$q", "$uibModal", function ($q, $uibModal,$timeout){
			return {
				
			};

	}]);
})();






