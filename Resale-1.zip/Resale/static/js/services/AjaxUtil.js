angular.module('resale.services')
	.factory('AjaxUtil', function ($rootScope, $http, $state, $window, store, base, $timeout, $location, AlertService, toastr ) {
	return {
		
		saveErrorLog:function(jqXHR, customMsg, showMsgDialog){
			var heading = ":: Alert!";
			var me = this;
			if (jqXHR.readyState == 0) {
				$rootScope.$apply(function(){ $rootScope.alert.noService = true;});
				me.removeAll(); 
				toastr.showAlert(':: Alert!', "Unable to connect hiddin Services.")
				.then(function (){}, function (){});
				$state.go("/");
				return;
			}else{
				var msg = "";
				var rs = "", unknownPassword = false;
				if(jqXHR.responseText && jqXHR.responseText!=null){						
					rs = JSON.parse(jqXHR.responseText);
					if(rs!=null && rs.error!=null){							
						if(rs.error == 'invalid_token'){
							//msg = "Your user session expired, need to re-login.";	
							me.removeAll();$state.go("/");			
							return;
						}else if("invalid_grant" === rs.error || "unknown_password" === rs.error_description){
							msg = "Invalid user credentials";
						}else if(rs.error === "unauthorized"){
							msg = "Unknown User";
						}
						AlertService.showAlert(	heading, msg)
						.then(function (){me.logout();},function (){});
					}						
				}else if(jqXHR.error == 'invalid_token'){
					me.removeAll();$state.go("/");
				}else{
					if(showMsgDialog){
						var msg = "Unable to complete request due to communication error.";
						if(customMsg && customMsg.length > 0){ msg = customMsg;	}
						AlertService.showAlert(':: Alert!', msg)
						.then(function (){ me.logout();}, function (){});
					}
				}
			}				
			var errorText = jqXHR.status;
			if(jqXHR.errorSource && jqXHR.errorSource.length > 0){
				errorText = jqXHR.errorSource + ", CAUSE:"+jqXHR.statusText;
			}
			var formData = {}, errorLog = {};
			errorLog["errorCode"] = jqXHR.status;
			errorLog["errorText"] = errorText;
			errorLog["errorData"] = jqXHR.responseText;
			errorLog["serviceUrl"] = jqXHR.url;
			formData["errorLog"] = errorLog;
			this.submitDataNoSecure("/js/saveErrorLog",formData)
			.success(function (data, textStatus, jqXHR) {
			}).error(function (jqXHR, textStatus, errorThrown) {
			});	
		},

		onErrorCallback: function (message, duration, stateUrl, callback) {
			if (!message || message.length <= 0) {
				message = "Unable to fulfil request due to communication failure, please try again.";
			}
			if (!duration || parseInt(duration) <= 0) { //Default duration set to 4 second(s)
				duration = 4000;
			}

			this.showDurableMessage(message, duration);

			if (typeof callback !== 'undefined' && jQuery.isFunction(callback)) {
				callback();
			} else if (stateUrl && stateUrl.length > 0) {
				$state.go(stateUrl);
			}
		},

		logout: function () {
			store.remove('hiddins_token');
				store.remove('hiddins_fullName');
				store.remove('hiddins_role');
				store.remove('hiddins_userId');
				$state.go("signUp");
				$location.path('/signUp').replace();
		},
		
		
		isLoggedIn: function () {
			return this.getToken() !== null;
		},
		getToken: function () {
			return store.get('hiddins_token');
		},

		checkInvalidToken: function (data) {
			try {
				if (data && data.responseText) {
					var jsonData = JSON.parse(data.responseText);
					if (jsonData.error === 'invalid_token') {
						this.logout();
					}
				}
			} catch (e) {
				//JSON Parse error, ignore italics
			}
		},

		serviceError: function (errorData, errorStatus, headers, config) {
			try {
				if (errorData && errorData.responseText) {
					var jsonData = JSON.parse(errorData.responseText);
					if (jsonData.error === 'invalid_token') {
							store.remove('hiddins_token');
							store.remove('hiddins_fullName');
							store.remove('hiddins_role');
							store.remove('hiddins_userId');
							$state.go('signUp');
					}
				}
			} catch (e) {
				//JSON Parse error, ignore italics
			}
		},
		serviceErrorNR: function (errorData, errorStatus, headers, config) {
			try {
				if (errorData && errorData.responseText) {
					var jsonData = JSON.parse(errorData.responseText);
					if (jsonData.error === 'invalid_token') {
						store.remove('hiddins_token');
						store.remove('hiddins_fullName');
						store.remove('hiddins_role');
						store.remove('hiddins_userId');
					}
				}
			} catch (e) {
				//JSON Parse error, ignore italics
			}
		},
		authorized: function () {
			var accessToken = this.getToken();
			var headers = {
				'Authorization': 'Bearer ' + accessToken,
				'Accept': 'application/json'
			};
			$.ajaxSetup({
				'headers': headers,
				dataType: 'json'
			});
			return true;
		},
		forgotPassword: function (serviceUrl, data, methodType) {

			var methodContentType = "application/x-www-form-urlencoded; charset=utf-8";
			var methodDataType = "json";
			return this.postAJAXRequest(serviceUrl, data, methodType, methodContentType, methodDataType)

		},
		login: function (username, password, loginType) {
			$.support.cors = true;
			var data = {
				'username' 	  : username, 
				  'password' 	  : password,
				  'client_id' 	  : 'hiddinservices',
				  'client_secret' : 'hiddinservices',
				  'grant_type'    : 'password'
			};

			return $.ajax({
				url: base + 'oauth/token',
				type: "POST",
				data: data,
				contentType: "application/x-www-form-urlencoded",
				crossDomain: true
			});
		},
		getData: function (serviceUrl, data) {
			if (!this.authorized()) {
				return false;
			}

			return this.getDataNoSecure(serviceUrl, data);
		},
		getDataNoSecure: function (serviceUrl, data) {
			return this.submitAJAXRequest(serviceUrl, data, "GET")
		},
		submitData: function (serviceUrl, data) {
			if (!this.authorized()) {
				return false;
			}

			return this.submitDataNoSecure(serviceUrl, data)
		},
		submitDataforgot: function (serviceUrl, data) {
			if (!this.authorized()) {
				return false;
			}

			return this.submitDataNoSecureForgot(serviceUrl, data)
		},
		submitDataNoSecureForgot: function (serviceUrl, data) {
			return this.forgotPassword(serviceUrl, data, "GET")
		},
		submitDataNoSecure: function (serviceUrl, data) {
			return this.submitAJAXRequest(serviceUrl, data, "POST")
		},
		editDataNoSecure: function (serviceUrl, data) {
			return this.submitAJAXRequest(serviceUrl, data, "PUT")
		},
		deleteData: function (serviceUrl, data) {
			if (!this.authorized()) {
				return false;
			}

			return this.deleteDataNoSecure(serviceUrl, data)
		},
		deleteDataNoSecure: function (serviceUrl, data) {
			return this.submitAJAXRequest(serviceUrl, data, "DELETE")
		},
		submitAJAXRequest: function (serviceUrl, data, methodType) {
			var methodContentType = "application/json; charset=utf-8";
			var methodDataType = "json";
			return this.postAJAXRequest(serviceUrl, data, methodType, methodContentType, methodDataType)
		},
		postAJAXRequest: function (serviceUrl, data, methodType, methodContentType, methodDataType) {
			var finalServiceUrl = base + serviceUrl;
			$.support.cors = true;
			return $.ajax({
				type: methodType,
				url: finalServiceUrl,
				data: JSON.stringify(data),
				contentType: methodContentType,
				crossDomain: true,
				dataType: methodDataType,
				beforeSend: function (jqXHR, settings) {
					jqXHR.url = settings.url;
				}
			});
		},
		uploadData: function uploadData(serviceUrl, data) {
			var serverUrl = base + serviceUrl;
			if (!this.authorized()) {
				return false;
			}

			$.support.cors = true;
			return $.ajax({
				type: "POST",
				url: serverUrl,
				data: data,
				contentType: false,
				crossDomain: true,
				processData: false,
				cache: false
			});
		},
		downloadData: function uploadData(serviceUrl, data) {
			if (!this.authorized()) {
				return false;
			}

			$.support.cors = true;
			return $.ajax({
				type: "GET",
				url: base + serviceUrl,
				crossDomain: true,
				dataType: "binary",
				headers: {
					'Content-Type': 'image/png',
					'X-Requested-With': 'XMLHttpRequest'
				},
				processData: false,
			});
		},
		deleteData: function (serviceUrl, data) {
			if (!this.authorized()) {
				return false;
			}

			return this.deleteDataNoSecure(serviceUrl, data);
		},
		deleteDataNoSecure: function (serviceUrl, data) {
			return this.submitAJAXRequest(serviceUrl, data, "DELETE")
		},

		loaderStart : function (msg) {
			$(".backimage").append('<div id="preloader"><div class="preloaderText">'+msg+'</div></div>');
			$("#preloader").show();
		},
		loaderClose : function () {
			$('#preloader').delay(100).fadeOut('slow', function () {
				$(this).remove();
			});
		}
	};
});
