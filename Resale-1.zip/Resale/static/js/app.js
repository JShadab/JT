// var imagePath = "http://localhost:8080/resaleservices/";
// var base = "http://localhost:8080/resaleservices/";
// var appBaseUrl = "http://localhost/resales/register/";
// var resaleURL = "http://localhost:8080/";


var imagePath = "http://localhost/resale";
var appBaseUrl = "http://localhost/resale";
var base = "http://localhost:8090/";
var appName = "resale";

angular.module('resale', ['resale.services', 'resale.controllers', 'angular-storage', 'ui.router', 'ui.bootstrap', 'ui.bootstrap.tpls', 'Alerts', 'toastr'])
.constant("base", base)
.constant("appName", appName)
.constant("appBaseUrl", appBaseUrl)
.constant("imagePath", imagePath)
.run(function ($rootScope, AjaxUtil, $uibModal, $state, $location, store, $timeout,  $stateParams, $interval, toastr) {


})
.config(function ($stateProvider,$urlRouterProvider) {
	$stateProvider.state('dashboard', {
		url: '/dashboard',
		templateUrl: 'templates/dashboard.html',
		controller:"dashboardCtrl"
	}).state('signin', {
		url: '/signin',
		templateUrl: 'templates/signin.html',
		controller:"signinCtrl"
	}).state('signup', {
		url: '/signup',
		templateUrl: 'templates/signup.html',
		controller:"signupCtrl"
	}).state('post-ad', {
		url: '/post-ad',
		templateUrl: 'templates/post-ad.html',
		controller:"post-adCtrl"
	}).state('post-offer', {
		url: '/post-offer/:productId',
		templateUrl: 'templates/post-offer.html',
		controller:"post-offerCtrl"
	}).state('products', {
		url: '/products',
		templateUrl: 'templates/products.html',
		controller:"productsCtrl"
	}).state('single', {
		url: '/single',
		templateUrl: 'templates/electronics-appliances.html',
	}).state('edit-ad', {
		url: '/edit-ad/:productId',
		templateUrl: 'templates/edit-ad.html',
		controller:"edit-adCtrl"
	})
	
	$urlRouterProvider.otherwise('dashboard');


})