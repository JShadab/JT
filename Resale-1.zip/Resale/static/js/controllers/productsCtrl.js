angular.module('resale.controllers')
.controller('productsCtrl', function ($rootScope, $window, $state, $scope,AjaxUtil, $location, store, $timeout, $stateParams, AlertService, toastr) {
    

    //Run when page loades and check if user loged in
    $scope.checkIfLoggedIn=function(){
        $scope.userId=store.get("resale-userId");
        if($scope.userId != null){
            $scope.getUserById();
        } else {
            $scope.logout();
        }
    }

    //get user by ID
    $scope.getUserById=function(){
        AjaxUtil.getDataNoSecure("user/" + $scope.userId, Math.random())
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $scope.user = data;
                    $scope.$digest();
                    $scope.getProducts();
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }

    //logout
    $scope.logout = function(){
        store.remove("resale-userId");
        $state.go("signin");
    }

    //Get category
    $scope.getCategory=function(){
        AjaxUtil.getDataNoSecure("common/category", Math.random())
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $scope.categories = data;
                    $scope.$digest();
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }
    //Get products
    $scope.getProducts=function(){
        AjaxUtil.getDataNoSecure("product/byUserId?userId=" + $scope.userId, Math.random())
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $scope.products = data;
                    $scope.$digest();
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }

    //Edit product--Rout to edit page
    $scope.editProduct = function(productId){
        $state.go('edit-ad',{'productId':productId})
    }

    //Add offer--Rout to edit page
    $scope.addOffer = function(productId){
        $state.go('post-offer',{'productId':productId})
    }


});