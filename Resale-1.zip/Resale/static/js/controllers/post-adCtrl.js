angular.module('resale.controllers')
.controller('post-adCtrl', function ($rootScope, $window, $state, $scope,AjaxUtil, $location, store, $timeout, $stateParams, AlertService, toastr) {
   
    $scope.product = {};
    //Check if logged in
    $scope.checkIfLoggedIn=function(){
        $scope.userId=store.get("resale-userId");
        if($scope.userId != null){
            $scope.getUserById();
        } else {
            $scope.logout();
        }
    }

    //Get user bu userId
    $scope.getUserById=function(){
        AjaxUtil.getDataNoSecure("user/" + $scope.userId, Math.random())
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $scope.user = data;
                    $scope.$digest();
                    $scope.getCategory();
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }
    // Get category
    $scope.getCategory=function(){
        AjaxUtil.getDataNoSecure("common/category", Math.random())
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $scope.categories = data;
                    $scope.$digest();
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }

    //Save Image
    $scope.saveImage = function(){
		var file = document.getElementById("fileselect").files;
        if(file.length == 0) {
            $scope.errorMsg5=true;
            alert();
			return;
        }
		var imageFile ="";						
		imageFile = document.getElementById("fileselect").files[0];
		if(imageFile){
			var imageData = new FormData();
			imageData.append('file', imageFile);
			AjaxUtil.uploadData("uploadFile", imageData)	
			.success(function (data, status, headers, config) {	
				console.log(data);
			})
			.error(function (errorData, errorStatus, headers, config) {
			});	
		}	
    }
    
    // //Save offers
    // $scope.saveOffers=function(){
    //     if($scope.product.offers && $scope.product.offers){
    //         alert($scope.product.offers.description);
    //         console.log($scope.product);
    //         AjaxUtil.submitDataNoSecure("offers", $scope.product.offers)
    //             .success(function(data, headers, config) {
    //                 console.log(data);
    //                 if(data){
    //                     $scope.product.offers = data;
    //                     $scope.saveProduct();
    //                 } 
    //             })
    //             .error(function (errorData, errorStatus, headers, config) {
    //                 if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
    //                     toastr.error('Oops! Error occured. Please try again later.')					
    //                 }
    //             });
    //     } else {
    //         $scope.saveProduct();
    //     }
    // }

    //Save product
    $scope.saveProduct=function(){
        $scope.product.user = $scope.user;
        console.log($scope.product);
        AjaxUtil.submitDataNoSecure("product", $scope.product)
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $state.go('products');
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }

    // signout
    $scope.logout = function(){
        store.remove("resale-userId");
        $state.go("signin");
    }

});