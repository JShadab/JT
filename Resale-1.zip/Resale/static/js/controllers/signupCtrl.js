angular.module('resale.controllers')
.controller('signupCtrl', function ($rootScope, $window, $state, $scope,AjaxUtil, $location, store, $timeout, $stateParams, AlertService, toastr) {
    
    $scope.signupInputs={};
    $scope.signup=function(){
        if($scope.signupInputs.confirmPassword != $scope.signupInputs.password){
            toastr.error("Password doesn't matches");
            return;
        }
        $scope.signupInputs.roleLevel = 'Business';
        $scope.signupInputs.city = $scope.signupInputs.city.toUpperCase() ;
        AjaxUtil.submitDataNoSecure("user", $scope.signupInputs)
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $scope.user = data;
                    $scope.$digest();
                    $state.go('signin');
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }

    $scope.getCategory=function(){
        AjaxUtil.getDataNoSecure("common/category", Math.random())
            .success(function(data, headers, config) {
                console.log(data);
                if(data){
                    $scope.categories = data;
                    $scope.$digest();
                } 
            })
            .error(function (errorData, errorStatus, headers, config) {
                if(!AjaxUtil.serviceError(errorData, errorStatus, headers, config)){
                    toastr.error('Oops! Error occured. Please try again later.')					
                }
            });
    }
});